const express = require('express');
const pool = require('../pool.js');
const r = express.Router();
// 分类
r.get('/category_sort',(req,res)=>{
  let sql = 'select category_name from category';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 内容、图片
r.get('/category_body',(req,res)=>{
  let sql = 'select category_top,category_img,content_1,content_2,content_3,content_4,content_5 from category inner join category_content on cid = category_id';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 轮播图
r.get('/carousel',(req,res)=>{
  let sql = 'select * from carousel';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
module.exports = r;
// 上下滚动
r.get('/roll',(req,res)=>{
  let sql = 'select * from roll';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    } 
  })
})
// 每日必抢
r.get('/every_grab',(req,res)=>{
  let obj = req.query;
  let list_switch = obj.list_switch;
  let table = list_switch==0? 'today_list':'tomorrow_list';
  let sql = `select * from ${table}`;
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 领券中心
r.get('/coupons',(req,res)=>{
  let sql = 'select * from coupons';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 猜你喜欢
r.get('/guesslike',(req,res)=>{
  let sql = 'select * from guesslike';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层分类
r.get('/floor_sort',(req,res)=>{
  let sql = 'select * from floor_sort';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层通道
r.get('/floor_channel',(req,res)=>{
  let sql = 'select * from floor_channel';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层关键字
r.get('/floor_keywords',(req,res)=>{
  let sql = 'select * from floor_keywords';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层品牌
r.get('/floor_brand',(req,res)=>{
  let sql = 'select * from floor_brand';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层型号
r.get('/floor_model',(req,res)=>{
  let sql = 'select * from floor_model';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层商品
r.get('/floor_product',(req,res)=>{
  let sql = 'select * from floor_product';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层静态图片
r.get('/floor_static',(req,res)=>{
  let sql = 'select * from floor_static';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层背景图片
r.get('/floor_bg',(req,res)=>{
  let sql = 'select * from floor_bg';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 所有楼层标题
r.get('/floor_title',(req,res)=>{
  let sql = 'select * from floor_title';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 为您推荐
r.get('/recommend',(req,res)=>{
  let sql = 'select * from recommend';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 帮助
r.get('/help',(req,res)=>{
  let sql = 'select * from help';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 页脚部分内容
r.get('/footer',(req,res)=>{
  let sql = 'select * from footer';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 热销推荐
r.get('/hot',(req,res)=>{
  let sql = 'select * from hot_sale';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 模糊查询获取商品
// 模糊查询如果通过？占位符插值的话，'%?%' => '%'手机'%' 字符串两边的引号会导致查询出错。You have an error in your SQL syntax
// 因此，这里我们暂时使用模板字符串插值来解决
// 该sql只能模糊查询出商品详细表内的30条数据，因为当product_id大于30的话，就跟详细表的pid匹配不上了。。所以查不到。。
r.get('/get_product',(req,res)=>{
  let obj = req.query;
  let kw = obj.kw;
  let start = (obj.pno-1)*obj.count;  // 隐式转换
  let count = parseInt(obj.count);
  let field = obj.field;
  let condition = obj.condition;
  let add_condition = obj.add_condition;
  if(typeof field == 'object'){
    if(field.length == 2){
      field = `,${field[0]},${field[1]}`;
    }else if(field.length == 3){
      field = `,${field[0]},${field[1]},${field[2]}`;
    }
  }
  let sql = `select product_id,product_name,product_price,product_href,comment,lg_img,volume,news${field}
  from floor_product inner join product_detail on product_id = pid
  where ${condition} product_name like '%${kw}%' ${add_condition} limit ?,?`;  
  pool.query(sql,[start,count],(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 模糊查询获取商品数量
r.get('/get_count',(req,res)=>{
  let obj = req.query;
  let kw = obj.kw;
  let condition = obj.condition;
  let add_condition = obj.add_condition;
  // 当传递过来的参数中 包含 附加条件时，
  if(add_condition != undefined){
    // 我们就把附加条件，追加到condition之后。
    condition += ` ${add_condition} = 1 and`;
  }
  let sql = `select count(product_id) as sum from floor_product inner join product_detail 
  on product_id = pid where ${condition} product_name like '%${kw}%'`;
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 获取商品详细数据
r.get('/get_detail',(req,res)=>{
  let obj = req.query;
  let pid = obj.pid;
  // 三表联查 join 就是内连接 inner join inner可以省略，也可以使用left join 和 right join看情况而定
  let sql = `SELECT praise,brand,capacity,color,color1_sm,color1_lg,color1_xl,color2_sm,color2_lg,color2_xl 
  FROM floor_product f JOIN product_detail p ON f.product_id = p.pid
  JOIN product_detail_img pd ON f.product_id = pd.pid WHERE f.product_id = ?`;
  pool.query(sql,[pid],(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 获取省市县(区)
r.get('/get_region',(req,res)=>{
  let sql = `select * from region`;
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 获取相似商品：从对应关键字的商品中，随机抽取18个 order by rand()随机排序;
r.get('/get_similar',(req,res)=>{
  let obj = req.query;
  let kw = obj.kw;
  let sql = `select * from floor_product where product_name like '%${kw}%' order by rand() limit 0,18`;
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 获取精选：随机6个
r.get('/get_carefully',(req,res)=>{
  let sql = `select * from floor_product order by rand() limit 0,6`;
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 根据浏览猜你喜欢
r.get('/browse_like',(req,res)=>{
  let sql = 'select * from browselike';
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 获取商品参数
r.get('/get_params',(req,res)=>{
  let obj = req.query;
  let pid = obj.pid;
  let sql = 'select * from product_parameter where pid = ?';
  pool.query(sql,[pid],(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})
// 获取相关分类
r.get('/get_relevant',(req,res)=>{
  let sql = `select * from relevant_sort`;
  pool.query(sql,(err,result)=>{
    if(err){
      throw err;
    }else{
      res.send(result);
    }
  })
})

// 以下为购物车接口
// 商品数量叠加
r.put('/quantity_superposition',(req,res)=>{
  let obj = req.body;
  let quantity = obj.quantity; // 数量
  let name = obj.name;
  let capacity = obj.capacity;
  let color = obj.color;
  let guarantee = obj.guarantee;
  let stages = obj.stages;
  let uid = obj.uid;    // 用户id
  let code = obj.code;
  let sql;
  if(code == 1){
    sql = `update user_shopping set us_count = ? where us_name = ? and us_capacity = ? and
    us_color = ? and us_guarantee = ? and us_stages = ? and user_id = ?`;
    pool.query(sql,[quantity,name,capacity,color,guarantee,stages,uid],(err,result)=>{
      if(err) throw err;
      if(result.affectedRows > 0){
        res.send("1");
      }else{
        res.send("0");
      }
    })
  }else if(code == 2){
    sql = `update user_shopping set us_count = ? where us_name = ? and user_id = ?`;
    pool.query(sql,[quantity,name,uid],(err,result)=>{
      if(err) throw err;
      if(result.affectedRows > 0){
        res.send("1");
      }else{
        res.send("0");
      }
    })
  }
})
// 插入商品
r.post('/save_commodity',(req,res)=>{
  let obj = req.body;
  let sql = `insert into user_shopping set ?`;
  pool.query(sql,[obj],(err,result)=>{
    if(err) throw err;
    if(result.affectedRows > 0){
      res.send("1");
    }else{
      res.send("0");
    }
  })
})
// 删除商品
r.delete('/del_commodity',(req,res)=>{
  let obj = req.query;
  let name = obj.name;
  let capacity = obj.capacity;
  let color = obj.color;
  let guarantee = obj.guarantee;
  let stages = obj.stages;
  let uid = obj.uid;    // 用户id
  let code = obj.code;
  let sql;
  if(code == 1){
    sql = `delete from user_shopping where us_name = ? and us_capacity = ? and
    us_color = ? and us_guarantee = ? and us_stages = ? and user_id = ?`;
    pool.query(sql,[name,capacity,color,guarantee,stages,uid],(err,result)=>{
      if(err) throw err;
      if(result.affectedRows > 0){
        res.send("1");
      }else{
        res.send("0");
      }
    })
  }else if(code == 2){
    sql = `delete from user_shopping where us_name = ? and user_id = ?`;
    pool.query(sql,[name,uid],(err,result)=>{
      if(err) throw err;
      if(result.affectedRows > 0){
        res.send("1");
      }else{
        res.send("0");
      }
    })
  }else{
    sql = `delete from user_shopping where user_id = ?`;
    pool.query(sql,[uid],(err,result)=>{
      if(err) throw err;
      if(result.affectedRows > 0){
        res.send("1");
      }else{
        res.send("0");
      }
    })
  }
})

module.exports = r;