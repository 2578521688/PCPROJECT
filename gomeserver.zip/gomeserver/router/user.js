const express = require('express');
const pool = require('../pool.js');
const r = express.Router();
// 手机号验证是否存在
r.get('/check_phone',(req,res)=>{
  let obj = req.query;
  let phone = obj.phone;
  let sql = `select * from user where phone = ?`;
  pool.query(sql,[phone],(err,result)=>{
    if(err){
      throw err;
    }else{
      if(result.length>0){
        res.send("1");
      }else{
        res.send("0");
      }
    }
  })
})
// 用户名验证是否存在
r.get('/check_user',(req,res)=>{
  let obj = req.query;
  let user = obj.user;
  let sql = `select * from user where username = ?`;
  pool.query(sql,[user],(err,result)=>{
    if(err){
      throw err;
    }else{
      if(result.length>0){
        res.send("1");
      }else{
        res.send("0");
      }
    }
  })
})
// 注册
r.post('/reg_user',(req,res)=>{
  let obj = req.body;
  let sql = `insert into user set ?`;
  pool.query(sql,[obj],(err,result)=>{
    if(err){
      throw err;
    }else{
      if(result.affectedRows>0){
        res.send("1");
      }else{
        res.send("0");
      }
    }
  })
})
// 登录（手机号或者用户名都可登录）
r.get('/log_user',(req,res)=>{
  let obj = req.query;
  let uorp = obj.userNameOrPhone;
  let upwd = obj.password;
  let sql = `select uid,username,us_img,us_name,us_price,us_count,us_color,us_capacity,
  us_guarantee,us_stages,us_db,us_dbi from user left outer join user_shopping on uid = user_id 
  where username=? and password=? or phone=? and password=?`;
  pool.query(sql,[uorp,upwd,uorp,upwd],(err,result)=>{
    if(err) throw err;
    if(result.length>0){
      res.send(result);
    }else{
      res.send("0");
    }
  })
})

module.exports = r;