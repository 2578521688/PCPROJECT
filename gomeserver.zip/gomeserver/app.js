const express = require('express');
const bodyParser = require('body-parser');
const productRouter = require('./router/product.js');
const userRouter = require('./router/user.js');

const app = express();

app.listen(3000,()=>{ 
	console.log('3000端口已开启...');
});

app.use(bodyParser.urlencoded({
	extended:false
}));

app.use('/v1/products',productRouter);
app.use('/v1/users',userRouter);