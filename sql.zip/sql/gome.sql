-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2021-07-26 14:59:08
-- 服务器版本： 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gome`
--

-- --------------------------------------------------------

--
-- 表的结构 `browselike`
--

CREATE TABLE `browselike` (
  `browse_id` int(11) NOT NULL,
  `browse_img` varchar(200) NOT NULL,
  `browse_name` varchar(200) NOT NULL,
  `browse_price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `browselike`
--

INSERT INTO `browselike` (`browse_id`, `browse_img`, `browse_name`, `browse_price`) VALUES
(1, 'browselike1_1.jpg', '铁达信 漫威系列单耳蓝牙耳机MV-320 黑', '98.00'),
(2, 'browselike1_2.jpg', 'vivo Z5x 8GB+128GB 极光色 极点屏手机 5000mAh大电池 三摄拍照手机 移动联通电信4G手机', '2077.00'),
(3, 'browselike1_3.jpg', '魔栖无线耳机音箱AW-90 海军蓝', '297.00'),
(4, 'browselike1_4.jpg', '魔栖无线耳机AW-10 白色', '99.00'),
(5, 'browselike1_5.jpg', '铁达信双快充移动电源X-100pro香槟金', '139.00'),
(6, 'browselike1_6.jpg', 'vivo Z5 4800W超广角AI三摄 6GB+256GB 全息幻彩  移动联通电信全网通4G手机', '1698.00'),
(7, 'browselike2_1.jpg', '哈博钢化膜V20全屏覆盖', '47.00'),
(8, 'browselike2_2.jpg', '漫威（MARVEL） iPhoneXR 复仇者联盟4 玻璃 手机壳 正版授权 MARVELRED-24', '79.00'),
(9, 'browselike2_3.jpg', '铁达信布艺苹果数据线BY-01红', '36.00'),
(10, 'browselike2_4.jpg', '麦麦米(memumi) iPhone 5.8 保护套 超薄系列 纯黑', '60.00'),
(11, 'browselike2_5.jpg', '雷神笔记本电脑911Plus -97508G512G1660Ti6GWBZ', '7999.00'),
(12, 'browselike2_6.jpg', '京瓷 TASKalfa 4012i-001 A3黑白多功能数码复合机(配置50页双面输稿器+专用纸柜)', '5998.00');

-- --------------------------------------------------------

--
-- 表的结构 `carousel`
--

CREATE TABLE `carousel` (
  `carousel_id` int(11) NOT NULL,
  `carousel_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `carousel`
--

INSERT INTO `carousel` (`carousel_id`, `carousel_img`) VALUES
(1, 'banner1.jpg'),
(2, 'banner2.jpg'),
(3, 'banner3.jpg'),
(4, 'banner4.jpg'),
(5, 'banner5.jpg'),
(6, 'banner6.jpg'),
(7, 'banner7.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE `category` (
  `cid` int(11) NOT NULL,
  `category_name` varchar(20) NOT NULL,
  `category_top` varchar(200) NOT NULL,
  `category_img` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`cid`, `category_name`, `category_top`, `category_img`) VALUES
(1, '手机|充值', '潮3C|手机|数码|以旧换新|手机充值|延保服务|智享生活', 'category_1/business_1.jpg|category_1/business_2.jpg|category_1/business_3.jpg|category_1/business_4.jpg|category_1/business_5.jpg|category_1/business_6.jpg'),
(2, '相机|智能数码', '潮3C|数码|以旧换新|延保服务|智享生活', 'category_2/business_1.jpg|category_2/business_2.jpg|category_2/business_3.jpg'),
(3, '电脑|办公软件', '潮3C|电脑办公|精品配件|以旧换新|美通卡|延保服务', 'category_3/business_1.jpg|category_3/business_2.jpg|category_3/business_3.jpg|category_3/business_4.jpg|category_3/business_5.jpg|category_3/business_6.jpg'),
(4, '电视|影音|智能', '电视影音|美通卡|以旧换新|延保服务|智享生活', 'category_4/business_1.jpeg|category_4/business_2.jpeg|category_4/business_3.jpeg|category_4/business_4.jpg|category_4/business_5.jpg|category_4/business_6.jpg|category_4/business_7.jpg|category_4/business_8.jpg'),
(5, '空调|冰箱|洗衣机', '空调|冰箱|洗衣机|美通卡|以旧换新|延保服务', 'category_5/business_1.jpg|category_5/business_2.jpg|category_5/business_3.jpg|category_5/business_4.jpg|category_5/business_5.jpg|category_5/business_6.jpeg|category_5/business_7.jpg|category_5/business_8.jpeg'),
(6, '厨房卫浴|生活电器|环境', '烟灶卫浴馆|厨卫新活馆|小家电|取暖器|美通卡|延保服务', 'category_6/business_1.jpg|category_6/business_2.jpg|category_6/business_3.jpg|category_6/business_4.jpg|category_6/business_5.jpg|category_6/business_6.jpeg|category_6/business_7.jpg|category_6/business_8.jpg'),
(7, '家具|建材|欧洲厨房', '住宅家具|家装建材|家装馆', 'category_7/business_1.png|category_7/business_2.jpg|category_7/business_3.jpg|category_7/business_4.jpg|category_7/business_5.jpg|category_7/business_6.png'),
(8, '家居家纺|家居家装', '家居日用|家居特卖惠|精选锅具', 'category_8/business_1.jpg|category_8/business_2.jpg|category_8/business_3.jpg|category_8/business_4.jpg|category_8/business_5.png|category_8/business_6.jpg'),
(9, '食品酒水|母婴玩具', '食品酒水|母婴玩具', 'category_9/business_1.jpg|category_9/business_2.jpg|category_9/business_3.jpg|category_9/business_4.jpg'),
(10, '美妆个护', '美妆个护', 'category_10/business_1.jpg'),
(11, '服饰鞋帽|箱包奢品', '服饰鞋帽|箱包奢品', 'category_11/business_1.jpg'),
(12, '运动户外|钟表首饰', '运动户外|钟表首饰', 'category_12/business_1.jpg|category_12/business_2.jpg'),
(13, '汽车整车|汽车用品', '国美汽车', 'category_13/business_1.jpg|category_13/business_2.jpg|category_13/business_3.jpg'),
(14, '国美金融', '国美金融', 'category_14/business_1.jpg'),
(15, '国美管家|美锅优食', '延保服务|美锅优食', 'category_15/business_1.jpg|category_15/business_2.jpg|category_15/business_3.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `category_content`
--

CREATE TABLE `category_content` (
  `content_id` int(11) NOT NULL,
  `content_1` varchar(200) NOT NULL,
  `content_2` varchar(200) NOT NULL,
  `content_3` varchar(200) NOT NULL,
  `content_4` varchar(200) NOT NULL,
  `content_5` varchar(200) NOT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `category_content`
--

INSERT INTO `category_content` (`content_id`, `content_1`, `content_2`, `content_3`, `content_4`, `content_5`, `category_id`) VALUES
(1, '手机通讯|手机|iPhone|华为|小米|荣耀', '运营商|中国移动|中国联通', '手机配件|手机壳|贴膜|手机存储卡|数据线|充电器', '充话费|移动|联通|电信|极信', '充流量|移动|联通|电信', 1),
(2, '摄影摄像|数码相机|单反相机|微单相机|摄像机|拍立得', '数码配件|存储卡|三脚架|相机包|滤镜|贴膜', '智能设备|智能手表|智能手环|VR眼睛|智能家居|健康监测', '视听娱乐|耳机|音响|MP3|收音机', '电子教育|电子书|电子词典|录音笔|学生平板|点读机', 2),
(3, '电脑整机|笔记本|游戏本|平板|台式|一体机', '外设产品|鼠标|键盘|电脑包|U盘|鼠标垫', '网络产品|路由器|机顶盒|交换机|网卡|5G', '办公设备|投影机|打印机|传真|收银机|保险柜', '电脑配件|显示器|CPU|主板|显卡|硬盘', 3),
(4, '电视|海信|长虹|TCL|小米|索尼', '电视配件|3D电视配件|保养配件|插线板|智能电视盒|电视框架', '音响|影院|播放器|DVD', '影音配件|其他配件|影音线材|线材转换器', '智能设备|智能手环|智能手表|智能眼镜|智能家居|航拍设备', 4),
(5, '空调|家用空调|商用空调|中央空调|柜式空调|移动空调', '冰箱|冰柜|酒柜|对开门|三门|双门', '洗衣机|滚筒洗衣机|波轮洗衣机|洗烘一体机|迷你洗衣机|干衣机', '彩电|大彩电|小彩电|迷你彩电', '气灶|燃气灶|煤气灶|锅炉|油烟机', 5),
(6, '厨卫大电|油烟机|燃气灶|消毒柜|热水器|洗碗机', '厨卫小电|微波炉|豆浆机|电饭煲|炊具|电烤箱', '环境电器|取暖器|空调扇|空气净化器|除湿机|加湿器', '个人护理|剃须刀|电吹风|理发器|脱毛器|美容仪', '水家电|净水器|饮水机|滤水壶|净水桶|滤料', 6),
(7, '客厅家具|沙发|茶几|电视柜|鞋柜|衣帽架', '卧室家具|床头柜|床|床垫|梳妆台|衣柜', '餐厅家具|餐桌|餐椅|餐桌椅套装|餐边柜', '儿童办公|儿童座椅|儿童床类|儿童衣柜|儿童套装|休闲躺椅', '书房家具|书桌|电脑桌|电脑椅|书柜', 7),
(8, '清洁用品|居室清洁|清洁工具|驱虫除害|纸品湿巾|防护用品', '生活日用|缝纫用品|收纳用品|浴室用品|洗晒用品|雨伞雨具', '厨具|烹饪锅具|刀剪砧板|保险收纳|厨房小件|精美餐具', '芯类|被子|电热毯|床垫|床褥|毛巾毯', '夏凉用品|凉席|夏凉被|蚊帐|凉枕|凉品套装', 8),
(9, '休闲零食|坚果炒货|糖果巧克力|肉感肉蒲|饼干糕点', '酒水|白酒|洋酒|葡萄酒|啤酒|保健酒', '茶叶|绿茶|铁观音|普洱茶|红茶|花茶', '进口食品|牛奶|饼干|米面|粮油|饮品', '喂养洗护|奶瓶|餐具|沐浴|护肤|消毒', 9),
(10, '面部护理|洁面|化妆水|乳液|面膜|精华', '身体护理|洗发|沐浴|脱毛|瘦身|手足', '个护清洁|纸品|湿巾|口腔|女性|家庭', '魅力彩妆|粉底|卸妆|睫毛|美甲|工具', '男士护理|剃须|防脱|脸部|眼部|唇膏', 10),
(11, '品质男装|卫衣|休闲裤|牛仔裤|夹克|T恤', '时尚女装|风衣|打底裤|休闲裤|针织衫|内衣', '箱包|学生包|休闲运动包|电脑包|旅行包|拖运箱', '奢侈品|单肩包|手提包|双肩包|钱包|斜挎包', '服饰配件|太阳镜|丝巾|皮带|手套|帽子', 11),
(12, '运动鞋服|跑步鞋|休闲鞋|训练鞋|瑜伽', '运动器械|自行车|羽毛球|器械|瑜伽垫|护具', '户外装备|帐篷|背包|桌椅床|望远镜|照明', '户外鞋服|户外T恤|户外衬衣|速干衣裤|户外配饰', '钟表|瑞士品牌|国产品牌|日韩品牌|时尚品牌', 12),
(13, '车载电器|汽车记录仪|净化器|车载冰箱|吸尘器|电源', '养护配件|轮胎|雨刷|雨衣', '美容清洁|洗车机|车蜡|玻璃水|清洁剂|汽车配件', '车饰精品|四季垫|香水|内饰|脚垫|颈枕', '安全自驾|儿童安全座椅|防盗设备|应急救援|打气泵|自驾装备', 13),
(14, '国美基金|国美基金', '国美黄金|国美黄金', '国美白金|国美白金', '国美钻石|国美钻石', '国美翡翠|国美翡翠', 14),
(15, '清洗服务|家电清洗', '维修服务|手机维修|家电维修', '环境治理|空气治理', '延长保修|家电延长保修', '产品展示|烧烤食材|火锅', 15);

-- --------------------------------------------------------

--
-- 表的结构 `coupons`
--

CREATE TABLE `coupons` (
  `coupons_id` int(11) NOT NULL,
  `coupons_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `coupons`
--

INSERT INTO `coupons` (`coupons_id`, `coupons_img`) VALUES
(1, 'coupons.jpg'),
(2, 'coupons_5.jpg'),
(3, 'coupons_20.jpg'),
(4, 'coupons_100.jpg'),
(5, 'coupons_200.jpg'),
(6, 'coupons_300.jpg'),
(7, 'coupons_more.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `floor_bg`
--

CREATE TABLE `floor_bg` (
  `bg_id` int(11) NOT NULL,
  `bg_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_bg`
--

INSERT INTO `floor_bg` (`bg_id`, `bg_img`) VALUES
(1, 'mobile_bg.jpg'),
(2, 'computer_bg.jpg'),
(3, 'electric_bg.jpg'),
(4, 'shop_bg.jpg'),
(5, 'car_bg.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `floor_brand`
--

CREATE TABLE `floor_brand` (
  `brand_id` int(11) NOT NULL,
  `brand_img` varchar(200) NOT NULL,
  `brand_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_brand`
--

INSERT INTO `floor_brand` (`brand_id`, `brand_img`, `brand_name`) VALUES
(1, 'mobile/brand/mobile_brand1.jpg', 'oppo'),
(2, 'mobile/brand/mobile_brand2.jpg', '手机充值'),
(3, 'mobile/brand/mobile_brand3.jpg', '魅族'),
(4, 'mobile/brand/mobile_brand4.png', '飞利浦'),
(5, 'mobile/brand/mobile_brand5.png', '中兴'),
(6, 'mobile/brand/mobile_brand6.png', '诺基亚'),
(7, 'computer/brand/computer_brand1.jpeg', '戴尔'),
(8, 'computer/brand/computer_brand2.jpg', '苹果'),
(9, 'computer/brand/computer_brand3.jpg', '华硕'),
(10, 'computer/brand/computer_brand4.jpeg', '惠普'),
(11, 'computer/brand/computer_brand5.jpg', 'thinkpad'),
(12, 'computer/brand/computer_brand6.jpg', '联想'),
(13, 'electric/brand/electric_brand1.jpg', '伊莱克斯空调'),
(14, 'electric/brand/electric_brand2.jpg', '卡萨帝空调'),
(15, 'electric/brand/electric_brand3.jpg', '海信空调'),
(16, 'electric/brand/electric_brand4.jpg', '美的空调'),
(17, 'electric/brand/electric_brand5.jpg', '海尔空调'),
(18, 'electric/brand/electric_brand6.jpg', '格力空调'),
(19, 'shop/brand/shop_brand1.jpg', '食品'),
(20, 'shop/brand/shop_brand2.jpg', '食品'),
(21, 'shop/brand/shop_brand3.jpg', '食品'),
(22, 'shop/brand/shop_brand4.jpg', '酒水'),
(23, 'shop/brand/shop_brand5.jpg', '食品'),
(24, 'shop/brand/shop_brand6.jpg', '酒水'),
(25, 'car/brand/car_brand1.jpg', '美孚'),
(26, 'car/brand/car_brand2.jpg', '途虎'),
(27, 'car/brand/car_brand3.jpg', '巡游'),
(28, 'car/brand/car_brand4.jpg', '长城'),
(29, 'car/brand/car_brand5.jpg', '乔氏'),
(30, 'car/brand/car_brand6.jpg', '卡饰得');

-- --------------------------------------------------------

--
-- 表的结构 `floor_channel`
--

CREATE TABLE `floor_channel` (
  `channel_id` int(11) NOT NULL,
  `channel_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_channel`
--

INSERT INTO `floor_channel` (`channel_id`, `channel_name`) VALUES
(1, '手机|充值|电器城'),
(2, '电脑|数码|配件|潮电子'),
(3, '电视|冰箱|洗衣机|空调'),
(4, '母婴|美妆|食品|酒水'),
(5, '机油|轮胎|电瓶');

-- --------------------------------------------------------

--
-- 表的结构 `floor_keywords`
--

CREATE TABLE `floor_keywords` (
  `keyword_id` int(11) NOT NULL,
  `keyword_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_keywords`
--

INSERT INTO `floor_keywords` (`keyword_id`, `keyword_name`) VALUES
(1, '荣耀|iQOO|华为|热销推荐|以旧换新'),
(2, '潮3C|配件|全面屏|保护套|小米'),
(3, 'iPhone12|淘实惠|飞利浦|中兴|诺基亚'),
(4, '华硕|游戏本|单反相机|智能家居|智能路由'),
(5, '轻薄本|联想|微单|耳机|投影机'),
(6, '惠普电脑|戴尔|智能音箱|智能手表|插线板线材'),
(7, '智能电视|海尔冰箱|柜式空调|变频风冷|音响影院'),
(8, '全面屏|全自动|壁挂式|冷柜|播放器'),
(9, '55英寸电视|滚筒洗衣机|变频空调|多门/对开|电视影音配件'),
(10, '休闲零食|米面粮油|冲调饮品|茅台|海之蓝'),
(11, '奔富|按摩器|水果|我买网|面膜'),
(12, '纸品湿巾|面部处理|品牌奶粉|纸尿裤|益智玩具'),
(13, '汽车记录|机油|改装配件|车蜡|整车'),
(14, '轮胎|洗车机|添加剂|新品坐|专场坐'),
(15, '儿童座椅|蓄电池|防冻液|车载生活|维修保养');

-- --------------------------------------------------------

--
-- 表的结构 `floor_model`
--

CREATE TABLE `floor_model` (
  `model_id` int(11) NOT NULL,
  `model_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_model`
--

INSERT INTO `floor_model` (`model_id`, `model_img`) VALUES
(1, 'mobile/model/mobile_model1.jpg'),
(2, 'mobile/model/mobile_model2.jpg'),
(3, 'mobile/model/mobile_model3.jpg'),
(4, 'mobile/model/mobile_model4.jpg'),
(5, 'mobile/model/mobile_model5.jpg'),
(6, 'mobile/model/mobile_model6.jpg'),
(7, 'computer/model/computer_model1.jpg'),
(8, 'computer/model/computer_model2.jpg'),
(9, 'computer/model/computer_model3.jpg'),
(10, 'computer/model/computer_model4.jpg'),
(11, 'computer/model/computer_model5.jpg'),
(12, 'computer/model/computer_model6.jpg'),
(13, 'electric/model/electric_model1.jpg'),
(14, 'electric/model/electric_model2.jpg'),
(15, 'electric/model/electric_model3.jpg'),
(16, 'electric/model/electric_model4.jpg'),
(17, 'electric/model/electric_model5.jpg'),
(18, 'electric/model/electric_model6.jpg'),
(19, 'shop/model/shop_model1.jpg'),
(20, 'shop/model/shop_model2.jpg'),
(21, 'shop/model/shop_model3.jpg'),
(22, 'shop/model/shop_model4.jpg'),
(23, 'shop/model/shop_model5.jpg'),
(24, 'shop/model/shop_model6.jpg'),
(25, 'car/model/car_model1.jpg'),
(26, 'car/model/car_model2.jpg'),
(27, 'car/model/car_model3.jpg'),
(28, 'car/model/car_model4.jpeg'),
(29, 'car/model/car_model5.png'),
(30, 'car/model/car_model6.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `floor_product`
--

CREATE TABLE `floor_product` (
  `product_id` int(11) NOT NULL,
  `product_img` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_price` decimal(6,2) NOT NULL,
  `product_href` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_product`
--

INSERT INTO `floor_product` (`product_id`, `product_img`, `product_name`, `product_price`, `product_href`) VALUES
(1, 'mobile/product/product_1/product1_1.jpg', 'Apple iPhone 12 64G 多色 移动联通电信 5G手机', '7499.00', '/details/1'),
(2, 'mobile/product/product_1/product1_2.jpg', 'Apple 苹果 iPhone 11 手机 全网通 双卡双待 新包装 5G手机', '5998.00', '/details/2'),
(3, 'mobile/product/product_1/product1_3.jpg', '小米Redmi 红米9A 5000mAh大电量 大屏幕大字体大音量 1300万AI相机 八核处理器 人脸解锁 5G手机', '4666.00', '/details/3'),
(4, 'mobile/product/product_1/product1_4.jpg', '小米MI 小米10S 5G 骁龙870 VC液冷散热 蓝 游戏智能 5G手机', '4799.00', '/details/4'),
(5, 'mobile/product/product_1/product1_5.jpg', 'vivo S9 8 128G 印象拾光 5G手机', '2899.00', '/details/5'),
(6, 'mobile/product/product_1/product1_6.jpg', 'vivo S9e 8GB 256GB 5G手机', '2699.00', '/details/6'),
(7, 'mobile/product/product_1/product1_7.jpg', 'vivo X60Pro 12 256GB 5G手机', '5998.00', '/details/7'),
(8, 'mobile/product/product_1/product1_8.jpg', '华为 nova 7 Pro 8GB 128GB 5G手机', '3699.00', '/details/8'),
(9, 'mobile/product/product_1/product1_9.jpg', '荣耀V40 8GB 128GB 5G手机', '3589.00', '/details/9'),
(10, 'mobile/product/product_1/product1_10.jpg', 'Apple iPhone 12 Pro Max 128G 5G手机', '8799.00', '/details/10'),
(11, 'mobile/product/product_2/product2_1.jpg', '华为 Mate40 Pro 8GB 256GB 5G手机', '7599.00', '/details/11'),
(12, 'mobile/product/product_2/product2_2.jpg', '华为 Mate30E Pro 8GB 128GB 5G手机', '5299.00', '/details/12'),
(13, 'mobile/product/product_2/product2_3.jpg', '荣耀V40 8GB 256GB 5G手机', '3989.00', '/details/13'),
(14, 'mobile/product/product_2/product2_4.jpg', 'OPPO Reno5Pro 12GB 256GB 5G手机', '3599.00', '/details/14'),
(15, 'mobile/product/product_2/product2_5.jpg', 'vivo X60 8 256GB 5G手机', '3599.00', '/details/15'),
(16, 'mobile/product/product_2/product2_6.jpg', '荣耀 X10 8 128G 5G手机', '2399.00', '/details/16'),
(17, 'mobile/product/product_2/product2_7.jpg', '小米10S 12GB 256GB 5G手机', '3799.00', '/details/17'),
(18, 'mobile/product/product_2/product2_8.jpg', '小米11 8GB 256GB 5G手机', '4299.00', '/details/18'),
(19, 'mobile/product/product_2/product2_9.jpg', 'iQOO Neo3 8G 256G 5G手机', '3398.00', '/details/19'),
(20, 'mobile/product/product_2/product2_10.jpg', '华为 nova 7 Pro 8GB 128GB 5G手机', '3699.00', '/details/20'),
(21, 'mobile/product/product_3/product3_1.jpg', 'OPPO A72 8GB 128GB 5G手机', '1799.00', '/details/21'),
(22, 'mobile/product/product_3/product3_2.jpg', 'vivo Y3s 4GB 128G 5G手机', '1098.00', '/details/22'),
(23, 'mobile/product/product_3/product3_3.jpg', 'Redmi Note 9 5G 6GB 128GB 5G手机', '1299.00', '/details/23'),
(24, 'mobile/product/product_3/product3_4.jpg', 'OPPO A32 8 128GB 5G手机', '1399.00', '/details/24'),
(25, 'mobile/product/product_3/product3_5.jpg', 'vivo Y52s 8GB 128GB 5G手机', '1699.00', '/details/25'),
(26, 'mobile/product/product_3/product3_6.jpg', 'vivo Y31s 6GB 128GB 5G手机', '1498.00', '/details/26'),
(27, 'mobile/product/product_3/product3_7.jpg', 'OPPO A93 8GB 256GB 5G手机', '1999.00', '/details/27'),
(28, 'mobile/product/product_3/product3_8.jpg', 'iQOO U3 8 128GB 5G手机', '1598.00', '/details/28'),
(29, 'mobile/product/product_3/product3_9.jpg', 'Redmi 9A 6GB 128GB 5G手机', '899.00', '/details/29'),
(30, 'mobile/product/product_3/product3_10.jpg', 'iQOO Z3 8GB 128GB 5G手机', '1799.00', '/details/30'),
(31, 'computer/product/product_1/product1_1.jpg', '惠普(hp) 光影精灵6 16英寸十代英特尔酷睿i5游戏本笔记本电脑i5-10200H 16G 512G 高色域 紫光(16-a0076TX)', '5599.00', ''),
(32, 'computer/product/product_1/product1_2.jpg', '戴尔DELL灵越5000 15.6英寸英特尔酷睿i5轻薄笔记本电脑(十一代i5-1135G7 16G 512G MX350 2G独显)银', '5199.00', ''),
(33, 'computer/product/product_1/product1_3.jpg', 'Apple iPad Air 10.9英寸 2020年新款 平板电脑（256G WLAN版/A14芯片/触控ID/2360 x 1640 分辨率）玫瑰金', '5399.00', ''),
(34, 'computer/product/product_1/product1_4.jpg', '联想(Lenovo)小新Air15 2021锐龙版全面屏轻薄笔记本电脑(8核R7-4800U 16G 512G 100%sRGB 高色域)深空灰', '4899.00', ''),
(35, 'computer/product/product_1/product1_5.jpg', '华硕笔记本电脑E410MA', '4899.00', ''),
(36, 'computer/product/product_1/product1_6.jpg', 'Kindle oasis电子书阅读器', '2658.00', ''),
(37, 'computer/product/product_1/product1_7.jpg', '荣耀手表GS Pro 潮汐蓝', '1388.00', ''),
(38, 'computer/product/product_1/product1_8.jpg', '小米55W氮化镓充电器', '99.00', ''),
(39, 'computer/product/product_1/product1_9.jpg', 'Apple Watch S6智能手表', '3399.00', ''),
(40, 'computer/product/product_1/product1_10.jpg', '华为Max 40W超级快充立式无线充电器', '269.00', ''),
(41, 'computer/product/product_2/product2_1.jpg', '联想(Lenovo)小新Air15 2021锐龙版全面屏轻薄笔记本电脑(8核R7-4800U 16G 512G 100%sRGB 高色域)深空灰', '4899.00', ''),
(42, 'computer/product/product_2/product2_2.jpg', '华硕(ASUS) VivoBook14 X 2020 14英寸金属轻薄本笔记本电脑(i5-10210U 8G 512G固态+32G傲腾 2G独显)耀夜黑', '4799.00', ''),
(43, 'computer/product/product_2/product2_3.jpg', '蔡徐坤代言 惠普(hp) 星系列14英寸十一代轻薄本笔记本电脑 粉 i5-1135G7 16G 512G固态硬盘(14-dv0007TX)', '5399.00', ''),
(44, 'computer/product/product_2/product2_4.jpg', '联想(Lenovo)小新Air14 2020锐龙版 全面屏金属超轻薄笔记本电脑(6核R5-4600U 16G 512G IPS高清屏 高色域)灰', '4199.00', ''),
(45, 'computer/product/product_2/product2_5.jpg', '戴尔（DELL）游匣G3 2020新品 15.6英寸第十代游戏笔记本电脑（i7-10750H 16G 512G GTX1660Ti 6G独显）黑', '6599.00', ''),
(46, 'computer/product/product_2/product2_6.jpg', '联想(Lenovo)拯救者R7000P 15.6英寸游戏笔记本电脑(R7-4800H 16G 512G SSD RTX2060 144Hz)钛晶灰', '7599.00', ''),
(47, 'computer/product/product_2/product2_7.jpg', '华硕(ASUS) 飞行堡垒8 15.6英寸游戏笔记本电脑(i7-10750H 8G 512SSD GTX1650Ti 4G)144Hz电竞屏', '6599.00', ''),
(48, 'computer/product/product_2/product2_8.jpg', '联想(Lenovo)拯救者Y7000英特尔酷睿 15.6英寸游戏笔记本电脑标配i5-10200H 16G 512G  1650-4G', '6499.00', ''),
(49, 'computer/product/product_2/product2_9.jpg', '联想(Lenovo)小新Pro13 2020 锐龙版 全面屏性能超轻薄笔记本电脑(6核R5-4600U 16G 512G 2.5K屏 高色域)灰', '4829.00', ''),
(50, 'computer/product/product_2/product2_10.jpg', '蔡徐坤代言 惠普(HP)星14 青春版 14英寸轻薄窄边框笔记本电脑 R7-4700U 16G 512G SSD UMA FHD IPS 闪耀银', '4199.00', ''),
(51, 'computer/product/product_3/product3_1.jpg', '佳能单反相机EOS 90D(EF-S 18-135 IS USM)', '9499.00', ''),
(52, 'computer/product/product_3/product3_2.jpg', '索尼全画幅微单机身ILCE-7RM4', '9889.00', ''),
(53, 'computer/product/product_3/product3_3.jpg', '尼康微单Z7(24-70)', '9289.00', ''),
(54, 'computer/product/product_3/product3_4.jpg', '佳能微单EOSM6(18-150)', '4730.00', ''),
(55, 'computer/product/product_3/product3_5.jpg', 'GoPro运动摄像机HERO8', '2298.00', ''),
(56, 'computer/product/product_3/product3_6.jpg', '索尼黑卡相机RX100M4', '5235.00', ''),
(57, 'computer/product/product_3/product3_7.jpg', '佳能镜头RF24-70MM F2.8 L IS USM', '5599.00', ''),
(58, 'computer/product/product_3/product3_8.jpg', '佳能RF70-200MM F2.8 L IS USM', '7599.00', ''),
(59, 'computer/product/product_3/product3_9.jpg', '佳能单反800D(18-135)', '6099.00', ''),
(60, 'computer/product/product_3/product3_10.jpg', '佳能单反 5D Mark IV(24-105)', '1600.00', ''),
(61, 'electric/product/product_1/product1_1.jpg', '长虹55英寸人工智能电视', '2399.00', ''),
(62, 'electric/product/product_1/product1_2.jpg', 'TCL 55英寸4K智能电视', '2099.00', ''),
(63, 'electric/product/product_1/product1_3.jpg', '海信65英寸人工智能电视', '2899.00', ''),
(64, 'electric/product/product_1/product1_4.jpg', '小米43英寸人工智能电视', '1899.00', ''),
(65, 'electric/product/product_1/product1_5.jpg', '海尔55英寸人工智能电视', '1699.00', ''),
(66, 'electric/product/product_1/product1_6.jpg', '康佳55英寸4K超高清智能电视', '1699.00', ''),
(67, 'electric/product/product_1/product1_7.jpg', '创维65英寸4K超高清智能电视', '3999.00', ''),
(68, 'electric/product/product_1/product1_8.jpg', '索尼55英寸4K智能电视', '4999.00', ''),
(69, 'electric/product/product_1/product1_9.jpg', 'TCL 32英寸经典蓝光机', '699.00', ''),
(70, 'electric/product/product_1/product1_10.jpg', 'TCL 50英寸高画质4K电视', '1699.00', ''),
(71, 'electric/product/product_2/product2_1.jpg', '海尔10kg滚筒洗衣机', '2499.00', ''),
(72, 'electric/product/product_2/product2_2.jpg', '荣事达7kg波轮洗衣机', '779.00', ''),
(73, 'electric/product/product_2/product2_3.jpg', '西门子8kg滚筒洗衣机', '3799.00', ''),
(74, 'electric/product/product_2/product2_4.jpg', '三星9kg变频滚筒洗衣机', '6490.00', ''),
(75, 'electric/product/product_2/product2_5.jpg', '海尔8kg波轮洗衣机', '1049.00', ''),
(76, 'electric/product/product_2/product2_6.jpg', '小天鹅8kg波轮洗衣机', '999.00', ''),
(77, 'electric/product/product_2/product2_7.jpg', '松下10kg滚筒洗衣机', '4998.00', ''),
(78, 'electric/product/product_2/product2_8.jpg', '海尔9kg滚筒洗衣机', '2699.00', ''),
(79, 'electric/product/product_2/product2_9.jpg', '海信7kg波轮洗衣机', '899.00', ''),
(80, 'electric/product/product_2/product2_10.jpg', '西门子10kg滚筒洗衣机', '3899.00', ''),
(81, 'electric/product/product_3/product3_1.jpg', '海尔258L三门冰箱', '3199.00', ''),
(82, 'electric/product/product_3/product3_2.jpg', '西门子610L对开门冰箱', '6299.00', ''),
(83, 'electric/product/product_3/product3_3.jpg', '美的535L对开门冰箱', '2699.00', ''),
(84, 'electric/product/product_3/product3_4.jpg', '美菱568L对开门冰箱', '3799.00', ''),
(85, 'electric/product/product_3/product3_5.jpg', '美菱362L多门冰箱', '2899.00', ''),
(86, 'electric/product/product_3/product3_6.jpg', '西门子452L十字对开门冰箱', '7699.00', ''),
(87, 'electric/product/product_3/product3_7.jpg', '博世452L十字对开门冰箱', '8699.00', ''),
(88, 'electric/product/product_3/product3_8.jpg', '美菱200L双门冰箱', '1599.00', ''),
(89, 'electric/product/product_3/product3_9.jpg', '海尔642L对开门冰箱', '3599.00', ''),
(90, 'electric/product/product_3/product3_10.jpg', '美的207L双门冰箱电脑控温芙蓉金', '1899.00', ''),
(91, 'shop/product/product_1/product1_1.jpg', '佳贝艾特悠装幼儿配方羊奶粉3段800g (12-36月龄适用)', '306.00', ''),
(92, 'shop/product/product_1/product1_2.jpg', '飞鹤星飞帆幼儿配方奶粉3段700g 12-36个月幼儿适用', '262.00', ''),
(93, 'shop/product/product_1/product1_3.jpg', '爱他美婴儿配方奶粉2段800g （6–12月龄适用）新老包装随机发货', '159.00', ''),
(94, 'shop/product/product_1/product1_4.jpg', '惠氏启赋婴幼儿配方奶粉3段900g【官方授权】 蓝钻启赋  品质保证 爱尔兰原装进口', '262.00', ''),
(95, 'shop/product/product_1/product1_5.jpg', '美素佳儿幼儿配方奶粉3段900g （1-3岁适用）', '159.00', ''),
(96, 'shop/product/product_1/product1_6.jpg', '强生婴儿牛奶营养面霜60g 润肤霜 宝宝面霜 滋润补水', '37.90', ''),
(97, 'shop/product/product_1/product1_7.jpg', '可心柔V9婴儿纸巾120抽*5 量贩装 保湿抽纸餐巾纸儿童面巾纸', '34.90', ''),
(98, 'shop/product/product_1/product1_8.jpg', '强生婴儿牛奶润肤露500g 身体乳 润肤乳 牛奶滋养 长效保湿 秋冬身体乳', '41.90', ''),
(99, 'shop/product/product_1/product1_9.jpg', '维达湿巾纸巾婴儿手口可用80片装 卫生洁肤', '13.90', ''),
(100, 'shop/product/product_1/product1_10.jpg', '盈佳智能机器狗塑料11801 儿童玩具早教机宝宝玩具小孩百科问答编程早教玩具', '147.90', ''),
(101, 'shop/product/product_2/product2_1.jpg', '阿玛尼挚爱哑光唇膏口红4g(番茄红301#) 哑而不干润泽持久', '99.00', ''),
(102, 'shop/product/product_2/product2_2.jpg', '沙宣去屑洗发水水润去屑750ml （针对油头与头屑问题水润平衡去屑轻盈男士女士通用新老包装随机发货）', '77.90', ''),
(103, 'shop/product/product_2/product2_3.jpg', 'SK-II嫩肤清莹露160ml 【专柜版】 去角质、清洁、毛孔细致', '560.00', ''),
(104, 'shop/product/product_2/product2_4.jpg', '资生堂安热沙水能户外清透防晒乳SPF50+ PA+++60ml（俗称安耐晒）【专柜版】 防晒 清爽 不油腻', '298.00', ''),
(105, 'shop/product/product_2/product2_5.jpg', '百雀羚小雀幸补水紧致面膜30片装 面膜女补水保湿化妆品护肤品套装', '119.90', ''),
(106, 'shop/product/product_2/product2_6.jpg', '纽西之谜烟酰胺果冻美白淡斑面膜30ml*7片 美白淡斑', '86.00', ''),
(107, 'shop/product/product_2/product2_7.jpg', '美迪惠尔水润保湿面膜10片水库针剂 补水保湿', '45.00', ''),
(108, 'shop/product/product_2/product2_8.jpg', '碧柔水活SPF50+PA++防晒乳90ml 倍护水凝露防晒霜日本进口', '59.00', ''),
(109, 'shop/product/product_2/product2_9.jpg', '瓷遇粉扑美妆化妆蛋海绵蛋化妆工具三只套装 国美超市甄选', '27.90', ''),
(110, 'shop/product/product_2/product2_10.jpg', '兰蔻小黑瓶眼霜套装 15ml*2【专柜版】 改善黑眼圈 淡眼纹', '980.00', ''),
(111, 'shop/product/product_3/product3_1.jpg', '统一(QXTY)阿萨姆奶茶原味奶茶500ml*15 国美超市甄选', '58.90', ''),
(112, 'shop/product/product_3/product3_2.jpg', 'Perrier巴黎水330ml*24瓶气泡矿泉水柠檬味含气（玻璃瓶） 国美超市甄选', '59.00', ''),
(113, 'shop/product/product_3/product3_3.jpg', '红牛含气维生素功能饮料250mL*4罐 奥地利原装进口', '47.90', ''),
(114, 'shop/product/product_3/product3_4.jpg', '桂格即食燕麦片超值装1478g 膳食纤维，谷物早餐', '22.90', ''),
(115, 'shop/product/product_3/product3_5.jpg', '蒙牛全脂甜奶粉400g 国美甄选', '22.90', ''),
(116, 'shop/product/product_3/product3_6.jpg', '维维冲饮代餐大豆豆奶粉560g 营养早餐非转基因大豆', '22.00', ''),
(117, 'shop/product/product_3/product3_7.jpg', '王饱饱酸奶果然多烘焙水果麦片即食燕麦片即食代餐懒人速食520g 代餐燕麦 谷物冲饮 早餐零食干吃', '62.90', ''),
(118, 'shop/product/product_3/product3_8.jpg', '康师傅香辣牛肉面五连包 和平精英吃鸡袋面泡面', '12.90', ''),
(119, 'shop/product/product_3/product3_9.jpg', '红牛维生素功能饮料250ml*24 整箱', '77.00', ''),
(120, 'shop/product/product_3/product3_10.jpg', '王老吉草本凉茶植物清凉饮料310ml*12 国美超市甄选', '35.90', ''),
(121, 'car/product/product_1/product1_1.jpg', '磐鼎P662A 1080P双录后视镜行车记录仪4.3英寸高清大屏 前后双镜头录像倒车时自动切换到倒车后视停车监控夜视后拉(官方标配无内存)', '169.00', ''),
(122, 'car/product/product_1/product1_2.jpg', '金字號H7后视镜行车记录仪高清星光夜视7英寸触摸大屏倒车影像停车监控一体机(标配 双镜头)', '238.00', ''),
(123, 'car/product/product_1/product1_3.jpg', '磐鼎 P616C 1200万相素小巧轻便高清1080P 行车记录仪 重力感映 循环录像 停车监控(单镜头带电子狗无内存)', '189.00', ''),
(124, 'car/product/product_1/product1_4.jpg', '磐鼎 P606 车载行车记录仪 锌合金机身 3寸屏单双镜头高清夜视倒车影像一体机(标配（无内存）)', '149.00', ''),
(125, 'car/product/product_1/product1_5.jpg', '磐鼎P663A超高清后视镜行车记录仪4.3英寸蓝镜 双镜头(官方标配无内存)', '159.00', ''),
(126, 'car/product/product_1/product1_6.jpg', '磐鼎 360度全景行车记录仪吸盘1080高清夜视360粘贴式车载监控仪循环录像(（标配+32G内存）)', '398.00', ''),
(127, 'car/product/product_1/product1_7.jpg', '磐鼎 行车记录仪电子狗一体机 安全预警仪固定流动雷达测速仪一键升级(标配（无内存）)', '239.00', ''),
(128, 'car/product/product_1/product1_8.jpg', '金字號H7行车记录仪(标配 双镜头)', '238.00', ''),
(129, 'car/product/product_1/product1_9.jpg', '磐鼎P8619 3G中控台行车记录仪导航仪双镜头高清夜视广角声控高德地图带电子狗倒车影像停车监控一体机(官方标配无内存)', '699.00', ''),
(130, 'car/product/product_1/product1_10.jpg', '磐鼎P666A四灯夜视电子狗记录仪后视镜行车记录仪后视镜电子狗行车记录仪重力感映停车监控1080P倒车后视行车记录仪(官方标配无内存)', '229.00', ''),
(131, 'car/product/product_2/product2_1.jpg', '乔氏汽车坐垫套新四季通用座垫迈腾凯美瑞帕萨特朗逸速腾坐垫-贝森(炫酷黑 十件套)', '328.00', ''),
(132, 'car/product/product_2/product2_2.jpg', '【下单备注车型号】2116 混纺麻时尚汽车四季坐垫 决明子亚麻汽车座垫 汽车用品(标准版咖色 材质)', '299.00', ''),
(133, 'car/product/product_2/product2_3.jpg', '【下单备注车型号】419混纺麻时尚汽车四季坐垫 亚麻汽车座垫 汽车用品(标准版红色 材质)', '277.00', ''),
(134, 'car/product/product_2/product2_4.jpg', '【下单备注车型】140丹尼皮冰丝夏季汽车坐垫 汽车用品 通用凉垫套座垫(豪华版橘色 材质)', '399.00', ''),
(135, 'car/product/product_2/product2_5.jpg', '【下单备注车型号】328高大帅 格调竹碳皮四季汽车坐垫座套 豪华座垫 汽车用品(豪华版黑色 材质)', '299.00', ''),
(136, 'car/product/product_2/product2_6.jpg', '【下单备注车型号】047丹尼皮四季通用汽车坐垫 竹碳夏季座垫汽车用品座椅套(豪华版米色 材质)', '318.00', ''),
(137, 'car/product/product_2/product2_7.jpg', '乔氏汽车坐垫套新四季通用座垫迈腾凯美瑞帕萨特朗逸速腾坐垫-贝森(浓情咖 十件套)', '328.00', ''),
(138, 'car/product/product_2/product2_8.jpg', '乔氏汽车坐垫套新四季通用座垫大众北京帕萨特朗逸速腾坐垫(汉欧-黑色 汉欧豪华款-六件套)', '458.00', ''),
(139, 'car/product/product_2/product2_9.jpg', '乔氏 汽车脚垫奥迪A4L宝骏730速腾昂科威crv卡罗拉迈腾轩逸哈弗H6丝圈脚垫(迪曼黑金皮-黑灰丝圈收纳)', '298.00', ''),
(140, 'car/product/product_2/product2_10.jpg', '乔氏防滑防震后备箱垫XPE环保汽车尾箱垫专车专用丰田福克斯途观朗逸凯越科鲁兹尾垫(雍森款【炫酷黑】下单留言车新年份)', '88.00', ''),
(141, 'car/product/product_3/product3_1.jpg', '燃油宝燃油添加剂除积碳高效多功能汽车发动机汽油添加剂燃油系统全方位清洗保护 盒装(六瓶*60ml)(1支装)', '18.00', ''),
(142, 'car/product/product_3/product3_2.jpg', '【劲牌MT-15】发动机烧机油高效修复剂消除烧机油冒蓝烟现象 全车系通用型机油添加剂(1支装)', '79.00', ''),
(143, 'car/product/product_3/product3_3.jpg', '劲牌汽油除水剂汽车油箱油路燃油添加剂清洗剂防止生锈防冻驱水剂清洁油箱清洗剂单支325ml(1支装)', '86.00', ''),
(144, 'car/product/product_3/product3_4.jpg', '固特威 碳霸5瓶装 燃油宝五瓶套装 辛烷提升剂 油路积碳清洗剂 燃油清净剂 喷油嘴除胶剂 三元清洗剂(1支装)', '79.00', ''),
(145, 'car/product/product_3/product3_5.jpg', '发动机保护剂燃油宝汽油燃油添加剂积碳净(其他 2支装)', '59.00', ''),
(146, 'car/product/product_3/product3_6.jpg', '巴什发动机动力还原液燃油宝除积碳清洁油路喷油嘴清洁提高燃烧效率350ML大容量1瓶顶5瓶(1支装)', '168.00', ''),
(147, 'car/product/product_3/product3_7.jpg', '巴什长效防冻液 发动机冷却液 -25 4升装 巴什石油出品 柴油汽油发动机通用 防冻 防沸 除水垢 清洁水箱(-25度 4L)', '88.00', ''),
(148, 'car/product/product_3/product3_8.jpg', '保赐利 螺栓松动剂(除锈灵)  螺丝松动剂 除锈剂', '14.80', ''),
(149, 'car/product/product_3/product3_9.jpg', '劲牌防止烧机油发动机添加剂引擎修复剂美国进口原液奥迪专用发动机保护剂缓解冒蓝烟 400ml(1支装)', '109.00', ''),
(150, 'car/product/product_3/product3_10.jpg', '标榜 表板蜡 仪表蜡 皮革护理 防尘去污蜡 抗氧化 450ml(柠檬味)', '12.00', '');

-- --------------------------------------------------------

--
-- 表的结构 `floor_sort`
--

CREATE TABLE `floor_sort` (
  `sort_id` int(11) NOT NULL,
  `sort_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_sort`
--

INSERT INTO `floor_sort` (`sort_id`, `sort_name`) VALUES
(1, '活动精选|新品速递|热销推荐|畅想低价'),
(2, '精品热卖|新品抢先|笔记本|摄影摄像'),
(3, '精选热卖|电视|洗衣机|冰箱'),
(4, '精选热卖|母婴玩具|美妆个护|食品饮料'),
(5, '精品热卖|车载电器|四季坐垫|添加剂');

-- --------------------------------------------------------

--
-- 表的结构 `floor_static`
--

CREATE TABLE `floor_static` (
  `static_id` int(11) NOT NULL,
  `static_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_static`
--

INSERT INTO `floor_static` (`static_id`, `static_img`) VALUES
(1, 'huawei.jpg'),
(2, '360.jpg'),
(3, 'kongtiao.jpg'),
(4, 'coffee.jpg'),
(5, 'tachograph.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `floor_title`
--

CREATE TABLE `floor_title` (
  `title_id` int(11) NOT NULL,
  `title_floor` varchar(10) NOT NULL,
  `title_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `floor_title`
--

INSERT INTO `floor_title` (`title_id`, `title_floor`, `title_name`) VALUES
(1, '1L', '手机通讯'),
(2, '2L', '电脑数码'),
(3, '3L', '家用电器'),
(4, '4L', '国美超市'),
(5, '5L', '汽车用品');

-- --------------------------------------------------------

--
-- 表的结构 `footer`
--

CREATE TABLE `footer` (
  `footer_id` int(11) NOT NULL,
  `footer_content` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `footer`
--

INSERT INTO `footer` (`footer_id`, `footer_content`) VALUES
(1, '国美控股集团|美锅优食|国美管家|关于国美|加入我们'),
(2, '品牌大全|商品专题|商品词|热词搜索|友情链接|风险监测'),
(3, '商家入驻|国美分销');

-- --------------------------------------------------------

--
-- 表的结构 `guesslike`
--

CREATE TABLE `guesslike` (
  `guesslike_id` int(11) NOT NULL,
  `guesslike_img` varchar(200) NOT NULL,
  `guesslike_name` varchar(200) NOT NULL,
  `guesslike_price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `guesslike`
--

INSERT INTO `guesslike` (`guesslike_id`, `guesslike_img`, `guesslike_name`, `guesslike_price`) VALUES
(1, 'list_1_1.jpg', '120克6桶大桶装正宗网红嗨吃酸辣粉红薯粉整箱泡面批发', '29.90'),
(2, 'list_1_2.jpg', 'Apple iPhone 12 128G 白色 移动联通电信 5G手机', '5799.00'),
(3, 'list_1_3.jpg', 'Apple iPhone 12 128G 黑色 移动联通电信 5G手机', '5799.00'),
(4, 'list_1_4.jpg', '纸护士本色卷纸1提*16卷', '10.00'),
(5, 'list_1_5.jpg', '爱恩倍薰衣草洗衣液2L/桶 无荧光剂 无增稠剂洗衣液 孕童通用洗衣液', '11.00'),
(6, 'list_1_6.jpg', '【4月产】蒙牛真果粒mini草莓125ml*7盒  散装', '11.00'),
(7, 'list_2_1.jpg', '佳洁士草本水晶牙膏清爽薄荷型140克*2支（新老包装随机发货） 清新口气 去牙渍', '11.00'),
(8, 'list_2_2.jpg', '舒肤佳红石榴香皂108克(新老包装随机发货） 深层排浊 洗澡 洗脸 留香', '11.00'),
(9, 'list_2_3.jpg', 'Apple iPhone 12 128G 绿色 移动联通电信 5G手机', '5799.00'),
(10, 'list_2_4.jpg', '洁饶2支云南三七植物牙膏去黄去牙垢炫白去渍口气清新家庭实惠装 双重薄荷105克1支+留兰香型105克1支 共2支(默认)', '11.00'),
(11, 'list_2_5.jpg', 'Apple iPhone 12 128G 蓝色 移动联通电信 5G手机', '5799.00'),
(12, 'list_2_6.jpg', 'Apple iPhone 12 128G 紫色 移动联通电信 5G手机', '5799.00');

-- --------------------------------------------------------

--
-- 表的结构 `help`
--

CREATE TABLE `help` (
  `help_id` int(11) NOT NULL,
  `help_title` varchar(10) NOT NULL,
  `help_content` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `help`
--

INSERT INTO `help` (`help_id`, `help_title`, `help_content`) VALUES
(1, '物流配送', '配送查询|配送服务|配送费用|配送时效|签收与验货'),
(2, '支付与账户', '货到付款|在线支付|分期付款|门店支付|发票制度'),
(3, '售后服务', '退换货服务|退款说明|专业维修|延保服务|家电回收'),
(4, '会员专区', '会员介绍|优惠券说明|美豆说明|商品评价'),
(5, '购物帮助', '购物保障|购物流程|促销优惠|焦点问题|联系我们');

-- --------------------------------------------------------

--
-- 表的结构 `hot_sale`
--

CREATE TABLE `hot_sale` (
  `sale_id` int(11) NOT NULL,
  `sale_img` varchar(200) NOT NULL,
  `sale_price` decimal(6,2) NOT NULL,
  `sale_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `hot_sale`
--

INSERT INTO `hot_sale` (`sale_id`, `sale_img`, `sale_price`, `sale_name`) VALUES
(1, 'hotsale/hot_sale1.jpg', '4798.00', 'Apple iPhone 11 128G 紫色 移动联通电信4G手机(新包装)'),
(2, 'hotsale/hot_sale2.jpg', '4798.00', 'Apple iPhone 11 128G 绿色 移动联通电信4G手机(新包装)'),
(3, 'hotsale/hot_sale3.jpg', '129.00', 'Apple 20W USB-C手机充电器插头 充电头 适用iPhone 12 iPad 快速充电'),
(4, 'hotsale/hot_sale4.jpg', '5299.00', '华为 HUAWEI Mate30E Pro(LIO-AN00m) 8GB+128GB 双卡双待 5G全网通 星河银'),
(5, 'hotsale/hot_sale5.jpg', '9597.00', 'Apple iPhone 12 Pro Max 256G 海蓝色 移动联通电信5G手机');

-- --------------------------------------------------------

--
-- 表的结构 `product_detail`
--

CREATE TABLE `product_detail` (
  `pd_id` int(11) NOT NULL,
  `comment` int(11) DEFAULT NULL,
  `praise` int(11) NOT NULL,
  `brand` varchar(10) NOT NULL,
  `lg_img` varchar(200) NOT NULL,
  `volume` int(11) NOT NULL,
  `news` tinyint(1) NOT NULL,
  `ziying` tinyint(1) NOT NULL,
  `goods` tinyint(1) NOT NULL,
  `shop_festival` tinyint(1) NOT NULL,
  `color` varchar(50) NOT NULL,
  `capacity` varchar(100) NOT NULL,
  `pid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `product_detail`
--

INSERT INTO `product_detail` (`pd_id`, `comment`, `praise`, `brand`, `lg_img`, `volume`, `news`, `ziying`, `goods`, `shop_festival`, `color`, `capacity`, `pid`) VALUES
(1, 24566, 97, '苹果', 'product/lg/lg1_1.jpg', 25799, 0, 1, 1, 0, '紫色|蓝色', '64G-7499|128G-7799|256G-7799', 1),
(2, 1811, 0, '苹果', 'product/lg/lg1_2.jpg', 1743, 1, 1, 1, 0, '紫色|绿色', '64G-5998|128G-6599|256G-6999', 2),
(3, 3428, 0, '红米', 'product/lg/lg1_3.jpg', 52, 0, 1, 1, 1, '砂石黑|晴空蓝', '2GB+32GB-4666|4GB+64GB-4998|4GB+128GB-5799', 3),
(4, 55, 0, '小米', 'product/lg/lg1_4.jpg', 76, 0, 0, 1, 1, '蓝色|白色', '8GB+128GB-4799|8GB+256GB-5099|12GB+256GB-5398', 4),
(5, 5040, 0, '', 'product/lg/lg1_5.jpg', 3027, 1, 0, 1, 1, '', '', 5),
(6, 419, 0, '', 'product/lg/lg1_6.jpg', 991, 1, 1, 1, 0, '', '', 6),
(7, 6708, 0, '', 'product/lg/lg1_7.jpg', 5050, 1, 0, 1, 1, '', '', 7),
(8, 3609, 0, '', 'product/lg/lg1_8.jpg', 2971, 0, 1, 1, 1, '', '', 8),
(9, 419, 0, '', 'product/lg/lg1_9.jpg', 3807, 0, 1, 1, 1, '', '', 9),
(10, 3571, 0, '', 'product/lg/lg1_10.jpg', 10, 1, 0, 1, 1, '', '', 10),
(11, 8954, 0, '', 'product/lg/lg2_1.jpg', 4497, 1, 0, 1, 0, '', '', 11),
(12, 7068, 0, '', 'product/lg/lg2_2.jpg', 2587, 0, 1, 1, 1, '', '', 12),
(13, 13717, 0, '', 'product/lg/lg2_3.jpg', 752, 0, 0, 1, 1, '', '', 13),
(14, 1011, 0, '', 'product/lg/lg2_4.jpg', 1688, 1, 0, 1, 1, '', '', 14),
(15, 14, 0, '', 'product/lg/lg2_5.jpg', 9887, 0, 1, 1, 0, '', '', 15),
(16, 32, 0, '', 'product/lg/lg2_6.jpg', 4532, 0, 1, 1, 1, '', '', 16),
(17, 2597, 0, '', 'product/lg/lg2_7.jpg', 2977, 0, 1, 1, 1, '', '', 17),
(18, 0, 0, '', 'product/lg/lg2_8.jpg', 0, 1, 1, 1, 1, '', '', 18),
(19, 97, 0, '', 'product/lg/lg2_9.jpg', 155, 0, 1, 1, 1, '', '', 19),
(20, 10213, 0, '', 'product/lg/lg2_10.jpg', 5799, 0, 1, 1, 1, '', '', 20),
(21, 423, 0, '', 'product/lg/lg3_1.jpg', 969, 1, 0, 1, 1, '', '', 21),
(22, 3479, 0, '', 'product/lg/lg3_2.jpg', 4732, 1, 0, 1, 0, '', '', 22),
(23, 2925, 0, '', 'product/lg/lg3_3.jpg', 1980, 1, 0, 1, 1, '', '', 23),
(24, 21, 0, '', 'product/lg/lg3_4.jpg', 22, 0, 0, 0, 0, '', '', 24),
(25, 19289, 0, '', 'product/lg/lg3_5.jpg', 10020, 0, 0, 1, 1, '', '', 25),
(26, 62, 0, '', 'product/lg/lg3_6.jpg', 75, 0, 0, 1, 1, '', '', 26),
(27, 275, 0, '', 'product/lg/lg3_7.jpg', 243, 1, 1, 1, 1, '', '', 27),
(28, 993, 0, '', 'product/lg/lg3_8.jpg', 960, 0, 0, 0, 0, '', '', 28),
(29, 5799, 0, '', 'product/lg/lg3_9.jpg', 4368, 0, 1, 1, 1, '', '', 29),
(30, 6003, 0, '', 'product/lg/lg3_10.jpg', 4396, 1, 0, 1, 1, '', '', 30);

-- --------------------------------------------------------

--
-- 表的结构 `product_detail_img`
--

CREATE TABLE `product_detail_img` (
  `pi_id` int(11) NOT NULL,
  `color1_sm` varchar(100) DEFAULT NULL,
  `color1_lg` varchar(100) DEFAULT NULL,
  `color1_xl` varchar(100) DEFAULT NULL,
  `color2_sm` varchar(100) DEFAULT NULL,
  `color2_lg` varchar(100) DEFAULT NULL,
  `color2_xl` varchar(100) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `product_detail_img`
--

INSERT INTO `product_detail_img` (`pi_id`, `color1_sm`, `color1_lg`, `color1_xl`, `color2_sm`, `color2_lg`, `color2_xl`, `pid`) VALUES
(1, 'color1_sm/sm1_1.jpg|color1_sm/sm1_2.jpg|color1_sm/sm1_3.jpg', 'color1_lg/lg1_1.jpg|color1_lg/lg1_2.jpg|color1_lg/lg1_3.jpg', 'color1_xl/xl1_1.jpg|color1_xl/xl1_2.jpg|color1_xl/xl1_3.jpg', 'color2_sm/sm1_1.jpg|color2_sm/sm1_2.jpg|color2_sm/sm1_3.jpg', 'color2_lg/lg1_1.jpg|color2_lg/lg1_2.jpg|color2_lg/lg1_3.jpg', 'color2_xl/xl1_1.jpg|color2_xl/xl1_2.jpg|color2_xl/xl1_3.jpg', 1),
(2, 'color1_sm/sm2_1.jpg|color1_sm/sm2_2.jpg|color1_sm/sm2_3.jpg', 'color1_lg/lg2_1.jpg|color1_lg/lg2_2.jpg|color1_lg/lg2_3.jpg', 'color1_xl/xl2_1.jpg|color1_xl/xl2_2.jpg|color1_xl/xl2_3.jpg', 'color2_sm/sm2_1.jpg|color2_sm/sm2_2.jpg|color2_sm/sm2_3.jpg', 'color2_lg/lg2_1.jpg|color2_lg/lg2_2.jpg|color2_lg/lg2_3.jpg', 'color2_xl/xl2_1.jpg|color2_xl/xl2_2.jpg|color2_xl/xl2_3.jpg', 2),
(3, 'color1_sm/sm3_1.jpg|color1_sm/sm3_2.jpg|color1_sm/sm3_3.jpg', 'color1_lg/lg3_1.jpg|color1_lg/lg3_2.jpg|color1_lg/lg3_3.jpg', 'color1_xl/xl3_1.jpg|color1_xl/xl3_2.jpg|color1_xl/xl3_3.jpg', 'color2_sm/sm3_1.jpg|color2_sm/sm3_2.jpg|color2_sm/sm3_3.jpg', 'color2_lg/lg3_1.jpg|color2_lg/lg3_2.jpg|color2_lg/lg3_3.jpg', 'color2_xl/xl3_1.jpg|color2_xl/xl3_2.jpg|color2_xl/xl3_3.jpg', 3),
(4, 'color1_sm/sm4_1.jpg|color1_sm/sm4_2.jpg|color1_sm/sm4_3.jpg', 'color1_lg/lg4_1.jpg|color1_lg/lg4_2.jpg|color1_lg/lg4_3.jpg', 'color1_xl/xl4_1.jpg|color1_xl/xl4_2.jpg|color1_xl/xl4_3.jpg', 'color2_sm/sm4_1.jpg|color2_sm/sm4_2.jpg|color2_sm/sm4_3.jpg', 'color2_lg/lg4_1.jpg|color2_lg/lg4_2.jpg|color2_lg/lg4_3.jpg', 'color2_xl/xl4_1.jpg|color2_xl/xl4_2.jpg|color2_xl/xl4_3.jpg', 4);

-- --------------------------------------------------------

--
-- 表的结构 `product_parameter`
--

CREATE TABLE `product_parameter` (
  `pp_id` int(11) NOT NULL,
  `body` varchar(100) NOT NULL,
  `os` varchar(10) NOT NULL,
  `network` varchar(10) NOT NULL,
  `memory` varchar(100) NOT NULL,
  `screen` varchar(20) NOT NULL,
  `camera` varchar(100) NOT NULL,
  `img` varchar(250) NOT NULL,
  `store_img` varchar(100) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `product_parameter`
--

INSERT INTO `product_parameter` (`pp_id`, `body`, `os`, `network`, `memory`, `screen`, `camera`, `img`, `store_img`, `pid`) VALUES
(1, '苹果(APPLE)|iPhone 12|00-8573-208663', 'ios', '双卡双待', '64GB-256GB|4GB-8GB', '6.1英寸|1792 x 828', '1200 万像素超广角及广角|1200 万像素超广角及广角|支持', 'params/bigimg/params1_1.jpg|params/bigimg/params1_2.jpg|params/bigimg/params1_3.jpg|params/bigimg/params1_4.jpg|params/bigimg/params1_5.jpg|params/bigimg/params1_6.jpg|params/bigimg/params1_7.jpg|params/bigimg/params1_8.jpg', 'params/storeimg/apple_store.jpg', 1),
(2, '苹果(APPLE)|iPhone 11|00-8573-197724', 'ios', '双卡双待', '64GB-256GB|4GB-8GB', '6.1 英寸|1792 x 828', '1200 万像素超广角及广角|1200 万像素超广角及广角|支持', 'params/bigimg/params2_1.jpg|params/bigimg/params2_2.jpg|params/bigimg/params2_3.jpg|params/bigimg/params2_4.jpg|params/bigimg/params2_5.jpg|params/bigimg/params2_6.jpg|params/bigimg/params2_7.jpg|params/bigimg/params2_8.jpg', 'params/storeimg/apple_store.jpg', 2),
(9, '红米(Redmi)|红米9A|00-3575-152456', '安卓', '双卡双待', '32GB-128GB|2GB-6GB', '6.55英寸|1840 x 950', '6400万像素+800万像素+500万像素|2000万像素|支持', 'params/bigimg/params3_1.jpg|params/bigimg/params3_2.jpg|params/bigimg/params3_3.jpg|params/bigimg/params3_4.jpg|params/bigimg/params3_5.jpg|params/bigimg/params3_6.jpg|params/bigimg/params3_7.jpg|params/bigimg/params3_8.jpg', 'params/storeimg/xiaomi_store.png', 3),
(10, '小米(MI)|小米10S|00-B324-218046', '安卓', '双卡双待', '128GB-256GB|8GB-12GB', '6.7英寸|1880 x 970', '6400万像素+800万像素+500万像素|2000万像素|支持', 'params/bigimg/params4_1.jpg|params/bigimg/params4_2.jpg|params/bigimg/params4_3.jpg|params/bigimg/params4_4.jpg|params/bigimg/params4_5.jpg|params/bigimg/params4_6.jpg|params/bigimg/params4_7.jpg|params/bigimg/params4_8.jpg', 'params/storeimg/xiaomi_store.png', 4);

-- --------------------------------------------------------

--
-- 表的结构 `recommend`
--

CREATE TABLE `recommend` (
  `recom_id` int(11) NOT NULL,
  `recom_img` varchar(200) NOT NULL,
  `recom_name` varchar(200) NOT NULL,
  `recom_price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `recommend`
--

INSERT INTO `recommend` (`recom_id`, `recom_img`, `recom_name`, `recom_price`) VALUES
(1, 'recommend/recom1_1.jpg', '【4月产】蒙牛真果粒mini草莓125ml*7盒  散装', '11.00'),
(2, 'recommend/recom1_2.jpg', '120克6桶大桶装正宗网红嗨吃酸辣粉红薯粉整箱泡面批发', '29.90'),
(3, 'recommend/recom1_3.jpg', '爱恩倍薰衣草洗衣液2L/桶 无荧光剂 无增稠剂洗衣液 孕童通用洗衣液', '11.00'),
(4, 'recommend/recom1_4.jpg', 'Apple iPhone 12 128G 白色 移动联通电信 5G手机', '5707.00'),
(5, 'recommend/recom1_5.jpg', '纸护士本色卷纸1提*16卷', '10.00'),
(6, 'recommend/recom2_1.jpg', '正宗嗨吃家网红酸辣粉102g*6桶(其他 共同)', '11.00'),
(7, 'recommend/recom2_2.jpg', '心相印【真选定制】心相印薰衣草系列100抽*6包 湿水不易破', '11.00'),
(8, 'recommend/recom2_3.jpg', 'Apple iPhone 12 128G 黑色 移动联通电信 5G手机', '5707.00'),
(9, 'recommend/recom2_4.jpg', 'Apple iPhone 12 128G 紫色 移动联通电信 5G手机', '5707.00'),
(10, 'recommend/recom2_5.jpg', '洁饶2支云南三七植物牙膏去黄去牙垢炫白去渍口气清新家庭实惠装 双重薄荷105克1支+留兰香型105克1支 共2支(默认)', '11.00');

-- --------------------------------------------------------

--
-- 表的结构 `region`
--

CREATE TABLE `region` (
  `region_id` int(11) NOT NULL,
  `re_province` varchar(10) NOT NULL,
  `re_city` varchar(200) NOT NULL,
  `re_dis_cou` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `region`
--

INSERT INTO `region` (`region_id`, `re_province`, `re_city`, `re_dis_cou`) VALUES
(1, '黑龙江省', '哈尔滨市|佳木斯市|齐齐哈尔市|牡丹江市', '道里区,南岗区,香坊区,平房区|前进区,东风区,向阳区,郊区|龙沙区,建华区,铁锋区,昂昂溪区|东安区,阳明区,爱民区,西安区'),
(2, '吉林省', '长春市|白城市|白山市|四平市', '南关区,宽城区,二道区,绿园区|洮北区,通榆县,洮南市,大安市|浑江区,抚松县,靖宇县,长白县|铁西区,铁东区,梨树县,伊通县'),
(3, '辽宁省', '沈阳市|鞍山市|本溪市|朝阳市', '和平区,沈河区,大东区,皇姑区|立山区,千山区,台安县,海城市|平山区,溪湖区,明山区,南芬区|双塔区,龙城区,建平县,北票市');

-- --------------------------------------------------------

--
-- 表的结构 `relevant_sort`
--

CREATE TABLE `relevant_sort` (
  `r_id` int(11) NOT NULL,
  `r_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `relevant_sort`
--

INSERT INTO `relevant_sort` (`r_id`, `r_name`) VALUES
(1, '合约机|手机服务|对讲机|手机|二手手机'),
(2, '苹果(APPLE)|三星|华为|小米(MI)|索尼(SONY)|摩托罗拉|联想(lenovo)|诺基亚|HTC|中兴(ZTE)|酷派|天语(K-touch)|macoox|努比亚|OPPO|步步高|飞利浦|朵唯(DOOV)|魅族(MEIZU)|金立');

-- --------------------------------------------------------

--
-- 表的结构 `roll`
--

CREATE TABLE `roll` (
  `roll_id` int(11) NOT NULL,
  `roll_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `roll`
--

INSERT INTO `roll` (`roll_id`, `roll_img`) VALUES
(1, 'roll1.jpg'),
(2, 'roll2.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `today_list`
--

CREATE TABLE `today_list` (
  `list_id` int(11) NOT NULL,
  `list_oldPrice` decimal(6,2) NOT NULL,
  `list_newPrice` decimal(6,2) NOT NULL,
  `list_name` varchar(200) NOT NULL,
  `list_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `today_list`
--

INSERT INTO `today_list` (`list_id`, `list_oldPrice`, `list_newPrice`, `list_name`, `list_img`) VALUES
(1, '129.00', '96.00', '帮宝适一级帮拉拉裤XL40片', 'list_1_1.jpg'),
(2, '180.00', '146.00', '诺优能4段800克 1罐', 'list_1_2.jpg'),
(3, '46.00', '39.00', '嘉宝米粉(燕麦) 250克', 'list_1_3.jpg'),
(4, '282.00', '190.00', '雅培亲护3段820克 1罐(820g)', 'list_1_4.jpg'),
(5, '129.00', '92.00', '帮宝适一级帮L码52片', 'list_2_1.jpg'),
(6, '73.00', '62.00', '帮宝适拉拉裤L码52片', 'list_2_2.jpg'),
(7, '139.00', '99.00', '美的（Midea）电炖锅迷你全自动BB煲汤煮粥锅隔水电炖盅陶瓷电砂锅 MD-DG05E101 粉红色', 'list_2_3.jpg'),
(8, '98.00', '72.00', '雀巢怡养中老年850克1罐', 'list_2_4.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `tomorrow_list`
--

CREATE TABLE `tomorrow_list` (
  `list_id` int(11) NOT NULL,
  `list_oldPrice` decimal(6,2) NOT NULL,
  `list_newPrice` decimal(6,2) NOT NULL,
  `list_name` varchar(200) NOT NULL,
  `list_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tomorrow_list`
--

INSERT INTO `tomorrow_list` (`list_id`, `list_oldPrice`, `list_newPrice`, `list_name`, `list_img`) VALUES
(1, '899.00', '649.00', '法格（FAGOR）多功能锅多用途锅料理火锅烤肉蒸炒烧烤煎涮烤一体家用不粘烤肉锅分离式电烤锅BBC-912P1(天青色)', 'list_3_1.jpg'),
(2, '370.00', '304.00', '皇家美素佳儿800g(三段（1-3周岁）)', 'list_3_2.jpg'),
(3, '269.00', '209.00', '东菱烧水壶电热水壶水瓶开水壶家用便携式保温自动断电旅行加热烧水杯网红DL-B1(粉色)', 'list_3_3.jpg'),
(4, '20.00', '8.90', '清风3条30包原木纯品手帕纸 3层8张/包迷你型手帕纸 方便携带', 'list_3_4.jpg'),
(5, '8.90', '7.90', '溢流香松花皮蛋无铅工艺皮蛋50g-60g(4枚)', 'list_4_1.jpg'),
(6, '18.50', '14.50', '宝湘坊 腊鸭腿500g湖南特产烟熏腊鸭腿农家传统手工腌制风味咸鸭腿肉腌鸭腿', 'list_4_2.jpg'),
(7, '10.90', '8.90', '双汇火炫风刻花香肠48g*4支辣味香肠脆骨肠即食小零食', 'list_4_3.jpg'),
(8, '168.00', '158.00', '家奈（GENE by HIROSE）XJ-130 超声波香薰机 小型加湿器 香薰灯室内静音 圆环款', 'list_4_4.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`uid`, `username`, `password`, `phone`) VALUES
(1, 'zhangsan', '123456', '18846760332'),
(2, 'lisi', '654321', '15928939681'),
(4, 'wangwu', 'kimjun', '13234546183'),
(5, 'zhaoliu', 'kimjnn', '19182205106'),
(7, 'damiemie', 'xiaomiemie', '19199110764');

-- --------------------------------------------------------

--
-- 表的结构 `user_shopping`
--

CREATE TABLE `user_shopping` (
  `us_id` int(11) NOT NULL,
  `us_img` varchar(200) NOT NULL,
  `us_name` varchar(200) NOT NULL,
  `us_price` decimal(6,2) NOT NULL,
  `us_count` int(11) NOT NULL,
  `us_color` varchar(10) NOT NULL,
  `us_capacity` varchar(10) NOT NULL,
  `us_guarantee` varchar(100) NOT NULL,
  `us_stages` varchar(100) NOT NULL,
  `us_db` varchar(100) NOT NULL,
  `us_dbi` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `browselike`
--
ALTER TABLE `browselike`
  ADD PRIMARY KEY (`browse_id`);

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`carousel_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `category_content`
--
ALTER TABLE `category_content`
  ADD PRIMARY KEY (`content_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`coupons_id`);

--
-- Indexes for table `floor_bg`
--
ALTER TABLE `floor_bg`
  ADD PRIMARY KEY (`bg_id`);

--
-- Indexes for table `floor_brand`
--
ALTER TABLE `floor_brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `floor_channel`
--
ALTER TABLE `floor_channel`
  ADD PRIMARY KEY (`channel_id`);

--
-- Indexes for table `floor_keywords`
--
ALTER TABLE `floor_keywords`
  ADD PRIMARY KEY (`keyword_id`);

--
-- Indexes for table `floor_model`
--
ALTER TABLE `floor_model`
  ADD PRIMARY KEY (`model_id`);

--
-- Indexes for table `floor_product`
--
ALTER TABLE `floor_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `floor_sort`
--
ALTER TABLE `floor_sort`
  ADD PRIMARY KEY (`sort_id`);

--
-- Indexes for table `floor_static`
--
ALTER TABLE `floor_static`
  ADD PRIMARY KEY (`static_id`);

--
-- Indexes for table `floor_title`
--
ALTER TABLE `floor_title`
  ADD PRIMARY KEY (`title_id`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`footer_id`);

--
-- Indexes for table `guesslike`
--
ALTER TABLE `guesslike`
  ADD PRIMARY KEY (`guesslike_id`);

--
-- Indexes for table `help`
--
ALTER TABLE `help`
  ADD PRIMARY KEY (`help_id`);

--
-- Indexes for table `hot_sale`
--
ALTER TABLE `hot_sale`
  ADD PRIMARY KEY (`sale_id`);

--
-- Indexes for table `product_detail`
--
ALTER TABLE `product_detail`
  ADD PRIMARY KEY (`pd_id`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `product_detail_img`
--
ALTER TABLE `product_detail_img`
  ADD PRIMARY KEY (`pi_id`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `product_parameter`
--
ALTER TABLE `product_parameter`
  ADD PRIMARY KEY (`pp_id`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `recommend`
--
ALTER TABLE `recommend`
  ADD PRIMARY KEY (`recom_id`);

--
-- Indexes for table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`region_id`);

--
-- Indexes for table `relevant_sort`
--
ALTER TABLE `relevant_sort`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `roll`
--
ALTER TABLE `roll`
  ADD PRIMARY KEY (`roll_id`);

--
-- Indexes for table `today_list`
--
ALTER TABLE `today_list`
  ADD PRIMARY KEY (`list_id`);

--
-- Indexes for table `tomorrow_list`
--
ALTER TABLE `tomorrow_list`
  ADD PRIMARY KEY (`list_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `user_shopping`
--
ALTER TABLE `user_shopping`
  ADD PRIMARY KEY (`us_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `browselike`
--
ALTER TABLE `browselike`
  MODIFY `browse_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- 使用表AUTO_INCREMENT `carousel`
--
ALTER TABLE `carousel`
  MODIFY `carousel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- 使用表AUTO_INCREMENT `category_content`
--
ALTER TABLE `category_content`
  MODIFY `content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- 使用表AUTO_INCREMENT `coupons`
--
ALTER TABLE `coupons`
  MODIFY `coupons_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `floor_bg`
--
ALTER TABLE `floor_bg`
  MODIFY `bg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `floor_brand`
--
ALTER TABLE `floor_brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- 使用表AUTO_INCREMENT `floor_channel`
--
ALTER TABLE `floor_channel`
  MODIFY `channel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `floor_keywords`
--
ALTER TABLE `floor_keywords`
  MODIFY `keyword_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- 使用表AUTO_INCREMENT `floor_model`
--
ALTER TABLE `floor_model`
  MODIFY `model_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- 使用表AUTO_INCREMENT `floor_product`
--
ALTER TABLE `floor_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;
--
-- 使用表AUTO_INCREMENT `floor_sort`
--
ALTER TABLE `floor_sort`
  MODIFY `sort_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `floor_static`
--
ALTER TABLE `floor_static`
  MODIFY `static_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `floor_title`
--
ALTER TABLE `floor_title`
  MODIFY `title_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `footer`
--
ALTER TABLE `footer`
  MODIFY `footer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `guesslike`
--
ALTER TABLE `guesslike`
  MODIFY `guesslike_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- 使用表AUTO_INCREMENT `help`
--
ALTER TABLE `help`
  MODIFY `help_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `hot_sale`
--
ALTER TABLE `hot_sale`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `product_detail`
--
ALTER TABLE `product_detail`
  MODIFY `pd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- 使用表AUTO_INCREMENT `product_detail_img`
--
ALTER TABLE `product_detail_img`
  MODIFY `pi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `product_parameter`
--
ALTER TABLE `product_parameter`
  MODIFY `pp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- 使用表AUTO_INCREMENT `recommend`
--
ALTER TABLE `recommend`
  MODIFY `recom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- 使用表AUTO_INCREMENT `region`
--
ALTER TABLE `region`
  MODIFY `region_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `relevant_sort`
--
ALTER TABLE `relevant_sort`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `roll`
--
ALTER TABLE `roll`
  MODIFY `roll_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `today_list`
--
ALTER TABLE `today_list`
  MODIFY `list_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `tomorrow_list`
--
ALTER TABLE `tomorrow_list`
  MODIFY `list_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `user_shopping`
--
ALTER TABLE `user_shopping`
  MODIFY `us_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- 限制导出的表
--

--
-- 限制表 `category_content`
--
ALTER TABLE `category_content`
  ADD CONSTRAINT `category_content_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`cid`);

--
-- 限制表 `product_detail`
--
ALTER TABLE `product_detail`
  ADD CONSTRAINT `product_detail_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `floor_product` (`product_id`);

--
-- 限制表 `product_detail_img`
--
ALTER TABLE `product_detail_img`
  ADD CONSTRAINT `product_detail_img_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `floor_product` (`product_id`);

--
-- 限制表 `product_parameter`
--
ALTER TABLE `product_parameter`
  ADD CONSTRAINT `product_parameter_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `floor_product` (`product_id`);

--
-- 限制表 `user_shopping`
--
ALTER TABLE `user_shopping`
  ADD CONSTRAINT `user_shopping_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`uid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
