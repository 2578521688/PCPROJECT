<template>
  <div class="not-found">
    <div class="top">
      <div class="tips">
        <p class="sorry">抱歉，您请求的页面现在无法打开</p>
        <p class="back">
          您可以
          <router-link to="/">返回首页</router-link>
        </p>
      </div>
    </div>
    <div class="content">
      <div class="content_top">
        <p>为您推荐</p>
      </div>
      <div class="content_bottom">
        <ul v-for="(rp,ri) of recommend" :key="ri" v-show="recom_chose == ri">
          <li v-for="p of rp" :key="p.recom_id">
            <router-link to="" :title="p.recom_name">
              <img :src="`img/${p.recom_img}`">
              <p class="name">{{p.recom_name}}</p>
              <p class="price">&yen;{{p.recom_price.toFixed(2)}}</p>
            </router-link>
          </li>
        </ul>
        <a href="javascript:;" @click="pageDown">换一组</a>
      </div>
    </div>
  </div>
</template>

<style>
  .not-found{
    width: 990px;
    margin: 0 auto;
  }
  .not-found .top{
    height: 450px;
    background: url('../../public/img/static/notFound.png') center;
    position: relative;
  }
  .not-found .top .tips{
    width: 400px;
    color: #383838;
    position: absolute;
    top: 175px; right: 50px;
  }
  .not-found .top .tips .sorry{
    font: 700 24px/40px "Microsoft Yahei";
  }
  .not-found .top .tips .back{
    margin-top: 12px;
    font: 15px/21px "Microsoft Yahei";
  }
  .not-found .top .tips .back a{
    color: #06c;
    margin-left: 8px;
  }
  .not-found .top .tips .back a:hover{
    color: #c00;
    text-decoration: underline;
  }
  .not-found .content{
    /* 距离页脚 */
    margin-bottom: 10px;
  }
  .not-found .content .content_top{
    font: 17px/31px "Microsoft Yahei";
    margin-bottom: 8px;
  }
  .not-found .content .content_bottom{
    /* 990-2px边框  高度不是继承来的，不计算 */
    width: 988px; height: 227px;
    border: 1px solid #e0e0e0;
    position: relative;
  }
  .not-found .content .content_bottom>a{
    position: absolute;
    top: 10px; right: 10px;
    color: #000;
  }
  .not-found .content .content_bottom>a:hover{
    color: #e3101e;
  }
  .not-found .content .content_bottom ul{
    /* width:988-88 height:227-60  */
    width: 900px; height: 167px;
    position: absolute;
    top: 0; left: 0;
    margin: 30px 44px;
  }
  .not-found .content .content_bottom ul>li{
    float: left;
    width: 160px;
    margin: 0 10px;
  }
  .not-found .content_bottom ul>li a{
    display: block;
    width: 160px; height: 167px;
  }
  .not-found .content_bottom ul>li a:hover .name{
    color: #b20fd3;
    text-decoration: underline;
  }
  .not-found .content_bottom ul>li img{
    display: block;
    width: 100px; height: 100px;
    margin-left: 30px;
  }
  .not-found .content_bottom ul>li .name{
    height: 36px;
    overflow: hidden;
    color: #5e5e5e;
    margin: 10px 0 0 15px;
  }
  .not-found .content_bottom ul>li .price{
    color: #e3101e;
    font-size: 14px;
    margin: 5px 0 0 15px;
  }
</style>

<script>
export default {
  data(){
    return {
      recommend:[],
      recommend_1:[],
      recommend_2:[],
      recom_chose:0
    }
  },
  methods:{
    pageDown(){
      this.recom_chose = this.recom_chose==0? 1 : 0;
    }
  },
  mounted(){
    this.axios.get('/v1/products/recommend').then(res=>{
      for(var obj of res.data){
        if(this.recommend_1.length!=5){
          this.recommend_1.push(obj);
        }else{
          this.recommend_2.push(obj);
        }
      }
      this.recommend.push(this.recommend_1);
      this.recommend.push(this.recommend_2);
    })
  }
}
</script>