<template>
  <div class="details">
    <div class="breadcrumb">
      <div class="content">
        <div class="left fl">
          <ul class="clearfix">
            <li v-for="(p,i) of breadcrumb" :key="i" class="fl">
              <router-link to="" :title="p">{{p}}</router-link>
            </li>
          </ul>
        </div>
        <div class="right fr">
          <div class="carrier clearfix">
            <router-link to="" class="fl">
              {{brand}}官方旗舰店<span class="self-operated">自营</span>
            </router-link>
            <router-link to="" class="fl">
              <i class="customer-service same"></i>在线客服
            </router-link>
            <router-link to="" class="fl">
              <i class="collection same"></i>收藏店铺
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <div class="container clearfix">
      <div class="left fl">
        <div class="pic-big same">
          <img :src="lg_href">
          <div class="pic-bigger same" v-show="mask_xl_show">
            <img :src="xl_href" :style="xl_move">
          </div>
          <!-- 小放大镜图标 -->
          <div class="small-magnifier-icon" v-show="!mask_xl_show"></div>
          <!-- 小遮罩层 -->
          <div class="mask" v-show="mask_xl_show" :style="mask_move"></div>
          <!-- 大遮罩层，在此绑定事件，防止鼠标进入小遮罩层时，小遮罩层隐藏 -->         <!-- 鼠标移动事件 -->  <!-- 防止数据没有响应回来之前，触发magnifier方法 -->
          <div class="super-mask" @mouseenter="magnifier" @mouseleave="mask_xl_hide" @mousemove="move" v-show="color_arr.length != 0"></div>
        </div>
        <div class="pic-list"> <!-- mouseenter不支持冒泡，改用mouseover即可 -->
          <ul class="clearfix" @mouseover="sm_change">
            <li v-for="(p,i) of color_arr[0]" :key="i" class="fl"> <!-- li：@mouseenter="sm_change(i)" 所有li都用同一个事件，改为事件委托 -->
              <router-link to="">
                <img :src="`img/color/${p}`" :class="{active: sm_chose == i}" :data-i="i">
              </router-link>
            </li>
          </ul>
        </div>
        <div class="toolbar clearfix">
          <span class="p-number">商品编号：100674396</span>
          <router-link to="" class="wish">
            <i></i>提心愿
          </router-link>
          <router-link to="" class="collect">
            <i></i>收藏
          </router-link>
        </div>
      </div>
      <div class="right fl">
        <div class="head">
          <p class="name">{{pname}}</p>
          <p class="tagging">&lt;由于活动火爆，会延迟发货&gt;&lt;门店自提/门店员工配送订单，需现场激活&gt;</p>
        </div>
        <div class="price clearfix">
          <div class="line-34 justify fl">
            零售价<span></span>
          </div>
          <div class="unit-price fl line-34">
            <p class="fl"><em class="line-34">&yen;</em>{{ca_price[ca_chose]}}</p>
            <router-link to="" class="reduce-price line-34 fl">降价通知</router-link>
          </div>
          <div class="tail fr">
            <p>好评率{{praise.toFixed(1)}}%</p>
            <p class="comment">{{comment_data}}条评价</p>
          </div>
        </div>
        <div class="properties">
          <div class="tese clearfix">
            <div class="justify line-20 fl">
              特色<span></span>
            </div>
            <div class="content fl">
              <div class="yijiuhuanxin radius fl">
                <i></i>
                <router-link to="">以旧换新特划算</router-link>
              </div>
              <div class="guanjiafuwu radius fl">
                <i></i>
                <router-link to="">管家服务</router-link>
              </div>
              <div class="guomiezhineng radius fl">
                <i></i>
                <router-link to="">国美智能</router-link>
              </div>
            </div>
          </div>
          <div class="songzhi clearfix">
            <div class="justify fl line-30">
              送至<span></span>
            </div>
            <div class="content fl">
              <div class="fl carrier">
                <div class="region" :class="{ border: region_chose == 1 }">
                  <a href="javascript:;" @click="open_region_list">
                    {{region_name}}<i class="drop-down" :class="{ rotate:region_chose == 1 }"></i>
                  </a>
                </div>
                <div class="region-list" v-show="region_chose == 1">
                  <div class="select-list">
                    <a href="javascript:;" v-for="(p,i) of pcd_arr" :key="i" class="fl same" :class="{ active: select_arr[i] == 1 }"
                    v-show="select_show[i] == 1" @click="change_region(i)">
                    {{p}}<i class="drop-down" :class="{ rotate: select_arr[i] == 1 }"></i></a>
                    <a href="javascript:;" class="close fr" @click="open_region_list"></a>
                  </div>
                  <div class="select-box clearfix">
                    <a href="javascript:;" class="fl" v-for="(p,i) of region_arr" :key="i"
                    @click="next_region(p,i)">{{p}}</a>
                  </div>
                </div>
              </div>
              <div class="has-stock fl line-30">有货</div>
              <div class="zhichi fl color-888 line-30">
                支持<span>免运费</span>
              </div>
            </div>
          </div>
          <div class="yanse clearfix">
            <div class="justify line-38 fl">
              颜色<span></span>
            </div>
            <div class="content line-38 fl">
              <a href="javascript:;" class="fl same-a" :class="{active: color_chose == i}" 
                 v-for="(p,i) of color" :key="i"
                 @click="change_color(i)">
                {{p}}<i class="selected" v-show="color_chose == i"></i>
              </a>
            </div>
          </div>
          <div class="rongliang clearfix">
            <div class="justify line-38 fl">
              容量<span></span>
            </div>
            <div class="content line-38 fl">
              <a href="javascript:;" class="fl same-a" :class="{active: ca_chose == i}"
                 v-for="(p,i) of capacity" :key="i"
                 @click="change_ca(i)">
                {{p}}<i class="selected" v-show="ca_chose == i"></i>
              </a>
            </div>
          </div>
          <div class="yanbaofuwu clearfix">
            <div class="line-42 fl color-888">延保服务</div>
            <div class="content fl">
              <a href="javascript:;" class="fl" :class="{active: yanbao_chose == 0}" @click="change_yanbao(0)">
                <img src="img/static/yanbaofuwu1.png">
                延保一年<span>&yen;219.0</span>
                <i v-show="yanbao_chose == 0" class="selected"></i>
              </a>
              <a href="javascript:;" class="fl" :class="{active: yanbao_chose == 1}" @click="change_yanbao(1)">
                <img src="img/static/yanbaofuwu2.png">
                碎屏+延长保1年<span>&yen;380.0</span>
                <i v-show="yanbao_chose == 1" class="selected"></i>
              </a>
              <div class="more fl" @mouseenter="change_tip(0)" @mouseleave="change_tip(0)">
                <div class="tips" v-show="tip_chose[0] == 1">
                  <div class="tips-body">
                    <p>凡是在真快乐平台购买的家安保服务，在保障期间内遇到无论是正常使用中的问题还是意外事故，即可享受国美家安保服务。国美家安保内容包括：延长保修、只换不修、屏碎保护、意外保护、服务保障。覆盖家电、手机数码、电脑办公等商品。</p>
                    <p class="shengming">如有疑问，请与<router-link to="">在线客服</router-link>联系</p>
                  </div>
                  <div class="sanjiao"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="guomeifenqi clearfix">
            <div class="line-38 fl color-888">国美分期</div>
            <div class="content fl">
              <div class="fl carrier" @mouseleave="fenqi_hide">
                <div class="fenqi" :class="{border: fenqi_list == 1}" @mouseenter="fenqi_show">
                  <a href="javascript:;" class="fl">
                    {{fenqi_chose}}<i class="drop-down" :class="{ rotate: fenqi_list == 1 }"></i>
                  </a>
                </div>
                <div class="fenqi-list" v-show="fenqi_list == 1">
                  <div @click="change_fenqi_chose(3)">
                    <p class="tip">¥ 1808.72 x 3期</p>
                    <p class="service-charge color-888">含手续费：费率14.34/年%，¥ 42.39 x 3期</p>
                  </div>
                  <div @click="change_fenqi_chose(6)">
                    <p class="tip">¥ 922.91 x 6期</p>
                    <p class="service-charge color-888">含手续费：费率15.27/年%，¥ 39.74 x 6期</p>
                  </div>
                  <div @click="change_fenqi_chose(12)">
                    <p class="tip">¥ 478.67 x 12期</p>
                    <p class="service-charge color-888">含手续费：费率15.16/年%，¥ 37.09 x 12期</p>
                  </div>
                  <div @click="change_fenqi_chose(24)">
                    <p class="tip">¥ 257.88 x 24期</p>
                    <p class="service-charge color-888">含手续费：费率15.38/年%，¥ 37.09 x 24期</p>
                  </div>
                  <div @click="change_fenqi_chose"> 
                    <p class="tip">不分期</p>
                    <p class="service-charge color-888">有钱任性</p>
                  </div>
                </div>
              </div>
              <div class="more fl" @mouseenter="change_tip(1)" @mouseleave="change_tip(1)">
                <div class="tips" v-show="tip_chose[1] == 1">
                  <div class="tips-body">
                    <p>国美分期是国美为您提供的集聚消费、现金功能于一体的信用额度产品，当您使用国美分期进行消费时，可选择延期付款或分期付款。</p>
                  </div>
                  <div class="sanjiao"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="buy clearfix">
          <div class="count fl">
            <input type="text" class="fl" v-model="buy_count" @input="num_valid">
            <!-- 行内块不会被浮动元素压在下面 -->
            <button @click="add" :class="{b_disabled: buy_count == 99}">+</button>
            <button :class="{b_disabled: buy_count == 1}" @click="sub">-</button>
            <div class="limit" v-show="buy_count == 99">
              <div class="sanjiao"></div>
              您最多能购买99件
            </div>
          </div>                                  <!-- router-link触发事件必须要.native -->
          <router-link to="" class="fl add-cart" @click.native="shop_tran">加入购物车</router-link>
          <a href="javascript:;" class="fl phone-order" @mouseenter="change_QR" @mouseleave="change_QR">
            <i></i>手机下单
            <img src="img/static/item.png" v-show="QR_chose == 1">
          </a>
        </div>
        <div class="reminder clearfix color-888 line-20">
          <p class="fl">温馨提示</p>
          <ol class="fl">
            <li>7天无理由退货(拆封/激活后不支持);正品保障;</li>
            <li>支持企业采购</li>
          </ol>
        </div>
      </div>
    </div>
    <!-- 相似商品 -->
    <similar :kw="kw"></similar>   
    <div class="popup-mask" v-show="popup_show == 1">
      <div class="popup">
        <a href="javascript:;" @click="popup_close"></a>
        <div class="popup-body">
          <p class="same-p" v-show="is_login == 1">请先登录</p>
          <p class="same-p" v-show="is_address == 1">请填写收货地址</p>
          <img src="img/static/item2.png">
          <p class="saoyisao">扫一扫，开启美好之旅</p>
        </div>
      </div>
    </div>
    <!-- 商品参数 -->
    <parameter :pid="pid"></parameter>
  </div>
</template>

<style>
  .details .pic-list li .active,
  .details .properties .same-a:hover,
  .details .properties .content .active,
  .details .yanbaofuwu .content>a:hover{
    border-color: #e3101e;
  }
  .details .breadcrumb{
    background: #f6f6f6;
    margin-bottom: 16px;
  }
  .details .breadcrumb .content{
    width: 1200px; height: 42px;
    line-height: 42px;
    margin: 0 auto;
  }
  .details .content a{
    color: #5e5e5e;
  }
  .details .content a:hover{
    color: #e3101e;
  }
  .details .content .left li:not(:last-child)::after{
    content: '';
    display: inline-block;
    width: 7px; height: 11px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat;
    margin: 0 8px;
    vertical-align: middle;
  }
  .details .content .right .carrier{
    padding: 10px 0;
  }
  .details .content .right a{
    /* 42-20 = 22 */
    height: 22px;
    line-height: 22px;
  }
  .details .content .right a+a{
    margin-left: 20px;
  }
  .details .content .right .self-operated{
    padding: 2px 4px;
    background: #e3101e;
    color: #fff;
    font-size: 12px;
    margin-left: 5px;
  }
  .details .content .right .same{
    display: inline-block;
    margin-right: 5px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -167px;
    vertical-align: middle;
  }
  .details .content .right .customer-service{
    width: 21px; height: 21px;
  }
  .details .content .right .collection{
    width: 16px; height: 17px;
    background-position: 0 -100px;
  }
  .details .container{
    width: 1200px;
    margin: 0 auto;
  }
  .details .container .left{
    width: 452px;
  }
  .details .left .same{
    width: 450px; height: 450px;
    border: 1px solid #D9D9D9;
  }
  .details .left .pic-big{
    position: relative;
  }
  .details .pic-big .pic-bigger{
    position: absolute;
    /* 边框不重叠 */
    top: -1px; left: 451px;
    overflow: hidden;
    z-index: 99;
  }
  .details .pic-big .small-magnifier-icon{
    width: 24px; height: 24px;
    position: absolute;
    right: 0; bottom: 0;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -800px;
  }
  .details .pic-big .mask{
    width: 200px; height: 200px;
    background: #ccc;
    opacity: .3;
    position: absolute;
    top: 0; left: 0;
  }
  .details .pic-big .super-mask{
    width: 450px; height: 450px;
    position: absolute;
    top: 0; left: 0;
    /* cursor url必须是绝对路径开头加/：默认找public目录 , auto：如果没有自定义光标，则用浏览器默认光标 */
    cursor: url('/img/static/mouse.cur'),auto;
  }
  .details .left .pic-list{
    margin: 20px 0 16px;
  }
  .details .pic-list li{
    width: 62px; height: 62px;
    margin-right: 25px;
  }
  .details .pic-list li img{
    display: block;
    border: 1px solid #fff;
  }
  .details .left .toolbar{
    width: 450px; height: 18px;
    line-height: 18px;
  }
  .details .toolbar .p-number{
    float: left;
    width: 135px;
    color: #5e5e5e;
  }
  .details .toolbar a{
    float: right;
    color: #5e5e5e;
    margin-left: 12px;
  }
  .details .toolbar i{
    display: inline-block;
    vertical-align: middle;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2325px;
    margin-right: 5px;
  }
  .details .toolbar .wish i{
    width: 14px; height: 14px;
  }
  .details .toolbar .collect i{
    width: 16px; height: 17px;
    background-position: 0 -100px;
  }
  .details .container .right{
    width: 718px;
    margin-left: 30px;
  }
  .details .right .head{
    margin-bottom: 16px;
    padding-top: 5px;
  }
  .details .right .head .name{
    font-size: 16px;
    color: #5e5e5e;
    font-weight: 600;
    height: 26px;
    line-height: 26px;
  }
  .details .right .head .tagging{
    color: #e3101e;
    height: 20px;
    line-height: 20px;
  }
  .details .right .price{
    width: 690px;
    padding: 20px 10px 18px 20px;
    background: #f6f6f6;
  }
  .details .justify{
    width: 48px;
    color: #888;
    text-align: justify;
    box-sizing: border-box;
  }
  .details .justify span{
    display: inline-block;
    padding-left: 100%;
  }
  .details .right .price .line-34{
    height: 34px;
    line-height: 34px;
  }
  .details .right .unit-price{
    margin-left: 15px;
    color: #e3101e;
  }
  .details .right .unit-price p{
    font-size: 24px;
    font-weight: 700;
  }
  .details .right .unit-price em{
    font-style: normal;
    font-size: 16px;
    margin-right: 2px;
    float: left;
  }
  .details .right .unit-price .reduce-price{
    color: #069;
    margin-left: 10px;
  }
  .details .right .price .tail{
    width: 100px; height: 34px;
    border-left: 1px solid #ccc;
    color: #5e5e5e;
  }
  .details .price .tail p{
    margin-left: 20px;
    line-height: 17px;
  }
  .details .price .tail .comment{
    color: #069;
  }
  .details .right .properties{
    margin-top: 20px;
    padding-left: 20px;
  }
  .details .right .properties>div:not(:first-child){
    margin-top: 15px;
  }
  .details .right .line-20{
    height: 20px;
    line-height: 20px;
  }
  .details .properties .content,
  .details .properties .tese .radius+.radius{
    margin-left: 15px;
  }
  .details .properties .tese .radius{
    height: 18px;
    line-height: 18px;
    border: 1px solid #61819f;
    border-top-left-radius: 9px;
    border-bottom-left-radius: 9px;
    padding-left: 16px;
    position: relative;
  }
  .details .properties .tese .radius a{
    color: #61819f;
    padding: 0 5px;
  }
  .details .properties .tese .radius a:hover{
    color: #e3101e; /* content a:hover 会跟上面的a进行权值比较，所以我们再自己写一个a:hover */
  }
  .details .properties .drop-down{
    position: absolute;
    width: 10px; height: 6px;
    top: 4px; right: 5px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -632px;
    transition: .2s ease-in .1s;
  }
  .details .properties .rotate{
    transform: rotate(180deg);
  }
  .details .tese i{
    position: absolute;
    left: 1px; top: 1px;
    width: 16px; height: 16px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2560px;
  }
  .details .tese .guanjiafuwu i{
    background-position: 0 -2638px;
  }
  .details .tese .guomeizhineng i{
    background-position: 0 -2586px;
  }
  .details .songzhi .line-30{
    height: 30px;
    line-height: 30px;
  }
  .details .songzhi .carrier{
    position: relative;
  }
  .details .songzhi .region{
    border: 1px solid #fff;
    padding: 5px 10px;
    position: relative;
    z-index: 10;
    background: #fff;
  }
  .details .songzhi .region a{
    position: relative;
    padding-right: 21px;
  }
  .details .songzhi .region-list{
    position: absolute;
    top: 28px; left: 0;
    width: 390px;
    background: #fff;
    z-index: 9;
    border: 1px solid #dedede;
    padding: 10px;
  }
  .details .songzhi .region-list .select-list{
    border-bottom: 1px solid #e6e6e6;
    height: 27px;
    line-height: 27px;
  }
  .details .songzhi .select-list .same{
    border: 1px solid #fff;
    border-bottom-color: #e6e6e6;
    height: 25px;
    line-height: 25px;
    padding: 0 20px 0 10px;
    position: relative;
    bottom: -1px;
    z-index: 1;
  }
  .details .songzhi .select-list .active{
    color: red;
    border-color: #e6e6e6;
    border-bottom-color: #fff;
  }
  .details .songzhi .select-list .active i{
    color: red;
  }
  .details .songzhi .select-list .drop-down{
    top: 9px; right: 5px;
  }
  .details .songzhi .select-list .close{
    width: 12px; height: 12px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -664px;
  }
  .details .songzhi .region-list .select-box{
    margin-top: 10px;
    padding-left: 10px;
  }
  .details .songzhi .select-box a{
    width: 95px; height: 26px;
    line-height: 26px;
  }
  .details .songzhi .content>div:not(:first-child){
    margin-left: 20px;
  }
  .details .songzhi .has-stock{
    color: #5e5e5e;
  }
  .details .songzhi .zhichi span{
    margin: 0 10px;
    color: #61819f;
  }
  .details .right .properties .line-38{
    height: 38px;
    line-height: 38px;
  }
  .details .properties .same-a + .same-a{
    margin-left: 7px;
  }
  .details .properties .same-a{
    padding: 0 10px;
    height: 36px;
    line-height: 36px;
    position: relative;
    border: 1px solid #ccc;
    text-align: center;
  }
  .details .properties .selected{  /* i */
    position: absolute;
    width: 11px; height: 11px;
    bottom: 0; right: 0;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2664px;
  }
  .details .yanbaofuwu img{
    image-rendering: -webkit-optimize-contrast; /* 解决图片缩放时造成的模糊 */
  }
  .details .yanbaofuwu .line-42{
    height: 42px;
    line-height: 42px;
  }
  .details .yanbaofuwu .content>a{
    padding: 11px 8px 11px 30px;
    position: relative;
    border: 1px solid #ccc;
  }
  .details .yanbaofuwu .content>a+a{
    margin-left: 7px;
  }
  .details .yanbaofuwu span{
    margin-left: 5px;
  }
  .details .yanbaofuwu img{
    width: 17px; height: 17px;
    position: absolute;
    top: 11px; left: 8px;
  }
  .details .properties .more{
    position: relative;
    width: 16px; height: 16px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2299px;
    /* 42 - 16 = 26 / 2 = 13 */
    margin: 13px 0 13px 7px;
    cursor: pointer;
  }
  .details .properties .more .tips{
    position: absolute;
    width: 274px;
    top: -13px; left: 22px;
    color: #5e5e5e;
  }
  .details .properties .more .tips-body{
    line-height: 22px;
    border: 1px solid #ccc;
    padding: 10px;
    cursor: default;
  }
  .details .properties .more .shengming{
    margin-top: 10px;
    border-top: 1px solid #bebebe;
    padding-top: 10px;
  }
  .details .properties .more .shengming a{
    margin: 0 3px;
    color: #069;
  }
  .details .properties .more .shengming a:hover{
    text-decoration: underline;
  }
  .details .properties .more .sanjiao{
    position: absolute;
    width: 18px; height: 12px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2508px;
    top: 14px; left: -6px;
    z-index: 11;
  }
  .details .right .color-888{
    color: #888;
  }
  .details .guomeifenqi .carrier{
    position: relative;
    width: 250px;
  }
  .details .guomeifenqi .fenqi{
    padding: 0 21px 0 8px;
    background: #fff;
    position: relative;
    z-index: 20;
    border: 1px solid #fff;
    height: 36px;
    line-height: 36px;
  }
  .details .right .border{
    border-color: #dedede;
    border-bottom: 0;
  }
  .details .guomeifenqi .drop-down{
    top: 15px; right: 5px;
  }
  .details .guomeifenqi .fenqi-list{
    /* 250 - 8(padd) - 2(bord)*/
    width: 240px;
    position: absolute;
    top: 37px; left: 0;
    z-index: 10;
    border: 1px solid #dedede;
    border-top: 0;
    padding: 0 0 10px 8px;
    background: #fff;
  }
  .details .guomeifenqi .fenqi-list>div{
    margin-top: 12px;
    cursor: pointer;
  }
  .details .guomeifenqi .fenqi-list .tip{
    color: #5e5e5e;
    height: 17px; 
    line-height: 17px;
    margin-bottom: 3px;
  }
  .details .guomeifenqi .fenqi-list .service-charge{
    line-height: 12px;
  }
  .details .guomeifenqi .more{
    /* 38 - 16 = 22 / 2 = 11*/
    margin: 11px 0 11px 7px;
  }
  .details .right .buy{
    margin: 34px 0 10px;
    padding-left: 20px;
    height: 42px;
  }
  .details .buy .count{
    width: 46px; height: 38px;
    border: 1px solid #ccc;
    position: relative;
  }
  .details .buy .count input{
    width: 32px; height: 38px;
    line-height: 38px;
    color: #5e5e5e;
    text-align: center;
    border: 0; outline: 0;
  }
  .details .buy .count button{
    width: 13px; height: 18px;
    line-height: 18px;
    border: 1px solid #ccc;
    border-right: 0; border-top: 0;
    text-align: center;
    color: #5e5e5e;
    font-size: 12px;
    background: #f8f8f8;
    cursor: pointer;
    /* button 默认 border-box */
    box-sizing: content-box;
  }
  .details .buy .count .b_disabled{
    color: #ccc;
    cursor: not-allowed;
    border-bottom: 0;
    /* 底部差1px，补上 */
    padding-bottom: 1px;
  }
  .details .buy .count .limit{
    position: absolute;
    top: -40px; right: -74px;
    box-shadow: 0 0 8px rgba(0, 0, 0, .2);
    border: 1px solid #e1e1e1;
    padding: 7px 10px;
    font-weight: 500;
    color: #5e5e5e;
    background: #fff;
    z-index: 21;
  }
  .details .buy .count .sanjiao{
    position: absolute;
    top: 32px;  left: 30px;
    border: 8px solid transparent;
    border-top-color: #fff;
  }
  .details .buy .add-cart{
    font-size: 18px;
    width: 140px; height: 40px;
    line-height: 40px;
    background: #e3101e;
    margin: 0 15px;
    color: #fff;
    text-align: center;
  }
  .details .buy .add-cart:hover{
    background: #d7000f;
  }
  .details .buy .phone-order{
    width: 100px; height: 38px;
    line-height: 38px;
    color: #5e5e5e;
    border: 1px solid #ccc;
    position: relative;
  }
  .details .buy .phone-order i{
    display: inline-block;
    width: 27px; height: 30px;
    margin: 0 8px 0 6px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2815px;
    vertical-align: middle;
  }
  .details .buy .phone-order img{
    position: absolute;
    width: 100px;
    border: 1px solid #ccc;
    border-top: 0;
    top: 38px; left: -1px;
  }
  .details .right .reminder p,
  .details .right .reminder ol{
    padding-left: 18px;
  }
  .details .popup-mask{
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, .5);
    z-index: 9998;
  }
  .details .popup-mask .popup{
    /* 儿子永远压着爹，不写z-index也可以 */
    width: 363px; height: 433px;
    position: fixed;
    top: 50%; left: 50%;
    margin-top: -216px;
    margin-left: -181px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2852px;
  }
  .details .popup .popup-body{
    padding: 110px 53px 86px 59px;
    text-align: center;
  }
  .details .popup a{
    position: absolute;
    width: 14px; height: 14px;
    top: 78px; right: 63px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -3305px;
  }
  .details .popup .same-p{
    font-size: 24px;
    color: #000;
  }
  .details .popup img{
    vertical-align: middle;
    margin: 8px 0 5px;
  }
  .details .popup .saoyisao{
    font-size: 16px;
    height: 36px;
    line-height: 36px;
    color: #555;
  }
</style>

<script>
import similar from '../components/Similar.vue';
import parameter from '../components/Parameter.vue';
import { mapState,mapMutations } from 'vuex';
export default {
  components:{ similar,parameter },
  props:["pid","kw","comment","pname"],
  data(){
    return {
      breadcrumb:['首页','商品列表'], // 面包屑
      capacity:[],    // 容量
      ca_price:[],    // 不同容量对应价格
      ca_chose:0,     // 当前选择容量
      color_chose:0,  // 当前选中颜色
      color_arr:[],   // 当前遍历颜色数组
      color:[],       // 颜色
      color1_img:[],  // 颜色1对应图片
      color2_img:[],  // 颜色2对应图片
      praise:0,       // 好评
      brand:'',       // 品牌
      sm_chose:0,     // 当前选中的小图
      lg_href:'',     // 当前小图对应的大图
      xl_href:'',     // 当前大图对应的超大图
      mask_xl_show:false,   // 控制超大图、遮罩层的显示隐藏
      mask_move:{ left:0, top:0 },    // 通过鼠标控制小遮罩层的移动
      xl_move:{ 'margin-left':0 , 'margin-top':0 },  // 通过鼠标控制超大图的移动
      comment_data:0,  // 评论数(替代props中的comment)
      yanbao_chose:-1, // 当前选中的延保服务
      tip_chose:[0,0], // 是否打开？提示框
      fenqi_list:0,    // 是否打开分期列表
      fenqi_chose:'【国美分期支付】 0首付 30天免息 0利率',
      buy_count:1,     // 购买数量
      QR_chose:0,      // 是否打开二维码
      region_chose:0,  // 是否打开地区选择列表
      province:[],     // 省份列表（一维数组）
      city:[],         // 城市列表（二维数组）
      dis_cou:[],      // 区县列表（三维数组）
      region_arr:[],   // 当前遍历的地区列表
      pcd_arr:['请选择','请选择','请选择'], // 当前选择的省市县地区名称
      pcd_i:[-1,-1,-1],   // 当前选择的省市县地区名称下标
      select_arr:[1,0,0], // 用于给当前选择的省市县名称添加active类
      region_name:'请选择您的收货地址',  // 具体名称
      select_show:[1,0,0],// 用于控制当前选择的省市县名称的显示隐藏
      is_address:0,    // 是否写收货地址
      is_login:0,      // 是否登录
      popup_show:0     // 没登录 或 没填写收货地址，弹出窗口
    }
  },
  methods:{
    ...mapMutations(["isInclude"]),

    sm_change(e){
      if(e.target.nodeName == "IMG"){
        // 获取自定义属性
        this.sm_chose = e.target.dataset.i;
      }
    },
    magnifier(){
      this.xl_href = `img/color/${this.color_arr[2][this.sm_chose]}`;
      this.mask_xl_show = true;
    },
    mask_xl_hide(){
      this.mask_xl_show = false;
    },
    move(e){
      // 保证光标在小遮罩层的中间，所以减去小遮罩层的一半，不然光标会在遮罩层左上角
      let left  = e.offsetX - 100;
      let top = e.offsetY - 100;
      // 防止小遮罩层 溢出 大遮罩层    (总宽度-小遮罩层宽度 450-200)
      if(left<0) left = 0; else if(left>250) left = 250;
      if(top<0) top = 0; else if(top>250) top = 250;
      this.mask_move = {left:left+'px',top:top+'px'};
      // 移动超大图
      /* 
        大img(800) - 大div(450) = 350(大img最多移动像素)
        super-mask(450) - mask(200) = 250(mask最多移动像素)
        350 / 250 = 1.4 (mask每移动1像素，大img移动1.4像素)
      */
      this.xl_move = {
        'margin-left': `-${parseInt(left*1.4)}px`,
        'margin-top' : `-${parseInt(top*1.4)}px`
      }
    },
    // 评价简写
    short_comment(comment_data){
      // 取出最高位数字
      let num = comment_data.toString().slice(0,1);
      if(comment_data>9999){
        this.comment_data = `${num}万+`;
      }else if(comment_data>999){
        this.comment_data = `${num}千+`;
      }
    },
    open_region_list(){
      this.region_chose = !this.region_chose;
      // 每次打开地区选择列表时，先判断是否已经选择完毕，如果已完毕，要直接切换到 选中区县 状态（省份和城市不用判断，因为不选择到区县，我们不会在页面上显示出来）
      if(this.region_name != '请选择您的收货地址'){
        this.select_arr = [0,0,1];  // 给区县列表添加active类
      }
    },
    change_color(i){
      this.color_chose = i;
    },
    change_ca(i){
      this.ca_chose = i;
    },
    change_yanbao(n){
      if(this.yanbao_chose == 0 && n == 0 || this.yanbao_chose == 1 && n == 1){
        this.yanbao_chose = -1;
      }else{
        this.yanbao_chose = n;
      }
    },
    change_tip(i){
      this.$set(this.tip_chose,i,!this.tip_chose[i]);
    },
    /* 为什么不写一个方法，直接this.fenqi_list = !this.fenqi_list? bug：在不按照顺序反复进入fenqi和fenqi-list时，你会发现fenqi_chose的值会颠倒，移出隐藏，移入显示，变成了移入隐藏，移出显示 */
    fenqi_show(){
      this.fenqi_list = 1;
    },
    fenqi_hide(){
      this.fenqi_list = 0;
    },
    change_fenqi_chose(num){
      let str = ''
      if(num == 3){
        str = '¥ 1808.72 x 3期';
      }else if(num == 6){
        str = '¥ 922.91 x 6期';
      }else if(num == 12){
        str = '¥ 478.67 x 12期';
      }else if(num == 24){
        str = '¥ 257.88 x 24期';
      }else{
        str = '【国美分期支付】 0首付 30天免息 0利率';
      }
      this.fenqi_chose = str;
      this.fenqi_list = 0;
    },
    add(){
      if(this.buy_count < 99){
        this.buy_count++;
      }
    },
    sub(){
      if(this.buy_count!=1){
        this.buy_count--;
      }
    },
    change_QR(){
      this.QR_chose = !this.QR_chose;
    },
    change_region(index){
      // 给当前点击的地区列表添加class类
      this.$set(this.select_arr,index,1);
      // 当前点击的地区列表
      if(index==0){ 
        // 省份
        this.region_arr = this.province;
      }else if(index == 1){
        // 城市                      // 当前省份
        this.region_arr = this.city[this.pcd_i[0]];
      }else if(index == 2){
        // 区县                         // 当前省份    当前城市
        this.region_arr = this.dis_cou[this.pcd_i[0]][this.pcd_i[1]]
      }
      // 去除其余列表的class类
      this.select_arr.forEach((ele,i)=>{
        if(i!=index){
          this.$set(this.select_arr,i,0);
        }
      })
    },
    next_region(p,pi){
      let index = -1;
      // 先遍历，看看当前选择的地区列表是哪个
      this.select_arr.forEach((ele,i)=>{
        if(ele == 1) index = i;
      })
      // 如果我们要重新选省份，会先把原来的城市和区县列表重置
      if(index == 0){
        this.select_arr = [1,0,0];
        this.select_show = [1,0,0];
        this.$set(this.pcd_arr,1,'请选择');
        this.$set(this.pcd_arr,2,'请选择');
      }
      // 清除当前列表的active类
      this.$set(this.select_arr,index,0);
      // 更新地区名称,下标 及 列表
      this.$set(this.pcd_arr,index,p);
      this.$set(this.pcd_i,index,pi);
      if(index!=this.select_arr.length-1){
        this.$set(this.select_arr,index+1,1); // 添加active类
        this.$set(this.select_show,index+1,1);// 地区列表显示
      }
      // 遍历新的数组
      if(index == 0){
        // 遍历城市 0+1 = 1
        this.region_arr = this.city[pi];
      }else if(index == 1){
        // 遍历区县 1+1 = 2            // 当前所选省份
        this.region_arr = this.dis_cou[this.pcd_i[0]][pi];
      }else if(index == 2){
        // 拼接成完整的地区名称，显示在页面上
        this.region_name = '';
        for(let str of this.pcd_arr){
          this.region_name += str;
        }
        // 关闭地区选择列表
        this.region_chose = 0;
      }
    },
    shop_tran(){
      // 先判断是否登录
      if(this.loginState != 1){
        // 没登陆
        this.is_login = 1;
        this.popup_show = 1;
        return;
      }else if(this.region_name == '请选择您的收货地址'){
        // 没填写收获地址
        this.is_address = 1;
        this.popup_show = 1;
        return;
      }

      let obj = {
        us_img: `color/${this.color_arr[1][0]}`,
        us_name: this.pname,
        us_price: this.ca_price[this.ca_chose],
        us_count: this.buy_count,
        us_color: this.color[this.color_chose],
        us_capacity: this.capacity[this.ca_chose],
        us_guarantee: this.yanbao_chose==0? '延长保1年¥219.0' : this.yanbao_chose == 1? '碎屏+延长保1年¥380.0' : '',
        us_stages: this.fenqi_chose,
        us_db: `${this.pcd_arr[0]}|${this.pcd_arr[1]}|${this.pcd_arr[2]}`,  // 配送地址   distribution
        us_dbi: `${this.pcd_i[0]}|${this.pcd_i[1]}|${this.pcd_i[2]}`        // 省市县对应的下标 distribution_i
      }
      // 添加进数据库（我们再写一个是否包含的方法，vuex的isInclude不能使用return返回数据，主要用于操作state中的变量，因此我们在该组件下也写一个）
      // 这里一定要先添加进数据库，不然遍历vuex时，数据直接重复，导致误加商品数量
      let resObj = this.isIncludeObj(obj);
      if(resObj != undefined){
        // 已存在，我们数量叠加
        // 数量 = 原数量 + 新数量
        let quantity = resObj.us_count + obj.us_count;
        let guarantee = obj.us_guarantee.replace('+','%2B');
        this.axios.put('/v1/products/quantity_superposition',
        // 由于属性不同的同一种商品，无法通过us_pid进行判断，所以我们只能传递5个参数 商品名、容量、颜色、延保、分期 到后台进行判断
        `quantity=${quantity}&name=${obj.us_name}&capacity=${obj.us_capacity}&color=${obj.us_color}&guarantee=${
        guarantee}&stages=${obj.us_stages}&uid=${this.uid}&code=1`).then(res=>{
          if(res.data == 1){
            console.log(`数据库商品数量已更新`);
          }
        })
      }else{
        // 不存在，添加商品
        // 前端传入+号到后台会变成空格 所以需要转换为%2B +号的编码
        let guarantee = obj.us_guarantee.replace('+','%2B');
        this.axios.post('/v1/products/save_commodity',
        `us_img=${obj.us_img}&us_name=${obj.us_name}&us_price=${obj.us_price}&us_count=${obj.us_count}&us_color=${obj.
        us_color}&us_capacity=${obj.us_capacity}&us_guarantee=${guarantee}&us_stages=${obj.
        us_stages}&us_db=${obj.us_db}&us_dbi=${obj.us_dbi}&user_id=${this.uid}`).then(res=>{
          if(res.data == 1){
            console.log(`数据库商品已更新`);
          }
        })
      }
      // 添加进vuex
      this.isInclude(obj);
      // 再跳转到购物车中转站
      let xiegang = this.color_arr[1][0].indexOf('/');    // color1_lg/lg1_1.jpg
      let lg_pic_prefix = this.color_arr[1][0].slice(0,xiegang);    // color1_lg
      let lg_pic_suffix = this.color_arr[1][0].slice(xiegang+1,-4)  // lg1_1（既用于中转站也用于购物车）
      this.$router.push(`/sctransfer/${lg_pic_prefix}/${lg_pic_suffix}/${this.pname}/${this.buy_count}/${this.kw}`);
    },
    isIncludeObj(object){
      for(let obj of this.shoppingCartList){
        // 我们比较商品名、容量、颜色、延保、分期
        if(obj.us_name == object.us_name && obj.us_capacity == object.us_capacity && obj.us_color == object.us_color && obj.us_guarantee == object.us_guarantee && obj.us_stages == object.us_stages){
          // 说明包含（如果遍历结束后，仍没有符号if条件，那么返回undefined）
          return obj;
        }
      }
    },
    popup_close(){
      // 关闭弹窗
      this.popup_show = 0;
    },
    // 控制input框只能输入数字
    num_valid(e){
      /* 这里不传入并使用buy_count而选择事件对象的原因是：事件对象可以监听到中文输入法，当你输入一串中文并没有按下enter时，
        拼音会出现在input框内，但是v-model不会把这串拼音传递给data中的变量，因此我们就无法监听到这串拼音，导致调用string.replace函数时报is not a function的错误，
        因为data中的变量仍是一个数值型，但是事件对象可以监听到这串拼音！ */
      let str = e.target.value;
      this.buy_count = Number(str.replace(/[^\d]/g,''));
    }
  },
  watch:{
    sm_chose(newValue){
      this.lg_href = `img/color/${this.color_arr[1][newValue]}`;
    },
    color_chose(newValue){
      // 切换颜色，把小图初始化
      this.sm_chose = 0;
      // 先清空
      this.color_arr = [];
      this.color_arr = newValue == 0? this.color1_img : this.color2_img;
      // 图片初始化
      this.lg_href = `img/color/${this.color_arr[1][0]}`;
      this.xl_href = `img/color/${this.color_arr[2][0]}`;
    },
    buy_count(newValue){
      // 如果用户把数量给backspace删除了，则恢复成1
      if(newValue == 0){
        this.buy_count = 1;
      }else if(newValue > 99){
        // 用户购买商品数量不能超过99
        this.buy_count = 99;
      }
    }
  },
  computed:{
    ...mapState(["loginState","shoppingCartList","uid"])
  },
  mounted(){
    // 把关键字和商品名追加到导航中
    this.breadcrumb.splice(1,0,this.kw);
    this.breadcrumb.push(this.pname);
    // 获取商品详细数据
    this.axios.get('/v1/products/get_detail',{
      params:{
        pid:this.pid
      }
    }).then(res=>{
      let data = res.data[0];
      // 获取容量及对应价格
      let capacity = data.capacity.split('|');
      for(let str of capacity){
        let index = str.indexOf('-');
        this.capacity.push(str.slice(0,index));
        this.ca_price.push(str.slice(index+1));
      }
      // 获取颜色及对应图片
      this.color = data.color.split('|');
      let arr1 = [data.color1_sm , data.color1_lg , data.color1_xl];
      for(let str of arr1){
        this.color1_img.push(str.split('|'));
      }
      let arr2 = [data.color2_sm , data.color2_lg , data.color2_xl];
      for(let str of arr2){
        this.color2_img.push(str.split('|'));
      }
      // 默认遍历第一种颜色数组
      this.color_arr = this.color1_img;
      this.lg_href = `img/color/${this.color_arr[1][0]}`;
      this.xl_href = `img/color/${this.color_arr[2][0]}`;
      // 获取好评
      this.praise = data.praise;
      // 获取品牌
      this.brand = data.brand;
    })
    // vue不推荐直接修改 props中父组件传递过来的参数，我们先把该值，传递给一个替代变量，之后再修改。
    this.comment_data = this.comment;
    this.short_comment(this.comment_data);
    // 获取 省市县(区)
    this.axios.get('/v1/products/get_region').then(res=>{
      for(let str of res.data){
        // 获取省份列表
        this.province.push(str.re_province);
        // 获取城市列表
        let city = str.re_city.split('|');
        this.city.push(city);
        // 获取区县列表
        let dc_arr = [];
        let dis_cou = str.re_dis_cou.split('|');
        for(let str of dis_cou){
          let dc = str.split(',');
          dc_arr.push(dc);
        }
        this.dis_cou.push(dc_arr);
      }
      // 默认遍历省份
      this.region_arr = this.province;
    })
  }
}
</script>