<template>
  <div class="p-list clearfix">
    <!-- 数据挂载的时候都隐藏，请求以后再做判断 -->
    <div class="left" v-show="this.search_result == 1">
      <p>热销推荐</p>
      <ul>
        <li v-for="p of hot_sale" :key="p.sale_id">
          <router-link to="" :title="p.sale_name">
            <img :src="`img/${p.sale_img}`">
            <p class="price">&yen;{{p.sale_price.toFixed(2)}}</p>
            <p class="name">{{p.sale_name}}</p>
          </router-link>
        </li>
      </ul>
    </div>
    <div class="right" v-show="this.search_result == 1">
      <div class="filter-box">
        <div class="filter-top">
          <ul class="clearfix">                                                            
            <li v-for="(p,i) of filter_sort" :key="i" :class="{ active: filter_chose == i }" @click="select(i)">
              <router-link to="">{{p}}</router-link>
            </li>
            <li :class="{ active: filter_chose == 4 , price: seqencing == 0||seqencing == 1 , price_cover: seqencing == 1  }" @click="select(4)">
              <router-link to="">价格</router-link>
              <i></i>
            </li>
          </ul>
        </div>
        <div class="filter-bottom">
          <ul>
            <li v-for="(p,i) of check_sort" :key="i" class="filter-check" :class="{ filter_check_chose: check_chose[i] == 1 }">
              <input v-model="selected_items" type="checkbox" :name="p.name" :id="p.id" :value="p.value" @click="chose(i)"><label :for="p.id">{{p.content}}</label>
            </li>                                  <!-- label标签不需要写v-model和click事件，我们点击label时，会自动调用input上的click事件以及v-model -->
          </ul>                                    <!-- 这里不直接给li一个click，而拆开分开给的原因是，li继承了行高，有空白的地方，点上去会触发css，但是v-model不会接到数据 -->
        </div>
      </div>
      <div class="product-box">
        <div class="reveal">
          以下是<b>{{kw}} - {{filter_chose==0? '综合':filter_chose==1? '销量':filter_chose==2? '新品':filter_chose==3? '评价':seqencing==0? '价格(升序)':'价格(降序)'}}
          - {{check_chose_name}}</b>的搜索结果，共<b>{{page_count}}</b>个商品
        </div>
        <ul class="clearfix">
          <li v-for="p of product_list" :key="p.product_id" @mouseenter="option_change(p.product_id)" @mouseleave="option_change">
            <router-link :to="`${p.product_href}/${kw}/${p.comment}/${p.product_name}`" :title="p.product_name">
              <img :src="`img/${p.lg_img}`">
              <p class="price">
                &yen;{{p.product_price.toFixed(2)}}
                <span class="describe" v-show="p.news == 1">新品</span>
                <span class="describe" v-show="p.goods == 0">无货</span>
              </p>
              <p class="name" v-html="p.p_name"></p>
              <p class="count">
                <span>已售<b>{{p.volume}}</b>个商品</span>
                <span>已有<b>{{p.comment}}</b>人评价</span>
              </p>
              <p class="ziying" :class="{ visibility: p.ziying == 1 }">自营</p>
            </router-link>
            <p class="option clearfix" :class="{ visibility: option_chose == p.product_id}">
              <span class="fl" title="对比"><i></i></span>
              <span class="fl" title="收藏"><i></i></span>
              <span class="fl" title="加入购物车"><i></i></span>
              <span class="fl" title="在线客服"><i></i></span>
            </p>
          </li>
        </ul>
        <div class="page clearfix">
          <ul>
            <li class="prev-page" :class="{ pnDisable: page_chose == 1 }" @click="prev">
              <i class="prev-icon"></i>
              上一页
            </li>
            <!-- 数据等于2页时，只显示第1页和最后1页 -->
            <li v-show="page==2" :class="{ pDisable: page_chose == page_start }" @click="page_change(page_start)">{{page_start}}</li>
            <!-- 数据大于2页时，只显示前2页和最后1页 -->
            <li v-show="page>2" v-for="page_start of 2" :key="page_start" :class="{ pDisable: page_chose == page_start }" @click="page_change(page_start)">
              {{page_start}}
            </li>
            <!-- 用省略号代替中间的页 -->
            <li v-show="page>2" class="ellipsis"></li>
            <!-- 最后1页（数据小于2页时，只显示最后1页） -->
            <li :class="{ pDisable: page_chose == page }" @click="page_change(page)">{{page}}</li>
            <li class="next-page" :class="{ pnDisable: page_chose == page }" @click="next">
              下一页
              <i class="next-icon"></i>
            </li>
          </ul>
          <div class="skip-page">
            <span>到</span>
            <input v-model="skip_page" type="text" @input="num_valid">
            <span>页</span>
            <button @click="get_data_replay">确定</button>
          </div>
        </div>
      </div>
    </div>
    <div class="not-have" v-show="this.search_result == 2">
      <div class="nh-carrier">
        <i></i>非常抱歉，没有找到与<span>“{{kw}}”</span>相关的商品。
      </div>
    </div>
    <div class="carefully-chosen" v-show="this.search_result == 2">
      <div class="cc-carrier">
        <div class="cc-head">
          <p class="fl">商品精选</p>
          <i class="fr"></i>
        </div>
        <div class="cc-content">
          <ul>
            <li v-for="(p,i) of carefully" :key="i">
              <router-link to="" :title="p.product_name">
                <img class="cc-img" :src="`img/${p.product_img}`">
                <p class="cc-name">{{p.product_name}}</p>
                <p class="cc-price">&yen;{{p.product_price.toFixed(2)}}</p>
              </router-link>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 根据浏览猜你喜欢 v-show：为了和上面几个div同时显示，而不是一开始就显示 -->
    <browse-like v-show="this.search_result == 1 || this.search_result == 2"></browse-like>
  </div>
</template>

<style>
  .p-list{
    width: 1200px;
    margin: 0 auto;
  }
  .p-list a{
    color: #5e5e5e;
  }
  .p-list a:hover{
    color: #e3101e;
  }
  .p-list .left{
    float: left;
    width: 196px;
    margin-right: 10px;
    border: 1px solid #e6e6e6;
    border-top: 2px solid #a5a5a5;
    color: #5e5e5e;
  }
  .p-list .left > p{
    font-size: 14px;
    height: 32px;
    line-height: 32px;
    padding-left: 10px;
  }
  .p-list .left ul{
    padding: 0 10px;
    border-top: 0;
  }
  .p-list .left ul>li{
    margin: 30px 0;
  }
  .p-list .left ul>li:first-child{
    margin-top: 15px;
  }
  .p-list .left ul>li img{
    display: block;
    width: 160px; height: 160px;
    margin: 0 auto;
  }
  .p-list .left ul>li .price{
    color: #e3101e;
    font-size: 18px;
    height: 30px;
    line-height: 30px;
  }
  .p-list .left ul>li .name{
    height: 36px;
    overflow: hidden;
  }
  .p-list .right{
    float: left;
    width: 992px;
  }
  .p-list .right .filter-box{
    height: 74px;
  }
  .p-list .filter-box .filter-top{
    height: 26px;
    background: #f3f3f3;
    padding: 6px 10px;
  }
  .p-list .filter-top ul{
    /* 26 - 2px边框 */
    width: 320px; height: 24px;
    border: 1px solid #ccc;
    background: #fff;
  }
  .p-list .filter-top li{
    float: left;
    height: 24px;
    line-height: 24px;
  }
  .p-list .filter-top li a{
    padding: 6px 20px;
  }
  .p-list .filter-top .price a{
    padding: 6px 26px 6px 14px;
  }
  .p-list .filter-top .price i{
    position: absolute;
    width: 11px; height: 12px;
    margin: 6px 0 0 -24px;
    background: url('../../public/img/static/searchui.png') no-repeat -20px -250px;
    cursor: pointer;
  }
  .p-list .filter-top .price_cover i{
    background-position: 0 -250px;
  }
  .p-list .filter-top li:hover{
    border: 1px solid #e3101e;
    /* 与ul的边框重叠 */
    margin: -1px;
  }
  .p-list .filter-top li:hover a{
    color: #e3101e;
  }
  .p-list .filter-top .active{
    border: 1px solid #e3101e;
    background: #e3101e;
    /* 与ul的边框重叠 */
    margin: -1px;
  }
  .p-list .filter-top .active a,
  .p-list .filter-top .active:hover a{
    color: #fff;
  }
  .p-list .filter-box .filter-bottom{
    height: 26px;
    line-height: 26px;
    padding: 4px 10px;
    border: 1px solid #f3f3f3;
  }
  .p-list .filter-bottom .filter-check{
    float: left;
    margin-right: 15px;
  }
  .p-list .filter-check label{
    cursor: pointer;
  }
  .p-list .filter-check input{
    width: 12px; height: 12px;
    text-align: center;
    position: relative;
    margin-right: 7px;
    cursor: pointer;
    border: 0; outline: 0;
  }
  .p-list .filter-check input::before{
    content: "";
    position: absolute;
    top: 0; left: 0;
    background: #fff;
    width: 12px; height: 12px;
    border: 1px solid #BDBDBD;
  }
  .p-list .filter_check_chose input::before{
    content: "\2713";
    position: absolute;
    top: 0; left: 0;
    width: 12px; height: 12px;
    line-height: 12px;
    border: 1px solid #e3101e;
    color: #e3101e;
    background: #fff;
    font-size: 12px;
    font-weight: bold;
  }
  .p-list .right .product-box{
    margin-top: 10px;
  }
  .p-list .product-box .reveal{
    color: #5e5e5e;
    font-size: 16px;
    height: 30px;
    line-height: 30px;
  }
  .p-list .product-box .reveal b{
    color: #e3101e;
    margin: 0 5px;
  }
  .p-list .product-box>ul>li{
    float: left;
    width: 218px;
    padding: 35px 13px 10px;
    /* 让边框不重叠 */
    margin: 5px 1px;
    border: 1px solid #fff;
  }
  .p-list .product-box>ul>li:hover{
    border-color: #e6e6e6;
    /* 1px 模糊程度 */
    box-shadow: 0 0 1px #f00;
  }
  .p-list .product-box>ul>li a{
    display: block;
  }
  .p-list .product-box>ul>li a:hover{
    color: #5e5e5e;
  }
  .p-list .product-box>ul>li img{
    width: 220px; height: 210px;
    display: block;
  }
  .p-list .product-box>ul>li p{
    margin: 0 5px;
  }
  .p-list .product-box>ul>li .price{
    height: 23px;
    line-height: 23px;
    margin-top: 13px;
    color: #e3101e;
    font-size: 20px;
  }
  .p-list .product-box>ul>li .price>.describe{
    display: inline-block;
    height: 14px;
    line-height: 14px;
    vertical-align: middle;
    border: 1px solid #e3101e;
    padding: 0 2px;
    font-size: 12px;
  }
  .p-list .product-box>ul>li .name{
    margin-top: 5px;
    height: 36px;
    overflow: hidden;
  }
  .p-list .product-box>ul>li .count{
    height: 56px;
  }
  .p-list .product-box>ul>li .count>span{
    display: block;
    padding-left: 18px;
    background: url('../../public/img/static/searchui.png') no-repeat -51px 3px;
    color: #333;
  }
  .p-list .product-box>ul>li .count>span:first-child{
    background: url('../../public/img/static/volume.png') no-repeat 0 1px;
    margin-bottom: 5px;
  }
  .p-list .product-box>ul>li .count>span b{
    color: #069;
    font-weight: 700;
  }
  .p-list .product-box>ul>li .ziying{
    width: 28px; height: 16px;
    line-height: 16px;
    color: #fff;
    background: #e3101e;
    text-align: center;
    margin-top: 10px;
    visibility: hidden;
  }
  /* 为什么用visibility：hidden，不用v-show？因为li没有具体高度，v-show：display:none脱离文档流的隐藏，
  每次移入移出，会改变li的高度，这样是不好的，所以使用visibility：hidden隐藏时仍占据位置 */
  .p-list .product-box>ul>li .option{
    margin-top: 10px;
    visibility: hidden;
  }
  .p-list .product-box>ul>li .option > span{
    /* 每个span的宽度虽然显示上都是53px，但由于mr:-1px 每个span的实际占地宽度-1 所以是52*4 刚好等于208px p元素的宽度 */
    width: 51px; height: 24px;
    border: 1px solid #ddd;
    /* 让边框重叠 */
    margin-right: -1px;
    cursor: pointer;
    text-align: center;
  }
  .p-list .product-box>ul>li .option span i{
    display: inline-block;
    width: 18px; height: 16px;
    background: url('../../public/img/static/searchui.png') no-repeat;
    vertical-align: middle;
    margin-top: 4px;
  }
  .p-list .product-box>ul>li .option span:first-child i{
    background-position: 0 -312px;
  }
  .p-list .product-box>ul>li .option span:first-child:hover i{
    background-position: 0 -269px;
  }
  .p-list .product-box>ul>li .option span:nth-child(2) i{
    background-position: -24px -312px;
  }
  .p-list .product-box>ul>li .option span:nth-child(2):hover i{
    background-position: -24px -269px;
  }
  .p-list .product-box>ul>li .option span:nth-child(3) i{
    background-position: -24px -334px;
  }
  .p-list .product-box>ul>li .option span:nth-child(3):hover i{
    background-position: -25px -291px;
  }
  .p-list .product-box>ul>li .option span:last-child i{
    background-position: -46px -334px;
  }
  .p-list .product-box>ul>li .option span:last-child:hover i{
    background-position: -46px -291px;
  }
  .p-list .product-box>ul>li .option span:last-child{
    margin-right: -5px;
  }
  .p-list .product-box>ul>li .visibility{
    visibility: visible;
  }

  .p-list .page{
    float: right;
  }
  .p-list .page ul{
    float: left;
  }
  .p-list .page li{
    float: left;
    height: 30px;
    line-height: 30px;
    text-align: center;
    /* 让边框重叠 */
    margin-left: -1px;
    border: 1px solid #ddd;
    padding: 0 13px;
    color: #5e5e5e;
    cursor: pointer;
  }
  .p-list .page li:hover{
    color: #e3101e;
  }
  .p-list .page .prev-page,
  .p-list .page .next-page{
    width: 51px;
    padding: 0 8px 0 15px; 
  }

  .p-list .page .pnDisable{
    color: #ccc;
    border: 1px solid #ddd;
    background: #f8f8f8;
    /* 红色禁止小符号 红色的圈加一个斜杠 */
    cursor: not-allowed;
  }
  .p-list .page .pnDisable:hover{
    color: #ccc;
  }
  .p-list .page .pDisable{
    font-weight: 500;
    color: #a5a5a5;
    border: 1px solid #e6e6e6;
    background: #f8f8f8;
    cursor: not-allowed;
  }
  .p-list .page .pDisable:hover{
    color: #a5a5a5;
  }
  .p-list .page .prev-icon,
  .p-list .page .next-icon{
    display: inline-block;
    width: 6px; height: 11px;
    background: url('../../public/img/static/searchui.png') no-repeat -20px 0;
    vertical-align: middle;
    margin-right: 5px;
  }
  .p-list .page .next-icon{
    margin-right: 0;
    margin-left: 5px;
    background-position: -30px 0;
  }
  .p-list .page li.prev-page.pnDisable .prev-icon{
    background-position: 0 0;
  }
  .p-list .page li.next-page.pnDisable .next-icon{
    background-position: -10px 0;
  }
  .p-list .page .ellipsis{
    width: 16px; height: 16px;
    margin: 0 8px;
    /* 清楚li的样式 */
    border: 0; padding: 0;
    border-bottom: 1px dotted #000;
    cursor: default;
  }
  .p-list .page .skip-page{
    float: left;
    margin-left: 10px;
    line-height: 30px;
  }
  .p-list .page .skip-page span{
    display: inline-block;
    color: #959595;
  }
  .p-list .page .skip-page input{
    width: 32px; height: 18px;
    line-height: 18px;
    margin: 0 5px; padding: 4px 0;
    border: 1px solid #ccc;
    outline: 0;
    vertical-align: middle;
    text-align: center;
    color: #5e5e5e;
  }
  .p-list .page .skip-page button{
    width: 42px; height: 26px;
    line-height: 26px;
    border: 1px solid #ddd;
    background: #f8f8f8;
    outline: 0;
    text-align: center;
    color: #5e5e5e;
    margin-left: 5px;
    vertical-align: middle;
    cursor: pointer;
    font-size: 12px;
  }
  .p-list .page .skip-page button:hover{
    color: #333;
    border: 1px solid #ccc;
  }
  .p-list .page .skip-page button:active{
    background: #f3f3f3;
  }
  .p-list .not-have{
    width: 1200px; height: 62px;
    line-height: 62px;
    margin: 0 auto 20px;
    background: #f8f8f8;
    color: #5e5e5e;
  }
  .p-list .not-have .nh-carrier{
    border: 1px solid #e6e6e6;
    font-weight: 700;
    font-size: 14px;
  }
  .p-list .not-have .nh-carrier i{
    display: inline-block;
    width: 41px; height: 41px;
    vertical-align: middle;
    background: url('../../public/img/static/searchui.png') no-repeat 0 -135px;
    margin: -1px 15px 0;
  }
  .p-list .not-have .nh-carrier span{
    color: #e3101e;
    margin: 0 5px;
  }
  .p-list .carefully-chosen{
    width: 1200px;
    margin: 0 auto;
  }
  .p-list .carefully-chosen .cc-carrier{
    border: 1px solid #ddd;
  }
  .p-list .carefully-chosen .cc-carrier .cc-head{
    padding: 0 6px;
    height: 33px;
    line-height: 33px;
  }
  .p-list .carefully-chosen .cc-head p{
    font-size: 14px;
    color: #666;
  }
  .p-list .carefully-chosen .cc-head i{
    width: 20px; height: 11px;
    background: url('../../public/img/static/u-ad.gif') no-repeat;
    position: relative;
    top: 50%;
    margin-top: -6px;
  }
  .p-list .carefully-chosen .cc-content ul{
    display: flex;
    justify-content: space-around;
  }
  .p-list .carefully-chosen .cc-content li{
    width: 140px;
    padding: 10px;
  }
  .p-list .carefully-chosen .cc-content .cc-img{
    display: block;
    margin: 0 auto;
  }
  .p-list .carefully-chosen .cc-content .cc-name{
    margin: 10px 0 10px 5px;
    height: 36px;
    line-height: 18px;
    overflow: hidden;
  }
  .p-list .carefully-chosen .cc-content .cc-price{
    color: #e3101e;
    font-size: 14px;
    margin-left: 5px;
  }
</style>

<script>
import browseLike from '../components/Browselike.vue';
export default {
  components:{ browseLike },
  props:['kw'],
  data(){
    return{
      product_list:[],
      hot_sale:[],
      filter_sort:['综合','销量','新品','评价'],
      filter_chose:0,
      check_sort:[{id:'zy',value:'ziying',name:'filter',content:'自营'},{id:'gs',value:'goods',name:'filter',content:'仅显示有货'},{id:'sf',value:'shop_festival',name:'filter',content:'618值得快乐'}],
      check_chose:[0,1,0],
      // 被选中项的中文名字，方便用户查阅
      check_chose_name:'仅显示有货',
      // 被选中项（默认仅显示有货）数组中的值与某个复选框value对等时，表示该复选框默认选中（vue不用checked）
      selected_items:['goods'],
      // 首页码
      page_start:1,
      // 总页码
      page:0,
      // 选中页码
      page_chose:1,
      // 每页显示数据量
      page_num:10,
      // 总数据量
      page_count:0,
      // 顺序 0：升序 1：降序
      seqencing:-1,
      // 跳页（默认第1页）
      skip_page:1,
      // li下的选项框
      option_chose:-1,
      // 控制watch中的selected_items  0：发送请求，1：什么也不做
      do_nothing:0,
      // 是否找到搜索结果 0：默认隐藏，1：找到，2：未找到  数据挂载的时候都隐藏，请求以后再做判断
      search_result:0,
      // 精选
      carefully:[]
    }
  },
  methods:{
    select(i){
      this.filter_chose = i;
      // 表示选中最后一个过滤：价格 
      if(i == 4){
        // 第一次点击，添加price类（升序样式）。 第二次点击，追加price_cover类，覆盖price类的bg-position（降序样式）。
        // 第三次点击，去除price_cover类，变成升序样式。 第四次点击，又变成降序样式，如此反复。
        this.seqencing = this.seqencing == -1? 0:this.seqencing == 0? 1:0;
      }
      // 切换过滤条件时，把页码初始为1
      this.page_chose = 1;
      this.product_transfer();
    },
    chose(i){
      if(this.check_chose[i] == 0){
        this.$set(this.check_chose,i,1);
      }else{
        this.$set(this.check_chose,i,0);
      }
    },
    page_change(page){
      this.page_chose = page;
      // 切换页码，请求新的数据
      this.product_transfer();
    },
    prev(){
     if(this.page_chose!=1){
       this.page_chose--;
       this.product_transfer();
     }
    },
    next(){
      if(this.page_chose!=this.page){
        this.page_chose++;
        this.product_transfer();
      }
    },
    // 热销推荐
    hot_data(){
      this.axios.get('/v1/products/hot').then(res=>{
        this.hot_sale = res.data;
      })
    },
    // 商品中转站： 通过不同过滤、分类，获取不同的商品及数量
    product_transfer(){
      let field;       // 字段
      let condition;   // 条件
      let sort = this.selected_items;  // 当前所选分类
      if(sort.length == 0){
        // 1种情况：（1）什么都不选，查询全部数据，不写条件
        field = ',goods,ziying,shop_festival';
        condition = '';
      }else if(sort.length == 1){
        // 3种情况：（1）自营（2）有货（3）618
        if(sort[0] == 'goods'){               // 只选择有货，要把自营、618带上
          field = ',goods,ziying,shop_festival'; 
          condition = 'goods = 1 and';
        }else if(sort[0] == 'ziying'){        // 只选择自营，要把618带上
          field = ',ziying,shop_festival';
          condition = 'ziying = 1 and';
        }else if(sort[0] == 'shop_festival'){ // 反之，只选择618，也要带上自营
          field = ',shop_festival,ziying';
          condition = 'shop_festival = 1 and';
        }
      }else if(sort.length == 2){
        // 3种情况：（1）自营+有货（2）自营+618（3）有货+618
        let ziying = sort.indexOf('ziying');
        let goods = sort.indexOf('goods');
        let shop_festival = sort.indexOf('shop_festival');
        if(ziying!=-1 && goods!=-1){
          field = ['ziying','goods'];
          condition = 'ziying = 1 and goods = 1 and';
        }else if(ziying!=-1 && shop_festival!=-1){
          field = ['ziying','shop_festival'];
          condition = 'ziying = 1 and shop_festival = 1 and';
        }else if(goods!=-1 && shop_festival!=-1){
          field = ['goods','shop_festival'];
          condition = 'goods = 1 and shop_festival = 1 and';
        }
      }else if(sort.length == 3){
        // 1种情况：（1）全部选取
        field = ['ziying','goods','shop_festival'];
        condition = 'ziying = 1 and goods = 1 and shop_festival = 1 and';
      }
      switch(this.filter_chose){
        case 0: // 当前选中过滤：综合
          this.get_product(field,condition);
          this.get_count(condition);
          break;
        case 1: // 当前选中过滤：销量
          this.get_product(field,condition,'volume');
          this.get_count(condition);
          break;
        case 2: // 当前选中过滤：新品
          this.get_product(field,condition,'news');
          this.get_count(condition,'news');
          break;
        case 3: // 当前选中过滤：评价
          this.get_product(field,condition,'comment');
          this.get_count(condition);
          break;
        case 4: // 当前选中过滤：价格
          this.get_product(field,condition,'product_price');
          this.get_count(condition);
      }
      // 返回页面顶部
      window.scrollTo(0,0);
    },
    // 获取数量
    get_count(condition,add_condition){
      this.axios.get('/v1/products/get_count',{
        params:{
          kw:this.kw,
          condition:condition,
          add_condition:add_condition  // 附加条件（筛选）
        }
      }).then(res=>{
        if(res.data[0].sum == 0) return;
        // 模糊查询总数据量
        let count = res.data[0].sum;
        this.page_count = count;
        // 计算出总页码 10：每页显示数据量，ceil向上取整，不足一页的按一页显示
        this.page = Math.ceil(count/10);
      })
    },
    // 获取商品
    get_product(field,condition,add_condition){
      switch(add_condition){
        case 'volume':
        case 'comment':
          add_condition = `order by ${add_condition} desc`;
          break;
        case 'product_price':
          add_condition =  this.seqencing == 1? `order by ${add_condition} desc`:`order by ${add_condition} asc`;
          break;
        case 'news':
          add_condition = `and ${add_condition} = 1`;
          break;
        // 不用写default，add_condition是undefiend的时候，axios不会把他传递给后台。
        default:
          // 还是写上，是避免过滤到 综合 时，后台还要做undefined验证。
          add_condition = '';
      }
      this.axios.get('/v1/products/get_product',{
        params:{
          kw:this.kw,                 // 关键字
          pno:this.page_chose,        // 当前选中页码
          count:this.page_num,        // 每页显示数据量
          field:field,                // 查询字段
          condition:condition,        // 查询条件
          add_condition:add_condition // 附加条件
        }
      }).then(res=>{
        if(res.data.length == 0){
          this.search_result = 2;
          //只有找不到搜索结果时，我们才发送请求获取精选
          this.get_carefully();
          return;
        }else{
          this.search_result = 1;
        }
        this.product_list = res.data;
      })
    },
    // 把当前选中项数组转换成中文，方便用户查阅
    get_chinese(arr){
      if(arr.length == 0) return '全部货物';
      let str = '';
      for(let ele of arr){
        str += ele=='ziying'? '自营&':ele=='goods'? '仅显示有货&':'618值得快乐&';
      }
      // 去掉字符串结尾的& str.length-1代表&的下标，从0截取到&之前的所有字符
      return str.slice(0,str.length-1);
    },
    // 页数跳转，重新获取数据
    get_data_replay(){
      if(this.skip_page>this.page){
        // 如果用户输入的页数大于总页数，则直接跳到最大页码
        this.page_chose = this.page;
        this.skip_page = this.page;
      }else{
        this.page_chose = this.skip_page;
      }
      this.product_transfer();
    },
    // 显示每个li下的选项框
    option_change(id){
      if(id != undefined){
        this.option_chose = id;
      }else{
        this.option_chose = -1;
      }
    },
    // 控制input框只能输入数字
    num_valid(e){
      let str = e.target.value;
      this.skip_page = Number(str.replace(/[^\d]/g,''));
    },
    // 获取精选
    get_carefully(){
      this.axios.get('/v1/products/get_carefully').then(res=>{
        this.carefully = res.data;
      })
    }
  },
  watch:{
    filter_chose(newValue,oldValue){
      // 如果上一个过滤条件是价格时，把顺序初始为-1
      if(oldValue == 4){
        this.seqencing = -1;
      }
    },
    // 由于@click事件优先于v-model执行，所以我们只能在watch里面操作selected_items
    selected_items(newValue){
      if(this.do_nothing != 1){
        // 切换不同分类 选中项时，把页码初始为1
        this.page_chose = 1;
        this.product_transfer();
      }else{
        // 恢复watch中的selected_items发送请求
        this.do_nothing = 0;
      }
      this.check_chose_name = this.get_chinese(newValue);
    },
    product_list(newValue){
      // 把关键字高亮显示
      for(let obj of newValue){
        // 我们添加一个新属性来代替商品名，原属性用于传参  动态生成的正则表达式用RegExp对象
        obj.p_name = obj.product_name.replace(new RegExp(`${this.kw}`,"ig"),`<span style="color:red;">${this.kw}</span>`);
      }
    },
    skip_page(newValue){
      // 如果用户把页数给backspace删除了，则恢复成1
      if(newValue == 0){
        this.skip_page = 1;
      }
    },
    // watch可以监听路由传递过来的参数
    kw(){
      this.product_transfer();
    }
  },
  mounted(){
    this.hot_data();
    if(window.name == ""){
      // 首次加载
      window.name = "refresh";
    }else if(window.name == "refresh"){
      // 页面刷新
      let obj = JSON.parse(sessionStorage.getItem("list_params"));
      this.page_chose = obj.pageChose;
      this.filter_chose = obj.filter;
      this.check_chose = obj.check;
      this.do_nothing = obj.nothing;    // 一定要写在 select 上面，才能起效果
      this.selected_items = obj.select;
      if(obj.seqencing != undefined){
        this.seqencing = obj.seqencing;
      }
    }
    window.addEventListener('beforeunload',()=>{
      // 刷新页面前，把当前页码、过滤、分类、以及用于操作分类的变量，存入sessionStorage
      let obj = {
        pageChose : this.page_chose,
        filter : this.filter_chose,
        check : this.check_chose,
        select : this.selected_items,
        nothing: 1 // 确保刷新后，初次给selected_items赋值时，watch不做任何操作
      }
      // 如果用户点的过滤是价格之后再刷新，那么我们要把seqencing排序也加进去
      if(this.filter_chose == 4){
        obj.seqencing = this.seqencing;
      }
      sessionStorage.setItem("list_params",JSON.stringify(obj));
    })
    this.product_transfer();
  },
  // 刷新不会触发该生命周期
  beforeDestroy(){
    // 清除名字（再次进入该路由，就会是首次加载）
    window.name = "";
  }
}
</script>