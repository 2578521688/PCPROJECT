<template>
  <!-- shopping cart transfer购物车中转站 -->
  <div class="sctransfer">
    <div class="info">
      <div class="info-body">
        <div class="msg">
          <i></i>商品已成功加入购物车！
        </div>
        <div class="detail clearfix">
          <div class="fl">
            <img :src="`img/${p_pic}`" alt="" class="fl">
            <div class="content fl">
              <p class="name" :title="p_pname">{{p_pname}}</p>
              <p class="count">数量：{{p_count}}</p>
            </div>
          </div>
          <div class="fr">
            <router-link :to="`/list/${kw}`" class="back">返回</router-link>
            <router-link to="/shoppingcart" class="shop">我的购物车<i></i></router-link>
          </div>
        </div>
      </div>
    </div>
    <div class="more">
      <div class="carrier" v-for="(p,i) of all_list" :key="i">
        <p class="title">购买了该商品的用户还购买了</p>
        <ul class="clearfix">
          <li class="fl" v-for="(p,i) of all_list[i]" :key="p.product_id" :title="p.product_name">
            <img :src="`img/${p.product_img}`">
            <p class="name same-p">{{p.product_name}}</p>
            <p class="price same-p">&yen;{{p.product_price.toFixed(2)}}</p>
            <a href="javascript:;" @click="add_to_cart(p.product_img,p.product_name,p.product_price,i)">
              <i></i>加入购物车
            </a>
            <div class="add-success" :class="{ openanimation: add_success[i] == 1 }" @animationend="hide(i)">
              <i></i>添加成功
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<style>
  @keyframes success {
    0%{z-index: 1;}
    50%{opacity: 1; z-index: 1;}
    100%{opacity: 0; z-index: -1;} 
  }
  .sctransfer i{
    display: inline-block;
    vertical-align: middle;
    background: url('../../public/img/static/sprite.png') no-repeat;
  }
  .sctransfer .info{
    background: #f8f8f8;
  }
  .sctransfer .info .info-body{
    width: 1200px;
    margin: 0 auto;
  }
  .sctransfer .info-body .msg{
    font-size: 16px;
    height: 80px;
    line-height: 80px;
    color: #68b64c;
  }
  .sctransfer .info-body .msg > i{
    width: 32px; height: 36px;
    background-position: 0 -65px;
    margin-right: 10px;
  }
  .sctransfer .info-body .detail{
    padding-bottom: 15px;
  }
  .sctransfer .info-body .detail img{
    width: 50px;
    margin-right: 10px;
    border: 1px solid #e6e6e6;
    image-rendering: -webkit-optimize-contrast; /* 解决图片缩放时造成的模糊 */
  }
  .sctransfer .info-body .detail .content{
    height: 40px;
    line-height: 20px;
    padding: 5px 0;
  }
  .sctransfer .info-body .detail .name{
    color: #333;
    width: 200px; height: 20px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .sctransfer .info-body .detail .count{
    color: #888;
  }
  .sctransfer .info-body .detail a{
    display: inline-block;
    text-align: center;
    vertical-align: middle;
    font-size: 16px;
    border-radius: 2px;
  }
  .sctransfer .info-body .detail .back{
    margin-right: 7px;
    border: 1px solid #ddd;
    padding: 10px 26px;
    color: #333;
    background: #fff;
  }
  .sctransfer .info-body .detail .shop{
    background: #e6060e;
    color: #fff;
    padding: 11px 46px;
  }
  .sctransfer .info-body .detail .shop > i{
    width: 12px; height: 13px;
    background-position: -232px -84px;
    margin-left: 10px;
  }
  .sctransfer .more{
    width: 1200px;
    margin: 0 auto;
  }
  .sctransfer .more > div{
    margin-top: 20px;
  }
  .sctransfer .more .title{
    margin-bottom: 9px;
    font-size: 14px;
    height: 24px;
    line-height: 24px;
    color: #333;
  }
  .sctransfer .more li{
    width: 198px;
    border: 1px solid #e6e6e6;
    /* li 与 li 之间 上、左边框重叠 */
    margin-left: -1px;
    margin-top: -1px;
    padding: 20px 0;
    position: relative;
  }
  .sctransfer .more img{
    display: block;
    margin: 0 auto;
  }
  .sctransfer .more .same-p{
    padding: 0 20px;
    margin-top: 10px;
  }
  .sctransfer .more .name{
    color: #5e5e5e;
    height: 40px;
    line-height: 20px;
    overflow: hidden;
  }
  .sctransfer .more .price{
    color: #e3101e;
    font-size: 14px;
    height: 24px;
    line-height: 24px;
  }
  .sctransfer .more a{
    display: block;
    width: 133px;
    margin: 10px auto 0;
    font-size: 14px;
    color: #5e5e5e;
    background: #fff;
    padding: 5px 12px;
    border: 1px solid #888;
    text-align: center;
  }
  .sctransfer .more a:hover{
    background: #e6060e;
    border: 1px solid #e6060e;
    color: #fff;
  }
  .sctransfer .more a i{
    width: 18px; height: 14px;
    background-position: -321px -83px;
    margin-right: 8px;
  }
  .sctransfer .more a:hover i{
    background-position: -339px -83px;
  }
  .sctransfer .more .add-success{
    width: 180px; height: 40px;
    line-height: 40px;
    font-size: 14px;
    color: #333;
    background: rgba(255, 255, 255, .5);
    box-shadow: 0 0 10px 2px rgba(0, 0, 0, .2);
    position: absolute;
    top: 50%; left: 50%;
    margin-top: -20px;
    margin-left: -90px;
    text-align: center;
    opacity: 0;
    z-index: -1;
  }
  .sctransfer .more .add-success > i{
    width: 22px; height: 22px;
    background-position: -188px -64px;
    margin-right: 10px;
  }
  .sctransfer .more .openanimation{
    animation: success 2s;
  }
</style>

<script>
import { mapState,mapMutations } from 'vuex';
export default {
  props:["lg_pic_prefix","lg_pic_suffix","pname","count","kw"],
  data(){
    return {
      other_buy:[], // 其他用户购买
      may_need:[],  // 你可能还需要
      all_list:[],  // 包括上面两个，用于v-for遍历
      p_pic:'',     // vue不推荐直接修改props中的变量，我们自己创建一份 
      p_pname:'',
      p_count:0,
      add_success:[], // 显示某个商品的'添加成功'
      timer:'',
      canClick:[]   // 能否点击某个商品下的'加入购物车'按钮
    }
  },
  methods:{
    ...mapMutations(["isInclude"]),

    add_to_cart(img,name,price,index){
      // 防止用户频繁点击加入购物车按钮
      if(this.canClick[index] != 0){
        // 不能继续点击
        this.$set(this.canClick,index,0);
        // 显示添加成功
        this.$set(this.add_success,index,1);
        // 中转站页面使用
        this.p_pname = name;
        this.p_count = 1;
        this.p_pic = img;
        // 添加进数据库
        let obj = {
          us_img:img,
          us_name:name,
          us_price:price,
          us_count:1
        }
        let resObj = this.isIncludeObj(obj);
        if(resObj != undefined){
          // 数量+1
          let quantity = resObj.us_count+1;
          this.axios.put('/v1/products/quantity_superposition',
          `quantity=${quantity}&name=${obj.us_name}&uid=${this.uid}&code=2`).then(res=>{
            if(res.data == 1){
              console.log(`数据库商品数量已更新`);
            }
          })
        }else{
          // 添加商品
          this.axios.post('/v1/products/save_commodity',
          `us_img=${obj.us_img}&us_name=${obj.us_name}&us_price=${obj.us_price}&us_count=${obj
          .us_count}&user_id=${this.uid}`).then(res=>{
            if(res.data == 1){
              console.log(`数据库商品已更新`);
            }
          })
        }
        // 添加进vuex
        this.isInclude(obj);
        // 加入购物车2s后，我们在恢复按钮点击（动画正好显示2s）
        this.timer = setTimeout(()=>{
          this.$set(this.canClick,index,1);
        },2000)
      }
    },
    hide(index){
      // 动画结束，恢复默认值，防止下次点击在同一商品时，openanimation类已存在
      this.$set(this.add_success,index,0);
    },
    isIncludeObj(object){
      for(let obj of this.shoppingCartList){
        // 我们比较商品名即可
        if(obj.us_name == object.us_name){
          // 说明包含（如果遍历结束后，仍没有符号if条件，那么返回undefined）
          return obj;
        }
      }
    }
  },
  computed:{
    ...mapState(["shoppingCartList","uid"])
  },
  mounted(){
    this.p_pic = `color/${this.lg_pic_prefix}/${this.lg_pic_suffix}.jpg`;  // 把图片路径拼回来
    this.p_pname = this.pname;
    this.p_count = this.count;
    this.axios.get('/v1/products/get_similar',{
      params:{
        kw:this.kw
      }
    }).then(res=>{
      // 每次获取到随机数据时，都要跟购物车数组内的详细页商品做比较，如果名字相同，则剔除该随机数据
      let index = [];
      for(let obj of this.shoppingCartList){
        if(obj.us_db != '' && obj.us_db != undefined){
          res.data.forEach((ele,i)=>{
            if(obj.us_name == ele.product_name){
              index.push(i);
            }
          })
        }
      }
      // 逆向删除
      index.sort((a,b)=>b-a);
      for(let i of index){
        res.data.splice(i,1);
      }
      // 添加数据
      for(let obj of res.data){
        if(this.other_buy.length!=12){
          this.other_buy.push(obj);
        }else{
          this.may_need.push(obj);
        }
        // 设置默认值
        this.canClick.push(1);
        this.add_success.push(0);
      }
      this.all_list.push(this.other_buy);
      this.all_list.push(this.may_need);
    })
  }
}
</script>