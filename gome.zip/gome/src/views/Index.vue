<template>
  <div class="index">
    <div class="category_box">
      <div class="category clearfix">
        <div class="sidecategory">
          <h2 class="sort_all">
            <router-link to="">全部商品分类</router-link>
          </h2>
          <div class="sort_carrier" @mouseleave="category_change" @mouseenter="category_body">
            <div class="sort">
              <ul>
                <li v-for="(p,i) of category_name" :key="i" :class="{ bgw: category_chose==i }"  @mouseenter="category_change(i)">
                  <h3>
                    <router-link to="" v-for="(p,i) of p" :key="i">{{p}}</router-link>
                  </h3>
                </li>
              </ul>
            </div>
            <div class="sort_content clearfix" v-for="(cp,ci) of category" :key="ci" v-show="category_chose == ci">
              <div class="sort_content_left">
                <div class="sort_content_title">
                  <router-link to="" v-for="(ctp,cti) of category_top[ci]" :key="cti" >{{ctp}}<i></i></router-link>
                </div>
                <div class="sort_content_box">
                  <div class="sort_content_all" v-for="(ccp,cci) of category_content[ci]" :key="cci">
                    <router-link to="" v-for="(p,i) of ccp" :key="i">{{p}}</router-link>
                  </div>
                </div>
              </div>
              <div class="sort_content_right">
                <div class="brand clearfix">
                  <router-link v-for="(cip,cii) of category_img[ci]" :key="cii" to="">
                    <img :src="`img/category/${cip}`" alt="">
                  </router-link>
                </div>
              </div>
            </div>
            <div class="bulletin">
              <div class="bulletin_top">
                <div class="news">
                  <h2 class="title">快讯</h2>
                  <router-link to="">
                    更多
                    <span></span>
                  </router-link>
                </div>
                <div class="news_content">
                  <span>
                    <router-link to="" class="news_sort">特惠</router-link>
                    <router-link to="" class="news_text">生活家电专场 松下吹风机低至98元哈哈哈哈哈</router-link>    
                  </span>
                  <span>
                    <router-link to="" class="news_sort">公告</router-link>
                    <router-link to="" class="news_text color_b20fd3">化妆品网络销售经营者自律声明哈哈哈哈哈</router-link>    
                  </span>
                  <span>
                    <router-link to="" class="news_sort">特惠</router-link>
                    <router-link to="" class="news_text">冰洗焕新 热卖洗衣机低至799元哈哈哈哈哈</router-link>    
                  </span>
                  <span>
                    <router-link to="" class="news_sort">特惠</router-link>
                    <router-link to="" class="news_text">厨房卫浴造作新家 爆品直降千元哈哈哈哈哈</router-link>    
                  </span>
                </div>
              </div>
              <div class="bulletin_icon">
                <ul>
                  <li>
                    <router-link to="">
                      <i class="iconfont icon-chonghuafei"></i>
                      <span>充话费</span>
                    </router-link>
                  </li>
                  <li>
                    <router-link to="">
                      <i class="iconfont icon-chongliuliangicon"></i>
                      <span>充流量</span>
                    </router-link>
                  </li>
                  <li>
                    <router-link to="">
                      <i class="iconfont icon-lingjuanzhongxin"></i>
                      <span>领劵</span>
                    </router-link>
                  </li>
                  <li>
                    <router-link to="">
                      <i class="iconfont icon-huiyuan_"></i>
                      <span>会员</span>
                    </router-link>
                  </li>
                  <li>
                    <router-link to="">
                      <i class="iconfont icon-bangzhu"></i>
                      <span>帮助</span>
                    </router-link>
                  </li>
                  <li>
                    <router-link to="">
                      <i class="iconfont icon-zhaofuwu"></i>
                      <span>找服务</span>
                    </router-link>
                  </li>
                </ul>
              </div>
              <div class="bulletin_img">
                <router-link to="">
                  <img src="../../public/img/static/bulletin.jpg">
                </router-link>
              </div>
            </div>
          </div>
        </div>
        <ul class="mainnav">
          <li v-for="(p,i) of main_nav" :key="i">
            <router-link to="">{{p}}</router-link>
          </li>
        </ul>
        <!-- 上下滚动 -->
        <roll></roll>
      </div>
    </div>
    <!-- 轮播图 -->
    <carousel></carousel>
    <!-- 美日必抢 -->
    <everyday></everyday>
    <!-- 领券 -->
    <coupons></coupons>
    <!-- 猜你喜欢 -->
    <guesslike></guesslike>
    <!-- 全部楼层 -->
    <floor></floor>
  </div>
</template>

<style>
  .index .category_box{
    height: 40px;
    border-bottom: 1px solid #b20fd3;
    background: #f8f8f8;
  }
  .index .category_box .category{
    width: 1200px;
    margin: 0 auto;
  }
  .index .category .sidecategory{
    float: left;
    position: relative;
  }
  .index .sidecategory .sort_all{
    width: 200px; height: 40px;
    line-height: 40px;
    background: #f1f1f1;
    opacity: .9;
  }
  .index .sidecategory .sort_all a{
    color: #585858;
    font-weight: bolder;
    font-size: 15px;
    padding-left: 15px;
  }
  .index .sidecategory .sort_carrier{
    width: 200px; height: 450px;
    position: absolute;
    top: 41px; left: 0;
    z-index: 10;
  }
  .index .sidecategory .sort{
    height: 450px;
    background: #333;
    color: #333;
    opacity: .7;
    z-index: inherit;
  }
  .index .sidecategory .sort li{
    height: 30px;
    line-height: 30px;
    margin-left: 1px;
  }
  .index .sidecategory .sort li:last-child{
    /* hover时，不贴底边 */
    height: 29px;
    line-height: 29px;
  }
  /* 绑定class:start */
  .index .sidecategory .sort_carrier .bgw{
    background: #fbfbfb;
  }
  .index .sidecategory .sort_carrier .bgw a{
    color: #000;
  }
  .index .sidecategory .sort_carrier .bgw a:hover{
    color: #b20fd3;
  }
  /* 绑定class:end*/
  .index .sidecategory .sort li h3{
    width: 170px;
    padding-left: 15px;
  }
  .index .sidecategory .sort li a{
    color: #fff;
    font-size: 14px;
    margin-right: 5px;
    font-weight: lighter;
  }
  .index .sidecategory .sort_content{
    /* 1000 450 减去边框 */
    width: 999px; height: 449px;
    position: absolute;
    top: 0; left: 200px;
    border: 1px solid #818181;
    border-top: 0;
    border-left: 0;
    background: #fff;
    z-index: inherit;
  }
  .index .sidecategory .sort_content_left{
    width: 789px; height: 448px;
    background: #fbfbfb;
    float: left;
  }
  .index .sidecategory .sort_content_title{
    height: 20px;
    padding: 20px 0 7px 20px;
  }
  .index .sidecategory .sort_content_title a{
    display: inline-block;
    height: 20px;
    line-height: 20px;
    background: #b20fd3;
    margin-right: 10px;
    padding: 0 5px;
    color: #fff;
    font-weight: 700;
  }
  .index .sidecategory .sort_content_title i{
    display: inline-block;
    width: 5px; height: 7px;
    background: url("../../public/img/static/ui.png") no-repeat -70px -433px;
    margin-left: 6px;
  }
  .index .sidecategory .sort_content_box{
    margin: 6px 0 10px 20px;
  }
  .index .sidecategory .sort_content_all{
    border-bottom: 1px solid #f3f3f3;
  }
  .index .sidecategory .sort_content_all a{
    color: #5e5e5e;
    display: inline-block;
    margin: 7px 0; padding: 0 7px;
    height: 14px;
    line-height: 14px;
    border-left: 1px solid #e0e0e0;
  }
  .index .sidecategory .sort_content_all a:hover{
    color: #b20fd3;
  }
  .index .sidecategory .sort_content_all a:first-child{
    width: 61px; height: 22px;
    line-height: 22px;
    font-weight: 700;
    border-left: 0;
    padding-left: 0;
  }
  .index .sidecategory .sort_content_all a:first-child:hover{
    color: #5e5e5e;
    cursor: text;
  }
  .index .sidecategory .sort_content_right{
    width: 210px; height: 448px;
    background: #fff;
    float: left;
  }
  .index .sidecategory .brand{
    padding: 0 0 11px 10px;
    border-bottom: 1px solid #f4f4f4;
  }
  .index .sidecategory .brand a{
    float: left;
  }
  .index .sidecategory .brand img{
    display: block;
    width: 70px; height: 35px;
    margin: 20px 20px 0 10px;
  }
  .index .sidecategory .bulletin{
    width: 250px; height: 450px;
    /* 轮播图750+类别200 */
    top: 0; left: 950px;
    position: absolute;
    background-color: #fff;
    z-index: 9;
  }
  .index .sidecategory .bulletin a:hover{
    color: #b20fd3;
  }
  .index .sidecategory .bulletin_top{
    /* 150减去1px边框 */
    height: 149px;
    margin: 0 15px;
    border-bottom: 1px dashed #ccc;
  }
  .index .sidecategory .bulletin_top .news{
    height: 36px;
  }
  .index .sidecategory .news .title{
    font-size: 14px;
    float: left;
    color: #333;
    margin-top: 12px;
    font-weight: 400;
  }
  .index .sidecategory .news a{
    color: #888;
    float: right;
    margin-top: 14px;
  }
  .index .sidecategory .news a span{
    display: inline-block;
    width: 5px; height: 9px;
    margin-left: 4px;
    background: url('../../public/img/static/ui2.png') no-repeat -126px -130px;
  }
  .index .sidecategory .news_content span{
    display: block;
    height: 28px;
    line-height: 28px;
  }
  .index .sidecategory .news_content .news_sort{
    float: left;
    color: #888;
    width: 24px; height: 28px;
  }
  .index .sidecategory .news_content .news_text{
    float: left;
    color: #5e5e5e;
    width: 184px; height: 28px;
    margin-left: 12px;
    /* 文本不换行 溢出隐藏 溢出部分用省略号代替 3个缺一不可*/
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .index .sidecategory .news_content .color_b20fd3{
    color: #b20fd3;
  }
  .index .sidecategory .bulletin_icon{
    height: 150px;
  }
  .index .sidecategory .bulletin_icon li{
    float: left;
    margin: 0 14px;
    text-align: center;
    cursor: pointer;
  }
  .index .sidecategory .bulletin_icon a:hover i,
  .index .sidecategory .bulletin_icon a:hover span{
    color: #b20fd3;
  }
  .index .sidecategory .bulletin_icon li a{
    display: block;
    width:55px; height: 75px;
  }
  .index .sidecategory .bulletin_icon li a i{
    font-size: 32px;
    color: #373737;
  }
  .index .sidecategory .bulletin_icon li a span{
    color: #5e5e5e;
    display: inline-block;
    width: 36px; height: 20px;
    line-height: 20px;
  }
  .index .sidecategory .bulletin_img{
    height: 150px;
  }
  .index .sidecategory .bulletin_img a{
    display: block;
    height: 150px;
  }
  .index .sidecategory .bulletin_img a img{
    width: 100%; height: 150px;
  }
  .index .mainnav{
    float: left;
    width: 800px;
  }
  .index .mainnav li{
    float: left;
    padding: 0 13px;
    text-align: center;
    height: 40px;
    line-height: 40px;
  }
  .index .mainnav li:first-child a,
  .index .mainnav a:hover{
    color: #b20fd3;
  }
  .index .mainnav a{
    color: #000;
    font-size: 15px;
  }
</style>

<script>
import carousel from '../components/Carousel.vue';
export default {
  components:{ 
    carousel,
    roll:resolve=>require(['../components/Roll.vue'],resolve),
    everyday:resolve=>require(['../components/Everyday.vue'],resolve),
    coupons:resolve=>require(['../components/Coupons.vue'],resolve),
    guesslike:resolve=>require(['../components/GuessLike.vue'],resolve),
    floor:resolve=>require(['../components/floor.vue'],resolve)
  }, // 子组件懒加载
  data(){
    return {
      // 完整数据
      category:[],
      // 类别名称
      category_name:[],
      // 类别顶部内容
      category_top:[],
      // 类别主内容
      category_content:[],
      // 类别品牌图片
      category_img:[],
      category_chose:-1,
      main_nav:["首页","发现","超市","电器城","家居安装","智能","管家","金融","美锅优食"]
    }
  },
  methods:{
    category_change(i){
      if(i != undefined){
        this.category_chose = i;
      }else{
        this.category_chose = -1;
      }
    },
    // 当用户触碰分类载体时，我们再发送请求，响应对应分类的内容
    category_body(){
      // 避免每次触碰分类载体，都发送请求
      if(this.category.length != 0){
        return;
      }
      this.axios.get('/v1/products/category_body').then(res=>{
        // 完整数据
        this.category = res.data;
        for(let obj of res.data){
          // 类别顶部内容
          let categoryTop = obj.category_top.split("|");
          this.category_top.push(categoryTop);
          // 类别主内容
          let categoryContent = [obj.content_1 , obj.content_2 , obj.content_3 , obj.content_4 , obj.content_5];
          let categoryArr = [];
          for(var str of categoryContent){
            categoryArr.push(str.split("|"));
          }
          this.category_content.push(categoryArr);
          // 类别品牌图片
          let categoryImg = obj.category_img.split("|");
          this.category_img.push(categoryImg);
        }
      })
    }
  },
  mounted(){
    // 先取出分类【之所以把分类和内容分开请求的原因是：减少首屏请求总次数，响应数据就少，页面渲染效率就高，用户不点，我们就不请求！】
    this.axios.get('/v1/products/category_sort').then(res=>{
      for(let obj of res.data){
        // 类别名称
        let categoryName = obj.category_name.split('|');
        this.category_name.push(categoryName);
      }
    })
  }
}
</script>