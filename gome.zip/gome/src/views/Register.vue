<template>
  <div class="register">
    <div class="head_carrier">
      <div class="head">
        <img src="img/static/register.png">
        <p class="fr">  
          我已经注册，现在就<router-link to="/login">登录</router-link>
        </p>
      </div>
    </div>
    <div class="step-progress">
      <div class="step-slider clearfix">
        <div class="step1 fl" :class="{ active: stepChose.indexOf(1) != -1 }">
          <div class="step-bg" v-if="stepChose.indexOf(2) != -1"></div>
          <div class="step-icon" v-else>1</div>
          <div class="step-name">验证手机号</div>
        </div>
        <p class="step-transverse fl" :class="{ activep: stepChose.indexOf(2) != -1 }"></p>
        <div class="step2 fl" :class="{ active: stepChose.indexOf(2) != -1 }">
          <div class="step-bg" v-if="stepChose.indexOf(3) != -1"></div>
          <div class="step-icon" v-else>2</div>
          <div class="step-name">填写用户信息</div>
        </div>
        <p class="step-transverse fl" :class="{ activep: stepChose.indexOf(3) != -1 }"></p>
        <div class="step2 fl" :class="{ active: stepChose.indexOf(3) != -1 }">
          <div class="step-bg" v-if="stepChose.indexOf(3) != -1"></div>
          <div class="step-icon" v-else>3</div>
          <div class="step-name">注册成功</div>
        </div>
      </div>
      <div class="step-content">
        <div class="step1-c same-div" v-show="stepContent == 1">
          <div class="input-carrier">
            <input type="text" placeholder="请输入常用手机号" v-model="phone" :class="{ border: phoneBorder == true }"
            @input="numValid(phone)" @focus="phoneMsgShow('focus')" @blur="phoneMsgShow('blur')">
            <i v-show="phoneIconShow == 0" class="clear" @click="clearContent('phone')"></i>
            <i v-show="phoneIconShow == 1" class="success"></i>
            <p class="msg" v-html="phoneMsg"></p>
          </div>
          <a href="javascript:;" class="verification same-a" @click="checkPhone">点击按钮进行验证</a>
          <a href="javascript:;" class="step-next same-a" @click="stepNext(1)">下一步</a>
          <div class="company">
            <router-link to=""><i></i>企业用户注册</router-link>
          </div>
        </div>
        <div class="step2-c same-div" v-show="stepContent == 2">
          <div class="input-carrier">
            <input type="text" placeholder="请输入用户名" v-model="username" :class="{ border: userBorder == true }"
            @focus="userMsgShow('focus')" @blur="userMsgShow('blur')">
            <i v-show="userIconShow == 0" class="clear" @click="clearContent('user')"></i>
            <i v-show="userIconShow == 1" class="success"></i>
            <p class="msg" v-html="userMsg"></p>
          </div>
          <div class="input-carrier">
            <input :type="pwdShow? 'text':'password'" placeholder="请设置登录密码" v-model="password" :class="{ border: pwdBorder == true }"
            @focus="pwdMsgShow('focus')" @blur="pwdMsgShow('blur')">
            <i v-show="pwdShow == 0" class="close-eyes" @click="change_eyes()"></i>
            <i v-show="pwdShow == 1" class="open-eyes" @click="change_eyes()"></i>
            <p class="msg" v-html="pwdMsg"></p>
          </div>
          <div class="input-carrier">
            <input type="text" placeholder="填写推荐人推荐码，帮好友赚收入（选填）">
          </div>
          <a href="javascript:;" class="step-next same-a" @click="stepNext(2)">下一步</a>
        </div>
        <div class="step3-c diff-div" v-show="stepContent == 3">
          <div class="congratulate">恭喜您，<span>{{phone}}</span>注册真快乐会员成功！</div>
          <div class="shop">您的账号可以在真快乐网站和真快乐旗下所有门店通用<p>快开启您的购物之旅吧</p></div>
          <router-link to="/" class="goshop">去购物</router-link>
          <p><span>{{n}}S</span>后自动跳转至首页</p>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .register i{
    display: inline-block;
    vertical-align: middle;
    background: url('../../public/img/static/bg-register.png') no-repeat;
  }
  .register .head_carrier{
    border-bottom: 1px solid #dd00a7;
  }
  .register .head{
    width: 990px; height: 120px;
    line-height: 120px;
    margin: 0 auto;
    position: relative;
    overflow: hidden;
    color: #333;
  }
  .register .head img{
    position: absolute;
    top: 50%;
    margin-left: -124px;
    margin-top: -28px;
  }
  .register .head a{
    color: #2875cc;
    margin-left: 3px;
  }
  .register .head a:hover{
    text-decoration: underline;
  }
  .register .step-progress{
    width: 550px;
    margin: 95px auto 0;
  }
  .register .step-progress .step-slider{
    width: 416px; height: 60px;
    margin: 0 auto 40px;
  }
  .register .step-progress .step-slider > div{
    width: 72px;
  }
  .register .step-slider .step-icon{
    width: 24px; height: 24px;
    line-height: 24px;
    color: #e0e0e0;
    border: 3px solid #e0e0e0;
    border-radius: 50%;
    font-weight: 700;
    text-align: center;
    margin: 0 auto;
  }
  .register .step-slider .step-name{
    color: #999;
    margin-top: 10px;
    text-align: center;
  }
  .register .step-slider .active .step-icon{
    color: #ff4c4c;
    border-color: #ff4c4c;
  }
  .register .step-slider .active .step-name{
    color: #ff4c4c;
  }
  .register .step-slider .step-bg{
    width: 30px; height: 30px;
    background: url('../../public/img/static/bg-register.png') no-repeat 0 0;
    margin: 0 auto;
  }
  .register .step-slider .step-transverse{
    width: 100px; height: 3px;
    background: #e0e0e0;
    margin-top: 14px;
  }
  .register .step-slider .activep{
    background: #ff4c4c;
  }
  .register .step-content{
    width: 450px; height: 350px;
    margin: 0 auto;
    position: relative;
  }
  .register .step-content > div{
    position: absolute;
  }
  .register .step-content .same-div{
    width: 300px; height: 300px;
    top: 50%; left: 50%;
    margin: -150px 0 0 -150px;
  }
  .register .step-content .diff-div{
    width: 400px; height: 300px;
    top: 50%; left: 50%;  
    margin: -150px 0 0 -200px;
  }
  .register .input-carrier{
    position: relative;
  }
  .register .input-carrier + .input-carrier{
    margin-top: 30px;
  }
  .register .input-carrier i{
    position: absolute;
    right: 10px;
    cursor: pointer;
  }
  .register .input-carrier .clear{
    width: 11px; height: 11px;
    background-position: -32px 0;
    top: 15px;
  }
  .register .input-carrier .clear:hover{
    background-position: -58px 0;
  }
  .register .input-carrier .success{
    width: 16px; height: 16px;
    background-position: -214px 0;
    top: 13px;
  }
  .register .input-carrier .close-eyes{
    width: 18px; height: 10px;
    background-position: -110px 0;
    top: 17px;
  }
  .register .input-carrier .close-eyes:hover{
    background-position: -136px 0;
  }
  .register .input-carrier .open-eyes{
    width: 20px; height: 14px;
    background-position: -162px 0;
    top: 13px;
  }
  .register .input-carrier .open-eyes:hover{
    background-position: -188px 0;
  }
  .register .input-carrier input{
    width: 300px;
    padding: 12px 10px;
    color: #333;
    box-sizing: border-box;
    outline: 0;
    border: 1px solid #ccc;
  }
  .register .input-carrier .border{
    border-color: #ee3b3b;
  }
  .register .input-carrier .msg{
    color: #333;
    font-size: 13px;
    position: absolute;
  }
  .register .same-a{
    display: block;
    width: 300px; height: 45px;
    line-height: 45px;
    text-align: center;
    box-sizing: border-box;
  }
  .register .verification{
    color: #555;
    border: 1px solid #ddd;
    margin-top: 30px;
  }
  .register .verification:hover{
    color: #ee3b3b;
    border: 1px solid #ee3b3b;
  }
  .register .step-next{
    color: #fff;
    font-size: 18px;
    margin: 50px 0 20px;
    background: #ff4c4c;
    border: 1px solid #ee3b3b;
  }
  .register .step-next:hover{
    background: #ee3b3b;
  }
  .register .company a{
    font-size: 14px;
    color: #2875cc;
  }
  .register .company i{
    width: 16px; height: 16px;
    background-position:  -84px 0;
    margin: -2px 5px 0 0;
  }
  .register .step-content .step3-c{
    color: #555555;
  }
  .register .step-content .step3-c .congratulate{
    font-size: 22px;
    font-weight: 700;
  }
  .register .step-content .step3-c .congratulate span{
    color: #FF4C4C;
    font-size: 20px;
  }
  .register .step-content .step3-c .shop{
    margin: 20px 0 30px;
  }
  .register .step-content .step3-c .goshop{
    display: block;
    width: 60px; height: 35px;
    line-height: 35px;
    text-align: center;
    color: #fff;
    font-size: 14px;
    margin-bottom: 20px;
    background: #ff4c4c;
    border-radius: 3px;
    border: 1px solid #ee3b3b;
    box-sizing: border-box;
  }
  .register .step-content .step3-c .goshop:hover{
    background: #ee3b3b;
  }
  .register .step-content .step3-c span{
    margin-right: 3px;
  }
</style>

<script>
import { mapMutations } from 'vuex';
// watch主要负责正则验证，blur主要负责非空验证
export default {
  data(){
    return {
      stepChose:[1],  // 当前正在第几步，包含几个元素就在第几步，数组是为了方便绑定active类
      stepContent:1,  // 当前步骤的内容
      phone:'',       // 常用手机号
      phoneMsg:'',    // 手机号失败、成功提示
      phoneState:0,   // 手机号状态，非空、正则验证是否通过【可以点击验证按钮的条件，通过后，才可以点击验证按钮进行查重验证】
      phoneCheck:0,   // 查重验证是否通过【可以点击下一步的条件，查重验证通过后，才可以点击下一步】
      phoneIconShow:-1,  // 显示input结尾的叉子0、对勾1、隐藏-1
      phoneBorder:false, // phone border类【由于border类不能通用，所以我们给每一个input，创建专属的border类变量】
      username:'',    // 用户名
      userMsg:'',     // 用户名失败、成功提示
      userState:0,    // 用户名状态，非空、正则验证是否通过
      userCheck:0,    // 查重验证是否通过
      userIconShow:-1,   // 显示input结尾的叉子0、对勾1、隐藏-1
      userBorder:false,  // user border类
      pwdShow:-1,     // 改变type类型，实现密码的显示与隐藏，并改变睁眼闭眼图案
      password:'',    // 密码
      pwdMsg:'',      // 密码失败、成功提示
      pwdState:0,     // 密码状态，非空、正则验证是否通过
      pwdBorder:false,   // pwd border类
      timer:'',       // 定时器
      n:10            // 计数器
    }
  },
  methods:{
    ...mapMutations(["setUserName"]),

    numValid(phone){
      // 把所有非数字替换为空字符
      this.phone = phone.replace(/[^\d]/g,'');
    },
    phoneMsgShow(str){
      if(str == 'focus'){
        this.phoneMsg = `验证完成后，你可以使用该手机登录或找回密码`;
        this.phoneBorder = false;
      }else if(str == 'blur'){
        if(this.phone == ''){
          this.phoneMsg = `<span style="color: #ff4c4c">手机号码不能为空</span>`;
          this.phoneBorder = true;
        }else if(this.phoneState != 1){
          this.phoneMsg = `<span style="color: #ff4c4c">手机号码格式有误，请重新输入</span>`
          this.phoneBorder = true;
        }else if(this.phoneState == 1){
          this.phoneMsg = '';
        }
      }
    },
    userMsgShow(str){
      if(str == 'focus'){
        this.userMsg = `4-20个字符，建议由汉字字母，数字与"-"、"_"组成`;
        this.userBorder = false;
      }else if(str == 'blur'){
        if(this.username == ''){
          this.userMsg = `<span style="color: #ff4c4c">请输入用户名</span>`;
          this.userBorder = true;
        }else if(this.userState != 1){
          this.userMsg = `<span style="color: #ff4c4c">用户名长度只能在4-20个字符之间</span>`
          this.userBorder = true;
        }else if(this.userState == 1){
          if(this.userCheck == 1){
            this.userMsg = `<span style="color: #6CBC4E">该用户名可以使用</span>`
          }else{
            this.userMsg = `<span style="color: #ff4c4c">该用户名已存在，请重新输入</span>`
            this.userBorder = true;
          }
        }
      }
    },
    pwdMsgShow(str){
      if(str == 'focus'){
        this.pwdMsg = `6-20个字符组成`;
        this.pwdBorder = false;
      }else if(str == 'blur'){
        if(this.password == ''){
          this.pwdMsg = `<span style="color: #ff4c4c">请输入密码</span>`;
          this.pwdBorder = true;
        }else if(this.pwdState != 1){
          this.pwdMsg = `<span style="color: #ff4c4c">密码长度只能在6-20个字符之间</span>`
          this.pwdBorder = true;
        }else if(this.pwdState == 1){
          this.pwdMsg = `<span style="color: #6CBC4E">该密码可以使用</span>`
        }
      }
    },
    stepNext(n){
      if(n==1){
        // n=1，当前处于步骤1，先判断验证按钮是否通过
        if(this.phoneCheck != 1){
          this.phoneMsg = `<span style="color: #ff4c4c">手机号码验证并未通过，请继续验证</span>`
          return;
        }
        // 把步骤2填入数组中（用于给本步骤添加背景图，以及下一个步骤添加active类）
        this.stepChose.push(2);
      }else if(n==2){
        if(this.userCheck != 1){
          this.userMsg = `<span style="color: #ff4c4c">账号验证并未通过，请继续验证</span>`;
          return;
        }else if(this.pwdState != 1){
          this.pwdMsg = `<span style="color: #ff4c4c">密码验证并未通过，请继续验证</span>`;
          return;
        }
        this.stepChose.push(3);
        // 发送注册请求
        this.userRegister();
        // 进入到注册成功页面时，我们打开定时器
        this.timer = setInterval(()=>{
          this.n--;
          if(this.n == 0){
            this.$router.push("/");
          }
        },1000)
      }
      this.stepContent = n+1;
    },
    clearContent(str){
      if(str=='phone'){
        // 清除手机号，并将自身隐藏
        this.phone = '';
        this.phoneIconShow = -1;
      }else if(str=='user'){
        this.username = '';
        this.userIconShow = -1;
      }
    },
    checkPhone(){
      if(this.phoneState != 1){
        this.phoneMsg = `<span style="color: #ff4c4c">请输入正确的手机号码，再验证</span>`
        return;
      }
      this.axios.get('/v1/users/check_phone',{
        params:{
          phone:this.phone
        }
      }).then(res=>{
        let bool = res.data;
        if(bool == "1"){
          this.phoneMsg = `<span>该手机号已存在，您可以使用此手机号直接<a href="#/login" style="color: #2875cc">登录</a></span>`
        }else{
          this.phoneMsg = `<span style="color: #6CBC4E">验证通过，请点下一步</span>`
          this.phoneCheck = 1;
        }
      })
    },
    checkUser(){
      this.axios.get('/v1/users/check_user',{
        params:{
          user:this.username
        }
      }).then(res=>{
        let bool = res.data;
        if(bool == "1"){
          this.userMsg = `<span style="color: #ff4c4c">该用户名已存在，请重新输入</span>`
          this.userBorder = true;
          this.userIconShow = 0;
          this.userCheck = 0;
        }else{
          this.userMsg = `<span style="color: #6CBC4E">该用户名可以使用</span>`
          this.userCheck = 1;
        }
      })
    },
    change_eyes(){
      this.pwdShow = !this.pwdShow;
    },
    userRegister(){
      this.axios.post('/v1/users/reg_user',
      `phone=${this.phone}&username=${this.username}&password=${this.password}`
      ).then(res=>{
        if(res.data == 1){
          // 把用户名存入vuex
          this.setUserName(this.username);
        }
      })
    }
  },
  watch:{
    phone(newValue){
      // 如果用户开始输入值，我们就显示叉子
      // 这里判断''是因为，clearContent清除手机号时仍会触发watch...
      if(newValue != ''){ 
        this.phoneIconShow = 0;
        // 边输入边验证
        let reg = /^1[3-9]\d{9}$/;
        let bool = reg.test(newValue);
        if(bool){
          this.phoneIconShow = 1;
          this.phoneMsg = '';
          this.phoneState = 1;
          this.phoneBorder = false;
        }else{
          this.phoneMsg = `<span style="color: #ff4c4c">手机号码格式有误，请重新输入</span>`;
          this.phoneState = 0;
          this.phoneBorder = true;
          // 如果查重验证成功后，仍然改动手机号，那我们就要重新进行查重验证
          this.phoneCheck = 0;
        }
      }else if(newValue == ''){
        this.phoneMsg = `<span style="color: #ff4c4c">手机号码不能为空</span>`
        this.phoneState = 0;
        this.phoneBorder = true;
        this.phoneIconShow = -1;
        this.phoneCheck = 0;
      }
    },
    username(newValue){
      if(newValue != ''){ 
        this.userIconShow = 0;
        let reg = /^[\u4e00-\u9fa5\w-]{4,20}$/;
        let bool = reg.test(newValue);
        if(bool){
          this.userIconShow = 1;
          this.userMsg = '';
          this.userState = 1;
          this.userBorder = false;
          // 如果非空验证和正则验证都通过了，我们进行查重验证
          this.checkUser();
        }else{
          this.userMsg = `<span style="color: #ff4c4c">用户名长度只能在4-20个字符之间</span>`;
          this.userState = 0;
          this.userBorder = true;
          this.userCheck = 0;
        }
      }else if(newValue == ''){
        this.userMsg = `<span style="color: #ff4c4c">请输入用户名</span>`
        this.userState = 0;
        this.userBorder = true;
        this.userCheck = 0;
        this.userIconShow = -1;
      }
    },
    password(newValue){
      if(newValue != ''){
        this.pwdShow = 0;
        let reg = /^.{6,20}$/;
        let bool = reg.test(newValue);
        if(bool){
          this.pwdMsg = `<span style="color: #6CBC4E">该密码可以使用</span>`;
          this.pwdState = 1;
          this.pwdBorder = false;
        }else{
          this.pwdMsg = `<span style="color: #ff4c4c">密码长度只能在6-20个字符之间</span>`;
          this.pwdState = 0;
          this.pwdBorder = true;
        }
      }else if(newValue == ''){
        this.pwdBorder = `<span style="color: #ff4c4c">请输入密码</span>`
        this.pwdState = 0;
        this.pwdBorder = true;
        this.pwdShow = -1;
      }
    }
  },
  // 当前子组件销毁前，清除定时器
  beforeDestroy() {
    clearInterval(this.timer);
  }
}
</script>