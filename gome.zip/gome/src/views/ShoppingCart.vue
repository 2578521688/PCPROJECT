<template>
  <div class="shoppingcart">
    <div class="head-img w-990">
      <img src="img/static/gwc.png">
    </div>
    <div v-show="shoppingCartList.length == 0" class="nothing w-990 clearfix">
      <i></i>
      <span>购物车内暂无商品，快去<router-link to="/">挑选商品</router-link>吧</span>
    </div>
    <div v-show="shoppingCartList.length != 0" class="distribution w-990 clearfix">
      <div class="fr">
        <div class="freight fl" @mouseenter="label_change" @mouseleave="label_change">
          <div class="label c5e5e5e">
            <i></i>运费说明
          </div>
          <div class="content c999 bgfff" v-show="label_show == 1">
            <p>1、自营（含超市）商品满99元免运费，不满99元时收取5元运费，自提商品不参与运费凑单；</p>
            <p>2、运费与配送方式、配送地址及订单实付金额相关（其中真快乐券、真快乐豆均不可抵扣运费），最终运费以订单确认页为准；</p>
            <p>3、自营部分大家电商品配送到偏远地区时会收取相应远程费用、过桥费、小区进门费等，此类费用不在免费送货服务内，需您自行承担；</p>
            <p>4、自营（不含超市）商品由第三方供应商提供配送服务时免运费；</p>
            <p>5、非自营商品按照商家设置的运费标准收取；</p>
            <div class="rule">
              <router-link to="" class="c666">查看详细规则></router-link>
            </div>
          </div>
        </div>
        <div class="address fr">
          <p class="fl">配送至：</p>
          <div class="region fl">
            <a href="javascript:;" class="c333" @click="open_region_list">{{dist_name}}</a>
          </div>
          <div class="region-list bgfff" v-show="region_chose == 1">
            <div class="select-list">
              <a href="javascript:;" class="c333 fl same" :class="{ active: select_arr[i] == 1 }"
              v-for="(p,i) of dist" :key="i"
              v-show="select_show[i] == 1"
              @click="change_region(i)">
              {{p}}<i></i></a>
              <a href="javascript:;" class="close fr" @click="open_region_list"></a>
            </div>
            <div class="select-box clearfix">
              <span class="fl" v-for="(p,i) of region_arr" :key="i">
                <a href="javascript:;" class="c5e5e5e" @click="next_region(p,i)">{{p}}</a>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-show="shoppingCartList.length != 0" class="properties w-990 c333 clearfix">
      <div class="prop-1 fl pl-20 c333" :class="{ checked: check_all == true }">
        <input type="checkbox" v-model="check_all" class="mr-0" @click="change_check_all">全选
      </div>
      <div class="prop-2 fl">商品信息</div>
      <div class="prop-3 fl w-117">单价</div>
      <div class="prop-4 fl w-117">数量</div>
      <div class="prop-5 fl w-117">小计</div>
      <div class="prop-6 fl w-117">操作</div>
    </div>
    <div v-show="shoppingCartList.length != 0" class="container">
      <div class="header">
        <div class="fl pl-20" :class="{ checked: check_other == true}">
          <input type="checkbox" v-model="check_other" @click="change_check_other">
        </div>
        <div class="fl">真快乐网店</div>
        <div class="fl">
          <router-link to="" class="c333"><i></i>在线客服</router-link>
        </div>
      </div>
      <ul>
        <li v-for="(p,i) of shoppingCartList" :key="i" class="clearfix goods" :class="{bgfffaf4: check_model.indexOf(p.us_pid) != -1}">
          <div class="fl pl-20" :class="{ checked: check_model.indexOf(p.us_pid) != -1}">
            <input type="checkbox" v-model="check_model" :value="p.us_pid">
          </div>
          <div class="fl column-1">
            <img :src="`img/${p.us_img}`">
          </div>
          <div class="fl column-2">
            <div class="name c333">{{p.us_name}}</div>
            <div class="yanbao c888" v-show="p.us_guarantee != '' && p.us_guarantee != undefined">{{p.us_guarantee}}</div>
            <div class="fenqi c888" v-show="p.us_stages != '' && p.us_stages != undefined">{{p.us_stages}}</div>
          </div>
          <div class="fl column-3">
            <div class="color" v-show="p.us_color != '' && p.us_color != undefined">颜色 ：{{p.us_color}}</div>
            <div class="capacity" v-show="p.us_capacity != '' && p.us_capacity != undefined">容量 ：{{p.us_capacity}}</div>
          </div>
          <div class="fl column-4">
            <div class="price c333">{{ p.us_db == '' || p.us_db == undefined ? '本区域暂不可售' : `&yen; ${Number(p.us_price).toFixed(2)}`}}</div>
          </div>
          <div class="fl column-5 bgfff">
            <div class="limit c5e5e5e bgfff" v-show="buy_count[i] == 99">
              <div class="sanjiao"></div>
              您最多能购买99件
            </div>
            <a href="javascript:;" @click="change_count(i,'sub')" :class="{ disabled: buy_count[i] == 1 }">-</a>
            <input type="text" v-model="buy_count[i]" @input="num_valid($event,i)">
            <a href="javascript:;" @click="change_count(i,'add')" :class="{ disabled: buy_count[i] == 99 }">+</a>
            <div class="out-of-stock ce3101e" v-show="p.us_db == '' || p.us_db == undefined">无货</div>
          </div>
          <div class="fl column-6">
            <div class="subtotal">{{p.us_db == '' || p.us_db == undefined ? `&yen; 0.00` : `&yen; ${(p.us_price*buy_count[i]).toFixed(2)}`}}</div>
          </div>
          <div class="fl column-7">
            <a href="javascript:;" class="c333" @click="pro_delete(i,p.us_pid)">删除</a>
          </div>
        </li>
      </ul>
    </div>
    <div v-show="shoppingCartList.length != 0" class="settle-accounts">
      <div class="w-990 clearfix line-60">
        <div class="fl pl-20 c333" :class="{ checked: check_all == true }">
          <input type="checkbox" v-model="check_all" @click="change_check_all">全选
        </div>
        <div class="fl column-1">
          <a href="javascript:;" class="c333" @click="pro_delete_select">删除</a>
        </div>
        <div class="fr line-60">
          <div class="fl column-2 c333 line-60">
            已选<span class="ce3101e">{{check_model.length}}</span>件商品
          </div>
          <div class="fl column-3 c333 line-60">
            总计（不含运费）：<span class="ce3101e">&yen;{{total.toFixed(2)}}</span>
          </div>
          <div class="fl column-4 line-60">
            <router-link to="" class="bge3101e">去结算<i></i></router-link>
          </div>
        </div>
      </div>
    </div>
    <!-- 购物车底部 -->
    <sc-bottom></sc-bottom>

    <div class="del-mask" v-show="del_mask == 1">
      <div class="del-popup bgfff">
        <a href="javascript:;" class="fr" @click="close_mask"><i></i></a>
        <div class="body clearfix">
          <div class="fl"><i></i></div>
          <div class="fl del">
            <p class="title">删除商品！</p>
            <p v-if="del_mode == 1 && check_model.length == 0">至少选中一件商品才可删除</p>
            <p v-else-if="del_mode == 1">确定要删除选中商品吗？</p>
            <!-- 不使用v-show 而用v-if 防止报TypeError: Cannot read property 'us_name' of undefined -->
            <p v-if="del_mode == 0" class="us_name">确定要删除{{shoppingCartList[del_index].us_name}}吗？</p>
          </div>
        </div>
        <div class="btns" v-show="check_model.length != 0">
          <a href="javascript:;" class="c333 cancel bgfff" @click="close_mask">取消</a>
          <a href="javascript:;" class="enter cfff bge3101e" @click="btn_chose(1)" v-show="del_mode == 1">确定</a>
          <a href="javascript:;" class="enter cfff bge3101e" @click="btn_chose(0)" v-show="del_mode == 0">确定</a>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .shoppingcart .w-990{
    width: 990px;
    margin: 0 auto;
    border-radius: 3px;
  }
  .shoppingcart i{
    display: inline-block;
    vertical-align: middle;
    background: url('../../public/img/static/sprite.png') no-repeat;
  }
  .shoppingcart .cfff{
    color: #fff;
  }
  .shoppingcart .bgfff{
    background: #fff;
  }
  .shoppingcart a:hover{
    color: #e3101e;
  }
  .shoppingcart .ce3101e{
    color: #e3101e;
  }
  .shoppingcart .bge3101e{
    background: #e3101e;
  }
  .shoppingcart .c5e5e5e{
    color: #5e5e5e;
  }
  .shoppingcart .c999{
    color: #999;
  }
  .shoppingcart .c666{
    color: #666;
  }
  .shoppingcart .c333{
    color: #333;
  }
  .shoppingcart .c888{
    color: #888;
  }
  .shoppingcart .pl-20{
    padding-left: 20px;
  }
  .shoppingcart input[type=checkbox]{
    width: 12px; height: 12px;
    margin-right: 10px;
    text-align: center;
    border: 0; outline: 0;
    position: relative;
    cursor: pointer;
  }
  .shoppingcart input[type=checkbox]::before{
    content: "";
    position: absolute;
    top: 0; left: 0;
    background: #fff;
    width: 12px; height: 12px;
    border: 1px solid #ccc;
  }
  .shoppingcart .checked input[type=checkbox]::before{
    content: "\2713";
    position: absolute;
    top: 0; left: 0;
    width: 12px; height: 12px;
    line-height: 12px;
    border: 1px solid #FF5757;
    background: #FF5757;
    color: #fff;
    font-weight: bold;
    font-size: 12px;
  }
  .shoppingcart label{
    cursor: pointer;
  }
  .shoppingcart .head-img{
    overflow: hidden;
  }
  .shoppingcart .head-img img{
    margin-left: -1px;
  }
  .shoppingcart .nothing{
    border: 1px solid #e6e6e6;
    text-align: center;
    padding: 56px 0;
  }
  .shoppingcart .nothing a{
    color: #069;
    margin: 0 3px;
  }
  .shoppingcart .nothing a:hover{
    text-decoration: underline;
  }
  .shoppingcart .nothing i{
    width: 71px; height: 54px;
    background-position: -626px 0;
    margin-right: 10px;
  }
  .shoppingcart .distribution > .fr{
    width: 448px; height: 26px;
    line-height: 26px;
    padding: 10px 0;
  }
  .shoppingcart .distribution .fr > div{
    position: relative;
  }
  .shoppingcart .distribution .label{
    cursor: pointer;
  }
  .shoppingcart .distribution .label > i{
    width: 14px; height: 17px;
    background-position: -307px -83px;
    margin-right: 5px;
  }
  .shoppingcart .distribution .content{
    position: absolute;
    width: 460px;
    top: 23px; right: -9px;
    padding: 30px 20px 10px;
    border: 1px solid #ccc;
    line-height: 20px;
  }
  .shoppingcart .distribution .content > p+p{
    margin-top: 5px;
  }
  .shoppingcart .distribution .content .rule{
    margin-top: 10px;
    text-align: right;
  }
  .shoppingcart .distribution .content .rule a:hover{
    text-decoration: underline;
  }
  .shoppingcart .distribution .address .region{
    height: 24px;
    line-height: 24px;
    border: 1px solid #e5e5e5;
    margin-left: 5px;
    padding: 0 5px;
  }
  .shoppingcart .distribution .address .region a{
    background: url('../../public/img/static/new-cart-arrow.png') no-repeat right 3px;
    padding-right: 16px;
  }
  .shoppingcart .distribution .address .region-list{
    position: absolute;
    top: 30px; right: 0;
    width: 390px;
    padding: 10px;
    border: 1px solid #dedede;
    box-shadow: 0 0 5px 1px lightgrey;
  }
  .shoppingcart .region-list .select-list{
    border-bottom: 1px solid #e6e6e6;
    height: 27px;
    line-height: 27px;
  }
  .shoppingcart .region-list .select-list > .same{
    border: 1px solid #fff;
    border-bottom-color: #e6e6e6;
    height: 25px;
    line-height: 25px;
    padding-left: 10px;
    position: relative;
    bottom: -1px;
    z-index: 1;
  }
  .shoppingcart .region-list .select-list > .same > i{
    width: 6px; height: 5px;
    background: url('../../public/img/static/ui3.png') no-repeat 0 -12px;
    margin: 0 5px;
  }
  .shoppingcart .region-list .select-list > .close{
    width: 12px; height: 12px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -664px;
  }
  .shoppingcart .region-list .select-list .active{
    border-color: #e6e6e6;
    border-bottom-color: #fff;
  }
  .shoppingcart .region-list .select-list .active > i{
    background-position: -6px -12px;
  }
  .shoppingcart .region-list .select-box{
    margin-top: 10px;
    padding-left: 10px;
  }
  .shoppingcart .region-list .select-box > span{
    width: 95px; height: 26px;
    line-height: 26px;
  }
  .shoppingcart .region-list .select-box > span > a{
    padding: 3px 5px;
  }
  .shoppingcart .region-list .select-box > span > a:hover{
    background: #e3101e;
    color: #fff;
  }
  .shoppingcart .properties{
    width: 988px; height: 44px;
    line-height: 44px;
    border: 1px solid #e6e6e6;
    background: #eee;
  }
  .shoppingcart .properties .prop-1{
    width: 110px;
  }
  .shoppingcart .properties .prop-2{
    width: 390px;
  }
  .shoppingcart .properties .w-117{
    width: 117px;
    text-align: center;
  }
  .shoppingcart .container{
    width: 988px;
    border: 1px solid #ddd;
    border-radius: 3px;
    margin: 10px auto 0;
  }
  .shoppingcart .container .header{
    height: 38px;
    line-height: 38px;
    border-bottom: 1px solid #e6e6e6;
  }
  .shoppingcart .header>:nth-child(2){
    font-weight: 700;
    margin-right: 8px;
  }
  .shoppingcart .header>:nth-child(3) > a > i{
    width: 20px; height: 21px;
    background: url('../../public/img/static/service_3.png') no-repeat;
    margin-right: 5px;
  }
  .shoppingcart .container .goods{
    background: #fff;
    padding: 20px 0;
  }
  .shoppingcart .container .bgfffaf4{
    background: #fffaf4;
  }
  .shoppingcart .goods > div:not(:first-child):not(:nth-child(2)){
    margin-top: 5px;
  }
  .shoppingcart .goods .column-1{
    margin-right: 10px;
  }
  .shoppingcart .goods .column-1 img{
    display: block;
    width: 80px; height: 80px;
    border: 1px solid #e6e6e6;
    image-rendering: -webkit-optimize-contrast; /* 解决图片缩放时造成的模糊 */
  }
  .shoppingcart .goods .column-2{
    width: 220px;
  }
  .shoppingcart .goods .column-2 .name{
    height: 38px;
    line-height: 19px;
  }
  .shoppingcart .goods .column-3{
    width: 100px;
    color: #a7a7a7;
    margin-left: 45px;
  }
  .shoppingcart .goods .column-4{
    width: 84px;
    margin-left: 50px;
  }
  .shoppingcart .goods .column-5{
    position: relative;
    margin-left: 24px;
    height: 20px;
    line-height: 20px;
    border: 1px solid #ccc;
    text-align: center;
  }
  .shoppingcart .goods .column-5 .limit{
    position: absolute;
    top: -46px; right: -50px;
    box-shadow: 0 0 8px rgba(0, 0, 0, .2);
    border: 1px solid #e1e1e1;
    padding: 7px 10px;
    font-weight: 500;
  }
  .shoppingcart .goods .column-5 .sanjiao{
    position: absolute;
    top: 34px;  right: 50px;
    border: 8px solid transparent;
    border-top-color: #fff;
  }
  .shoppingcart .goods .column-5 > a{
    display: inline-block;
    width: 15px; 
    color: #666;
  }
  .shoppingcart .goods .column-5 > input{
    width: 50px; height: 20px;
    border: 0; outline: 0;
    border-left: 1px solid #ccc;
    border-right: 1px solid #ccc;
    text-align: center;
  }
  .shoppingcart .goods .column-5 .disabled{
    cursor: not-allowed;
    color: #ddd;
  }
  .shoppingcart .goods .column-5 .out-of-stock{
    margin-top: 5px;
  }
  .shoppingcart .goods .column-6{
    width: 100px;
    font-weight: 700;
    font-size: 14px;
    margin-left: 42px;
  }
  .shoppingcart .goods .column-7{
    margin-left: 30px;
  }
  .shoppingcart .settle-accounts{
    margin-top: 20px;
    background: #f3f3f3;
  }
  .shoppingcart .settle-accounts .line-60{
    height: 60px;
    line-height: 60px;
  }
  .shoppingcart .settle-accounts .column-1{
    margin-left: 20px;
  }
  .shoppingcart .settle-accounts .column-2 span{
    font-size: 14px;
    font-weight: 900;
    margin: 0 3px;
  }
  .shoppingcart .settle-accounts .column-3{
    margin: 0 30px;
  }
  .shoppingcart .settle-accounts .column-3 span{
    font-size: 18px;
    font-weight: 700;
    margin-top: 1px;
  }
  .shoppingcart .settle-accounts .column-4{
    width: 136px;
    text-align: center;
  }
  .shoppingcart .settle-accounts .column-4 a{
    display: block;
    font-size: 16px;
    font-weight: 700;
    transition: background-color .3s;
    color: #fff; /* 方便挤掉hover */
  }
  .shoppingcart .settle-accounts .column-4 a:hover{
    background: #ff5757;
  }
  .shoppingcart .settle-accounts .column-4 i{
    width: 12px; height: 15px;
    margin-left: 6px;
    background-position: -232px -84px;
  }
  .shoppingcart .del-popup{
    position: fixed;
    top: 50%; left: 50%;
    width: 395px; 
    margin-top: -66px;
    margin-left: -197px;
    box-shadow: 0 0 23px #000;
    z-index: 1000;
  }
  .shoppingcart .del-popup > a > i{
    width: 12px; height: 12px;
    background-position: -931px -54px;
    margin: 10px;
  }
  .shoppingcart .del-popup > a:hover > i{
    background-position: -924px 0;
  }
  .shoppingcart .del-popup .body{
    padding: 20px 30px;
  }
  .shoppingcart .del-popup .body i{
    width: 39px; height: 39px;
    background-position: -837px -39px;
  }
  .shoppingcart .del-popup .body .del{
    width: 250px; height: 39px;  /* 脱离文档流后，不设置宽度，则靠内容撑开，由于商品名太长，如果不自定义长度和溢出隐藏，则会冲垮布局 */
    margin-left: 15px;
  }
  .shoppingcart .del-popup .body .del .us_name{
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .shoppingcart .del-popup .body .title{
    font-weight: 700;
    font-size: 14px;
  }
  .shoppingcart .del-popup .btns{
    text-align: center;
    height: 32px;
    padding-bottom: 20px;
  }
  .shoppingcart .del-popup .btns a{
    display: inline-block;
    padding: 6px 12px;
    border: 1px solid transparent;
    border-radius: 2px;
  }
  .shoppingcart .del-popup .btns .cancel{
    margin-right: 10px;
    border-color: #ddd;
  }
  .shoppingcart .del-popup .btns .enter{
    border-color: #e3101e;
  }
  .shoppingcart .del-popup .btns .enter:hover{
    background: #ff5757;
    border-color: #ff5757;
    color: #fff;
  }
  .shoppingcart .del-mask{
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, .5);
    z-index: 999;
  }
</style>

<script>
import { mapState } from 'vuex';
import scBottom from '../components/SCBottom.vue';
export default {
  components:{ scBottom },
  data(){
    return{
      label_show:0,       // 运费说明
      province:[],        // 省份列表
      city:[],            // 城市列表
      dis_cou:[],         // 区县列表
      region_arr:[],      // 当前遍历的地区列表
      dist_i:[],          // 配送地址（省市县下标数组，用于select-box）
      dist:[],            // 配送地址（省市县名称数组，用于select-list）
      dist_name:'',       // 配送地址（具体名称，用于region）
      select_arr:[0,0,1], // 用于给当前选择的省市县名称添加active类，因为有地址，所以给区县
      select_show:[1,1,1],// 用于控制当前选择的省市县名称的显示隐藏，因为有地址，所以全都显示
      region_chose:0,     // 是否打开地区选择列表
      check_all:true,     // 全选框
      check_model:[],     // 除全选外的其他复选框（商品）
      check_other:true,   // 其他复选框（真快乐网店）
      buy_count:[],       // 每个商品的购买数量（因为有众多商品，v-model不能只绑定一个变量，所以用数组来代替）
      del_mask:0,         // 删除遮罩层
      del_mode:-1,        // 当前删除方式：0：删除某个商品，1：删除选中商品
      del_index:-1,       // 当前正在删除某个商品的下标
      del_id:-1,          // 当前正在删除某个商品的us_pid（用于删除复选框内的value值）
    }
  },
  methods:{
    label_change(){
      this.label_show = !this.label_show;
    },
    get_dist_name(){
      // 拼接前，清空字符，不然会跟上一个地址累加
      this.dist_name = '';
      for(let str of this.dist){
        this.dist_name += str;
      }
    },
    change_region(index){
      // 给当前点击的地区列表添加class类
      this.$set(this.select_arr,index,1);
      // 当前点击的地区列表
      if(index==0){ 
        // 省份
        this.region_arr = this.province;
      }else if(index == 1){ 
        // 城市                      // 当前省份
        this.region_arr = this.city[this.dist_i[0]];
      }else if(index == 2){
        // 区县                         // 当前省份    当前城市
        this.region_arr = this.dis_cou[this.dist_i[0]][this.dist_i[1]]
      }
      // 去除其余列表的class类
      this.select_arr.forEach((ele,i)=>{
        if(i!=index){
          this.$set(this.select_arr,i,0);
        }
      })
    },
    next_region(p,pi){
      let index = -1;
      // 先遍历，看看当前选择的地区列表是哪个
      this.select_arr.forEach((ele,i)=>{
        if(ele == 1) index = i;
      })
      // 如果我们要重新选省份，会先把原来的城市和区县列表重置
      if(index == 0){
        this.select_arr = [1,0,0];
        this.select_show = [1,0,0];
        this.$set(this.dist,1,'请选择');
        this.$set(this.dist,2,'请选择');
      }
      // 清除当前列表的active类
      this.$set(this.select_arr,index,0);
      // 更新地区名称,下标 及 列表
      this.$set(this.dist,index,p);
      this.$set(this.dist_i,index,pi);
      if(index!=this.select_arr.length-1){
        this.$set(this.select_arr,index+1,1); // 添加active类
        this.$set(this.select_show,index+1,1);// 地区列表显示
      }
      // 遍历新的数组
      if(index == 0){
        // 遍历城市 0+1 = 1
        this.region_arr = this.city[pi];
      }else if(index == 1){
        // 遍历区县 1+1 = 2            // 当前所选省份
        this.region_arr = this.dis_cou[this.dist_i[0]][pi];
      }else if(index == 2){
        // 拼接成完整的地区名称，显示在页面上
        this.get_dist_name();
        // 关闭地区选择列表
        this.region_chose = 0;
      }
    },
    open_region_list(){
      this.region_chose = !this.region_chose;
      // 如果配送地址已经设置完毕，那么我们每次打开就给区县列表添加active类
      if(this.dist_name != '请选择您的收货地址'){
        this.select_arr = [0,0,1];
      }
    },
    server_change(){
      this.server_show = !this.server_show;
    },
    change_count(i,str){
      // 先获取商品对象
      let obj = this.shoppingCartList[i];
      let quantity;
      if(str == 'add' && obj.us_count < 99){
        quantity = obj.us_count + 1;           // 数量+1
        
      }else if(str == 'sub' && obj.us_count > 1){
        quantity = obj.us_count - 1;           // 数量-1
      }
      // 符合任意一个条件时，才存数据
      if(quantity != undefined){
        this.updata_count(obj,quantity);       // 存入数据库
        this.$set(this.buy_count,i,quantity);  // 存入data中的数组
        obj.us_count = quantity;               // 最后把购买数量添加回原商品对象中存储，用于下次增减 以及 刷新重新显示
      }
    },
    updata_count(obj,quantity){
      // 判断是不是 通过 中转站加入的商品
      let formData;
      if(obj.us_db == undefined || obj.us_db == ''){
        formData = `quantity=${quantity}&name=${obj.us_name}&uid=${this.uid}&code=2`;
      }else{
        let guarantee = obj.us_guarantee.replace('+','%2B');
        formData = `quantity=${quantity}&name=${obj.us_name}&capacity=${obj.us_capacity}&color=${obj.us_color}&guarantee=${
        guarantee}&stages=${obj.us_stages}&uid=${this.uid}&code=1`;
      }
      this.axios.put('/v1/products/quantity_superposition',formData).then(res=>{
        if(res.data == 1){
          console.log(`数据库商品数量已更新`);
        }
      })
    },
    num_valid(e,i){
      let str = e.target.value;
      let count = Number(str.replace(/[^\d]/g,'')); // \d是数字 ^\d非数字 [^]是否定运算 []表示一位 全局查找每一位非数字的字符，并替换为空字符（只保留数字）
      if(count > 99) count = 99;
      else if(count == 0) count = 1;   // 防止用户删除数量，因为是数组，不用watch监视了
      // 存入data中的数组
      this.buy_count[i] = count;
      // 存入数据库
      let obj = this.shoppingCartList[i];
      this.updata_count(obj,count);
      // 更新回原对象中
      obj.us_count = count;
    },
    pro_delete(i,id){
      this.del_mask = 1;    // 打开删除遮罩层
      this.del_mode = 0;    // 设置删除方式
      this.del_index = i;   // 记录要删除的商品下标
      this.del_id = id;     // 记录要删除的商品us_pid
    },
    delete_data(obj){
      let paramsObj;
      if(obj.us_db == undefined || obj.us_db == ''){
        paramsObj = {
          name: obj.us_name,
          uid: this.uid,
          code: 2
        }
      }else{
        let guarantee = obj.us_guarantee.replace('+','%2B');
        paramsObj = {
          name: obj.us_name,
          capacity: obj.us_capacity,
          color: obj.us_color,
          guarantee: guarantee,
          stages: obj.us_stages,
          uid: this.uid,
          code: 1
        }
      }
      this.axios.delete('/v1/products/del_commodity',{params:paramsObj}).then(res=>{
        if(res.data == "1"){
          console.log('数据库商品删除');
        }
      })
    },
    change_check_all(){
      // @click 优先于 v-model执行，所以我们通过click获取到的数据，要进行取反
      let ca = !this.check_all;
      if(ca == true){
        // 选中真快乐网店
        this.check_other = true;
        // 遍历商品列表，把对应的value值添加进数组中，即可选中所有商品复选框
        this.check_model = [];  // 先把用户原先点击的几个复选框value值清空，以免重复填入数组中
        for(let obj of this.shoppingCartList){
          this.check_model.push(obj.us_pid);
        }
      }else{
        this.check_model = [];
        this.check_other = false;
        this.check_all = false;
      }
    },
    change_check_other(){
      let co = !this.check_other;
      if(co == true){
        this.check_model = [];
        for(let obj of this.shoppingCartList){
          this.check_model.push(obj.us_pid);
        }
        this.check_all = true;
      }else{
        this.check_all = false;
        this.check_model = [];
      }
    },
    pro_delete_select(){
      this.del_mask = 1;    // 打开删除遮罩层
      this.del_mode = 1;    // 设置删除方式
    },
    close_mask(){
      // 关闭删除遮罩层
      this.del_mask = 0; 
    },
    btn_chose(n){
      if(n == 0){
        // 删除某个商品
        // 获取商品对象
        let obj = this.shoppingCartList[this.del_index];
        // 更新数据库
        this.delete_data(obj);
        // 更新vuex中的购物车数组
        this.shoppingCartList.splice(this.del_index,1);
        // 把对应下标的数量也删掉，不然删除了一个商品，数量就给了下一个商品
        this.buy_count.splice(this.del_index,1);
        // 如果用户点了前面的复选框，但是最终是通过点击商品后面的删除来删除某个商品，那么我们也要把该商品在check_model中对应的value值也删掉
        let index = this.check_model.indexOf(this.del_id); // 先获取value值对应下标
        this.check_model.splice(index,1);
      }else if(n == 1){
        // 删除选中商品
        // 先判断选中那些商品
        if(this.check_model.length == this.shoppingCartList.length){
          // 长度相同表示全部选中，删除全部
          this.axios.delete('/v1/products/del_commodity',{params:{uid:this.uid}}).then(res=>{
            if(res.data == "1"){
              console.log('数据库商品删除');
            }
          })
          this.shoppingCartList.splice(0);
        }else{
          let index = [];
          // 拿出被选中商品的value值 更新数据库，并记录下标
          for(let val of this.check_model){
            this.shoppingCartList.forEach((ele,i)=>{
              if(val == ele.us_pid){
                this.delete_data(ele);
                // 存储下标
                index.push(i);
              }
            })
          }
          // 更新vuex
          // 逆向删除，从最大的下标开始删，不会改变数组前面内容的下标。
          // 先将被选中商品的value值进行大->小排序，再删除
          index.sort((a,b)=>b-a);
          for(let i of index){
            this.shoppingCartList.splice(i,1);
            this.buy_count.splice(i,1);
          }
          // 清空所有选中的value值
          this.check_model = [];
        }
      }
      // 删除完后 恢复默认值
      this.del_mask = 0;
      this.del_mode = -1;
      this.del_index = 0;
      window.scrollTo(0,0); // 返回顶部
    }
  },
  computed:{
    ...mapState(["shoppingCartList","uid"]),

    total(){
      let num = 0;
      for(let obj of this.shoppingCartList){
        // 如果商品没有收货地址，说明他不是从详细页添加的，没有价格
        if(obj.us_db != '' && obj.us_db != undefined){
          num += obj.us_count*obj.us_price;
        }
      }
      return num;
    }
  },
  watch:{
    check_model(newValue){
      // 当复选框的长度 等于 商品列表的长度，表示每一个商品都被选中了
      if(newValue.length == this.shoppingCartList.length){
        // 把全选框和真快乐 都选中
        this.check_all = true;
        this.check_other = true;
      }else{
        this.check_all = false;
        this.check_other = false;
      }
    }
  },
  mounted(){
    if(this.shoppingCartList.length == 0) return;

    if(window.name == ""){
      // 首次加载
      let obj = JSON.parse(sessionStorage.getItem("shopping_params"));
      let dist;
      let dist_i;
      if(obj != null){
        dist = obj.dist;
        dist_i = obj.dist_i;
      }
      window.name = "refresh";
      for(let obj of this.shoppingCartList){
        // 默认全选
        this.check_model.push(obj.us_pid);
        // 配送地址（从数据库请求出来的空值为空字符，从中转站添加进的商品的空值是undefined）
        if(obj.us_db != '' && obj.us_db != undefined){
          // 用户每次通过商品详细页将商品加入购物车，如果收货地址不一样则替换
          this.dist = obj.us_db.split('|');
          this.dist_i = obj.us_dbi.split('|');
        }
      }
      if(this.dist.length == 0){
        // 如果用户删除了所有详细页商品，退出购物车路由又再次进入时，我们就把退出购物车前sessionStorage中保存的地址拿出使用
        this.dist = dist;
        this.dist_i = dist_i;
      }
    }else if(window.name == "refresh"){
      // 页面刷新
      let obj = JSON.parse(sessionStorage.getItem("shopping_params"));
      this.check_model = obj.cm;
      this.dist = obj.dist;
      this.dist_i = obj.dist_i;
    }
    for(let obj of this.shoppingCartList){
      // 添加个数
      this.buy_count.push(obj.us_count);
    }
    
    this.axios.get('/v1/products/get_region').then(res=>{
      for(let str of res.data){
        // 获取省份列表
        this.province.push(str.re_province);
        // 获取城市列表
        let city = str.re_city.split('|');
        this.city.push(city);
        // 获取区县列表
        let dc_arr = [];
        let dis_cou = str.re_dis_cou.split('|');
        for(let str of dis_cou){
          let dc = str.split(',');
          dc_arr.push(dc);
        }
        this.dis_cou.push(dc_arr);
      }
      // 默认遍历区县
      let province = this.dist_i[0];  // 当前所选省份下标
      let city = this.dist_i[1];      // 当前所选城市下标
      this.region_arr = this.dis_cou[province][city];
      this.get_dist_name();
    })

    window.addEventListener('beforeunload',()=>{
      // 存入配送地址、以及被选中的input value值
      let obj = {
        dist: this.dist,
        dist_i: this.dist_i,
        cm: this.check_model
      }
      sessionStorage.setItem("shopping_params",JSON.stringify(obj));
    })
  },
  beforeDestroy(){
    window.name = "";
  }
}
</script>