<template>
  <div class="login">
    <div class="head w-990">
      <img src="img/static/login.png">
      <router-link to=""><i></i>我想对“登录”提意见</router-link>
    </div>
    <div class="safe-tip">
      <div class="w-990">
        <i></i>依据《网络安全法》，为保障您的账户安全和正常使用，请尽快完成手机号验证！新版
        <router-link to="">《真快乐平台隐私政策》</router-link>
        已上线，将更有利于保护您的个人隐私。
      </div>
    </div>
    <div class="content-bg">
      <div class="main">
        <div class="login-box fr">
          <div class="login-head clearfix">
            <a href="javascript:;" class="fl" :class="{ active: loginMode == 0 }" @click="changeLoginMode(0)">扫码登录</a>
            <a href="javascript:;" class="fl" :class="{ active: loginMode == 1 }" @click="changeLoginMode(1)">账户登录</a>
          </div>
          <div class="login-body">
            <div class="saoma" v-show="loginMode == 0">                                                                                       
              <div class="img-carrier">                                                                                <!-- transitionend 事件在 CSS 完成过渡后触发 -->
                <img class="erweima" src="img/static/getQrcode.jpg" @mouseenter="changeTran(1)" @mouseleave="changeTran(0)" @transitionend="isTran && showSao()">
                <img v-show="saoyisao == 1" class="saoyisao" src="img/static/saoyisao.png">
              </div>
              <p class="qrcode-desc">
                打开手机<router-link to="">真快乐</router-link>
              </p>
              <p class="scan-code">扫一扫登录</p>
              <router-link to="/register">免费注册</router-link>
            </div>
            <div class="zhanghu" v-show="loginMode == 1">
              <div class="login-fail login-same-div" v-if="loginState == -1"><i class="login-same-i"></i>账户或密码不正确，请重新输入</div>
              <div class="login-tip login-same-div" v-else><i class="login-same-i"></i>公共场所不建议自动登录，以防账号丢失</div>
              <div class="input-carrier">
                <div>
                  <input class="txt" v-model="userNameOrPhone" type="text" placeholder="手机号码/用户名/邮箱/门店会员卡号" @keyup.13="login">
                  <a href="javascript: this.userNameOrPhone = ''" class="clear" v-show="userNameOrPhone != ''" tabindex="-1"></a>
                </div>
                <div>
                  <input class="txt" v-model="password" type="password" placeholder="密码" @keyup.13="login">
                  <a href="javascript: this.password = '';" class="clear" v-show="password != ''" tabindex="-1"></a>
                </div>
              </div>
              <div class="operation clearfix">
                <div class="fl">
                  <input type="checkbox" id="login"><label for="login">自动登录</label>
                </div>
                <div class="fr">
                  <router-link to="" class="forget">忘记密码</router-link>
                  <span>|</span>
                  <router-link to="/register" class="register">免费注册</router-link>
                </div>
              </div>
              <router-link to="" class="btn-login" @click.native="login">登录</router-link>
              <div class="quick-login">
                <router-link to="">手机号快速登录(支持门店预留手机)</router-link>
              </div>
            </div>
          </div>
          <div class="login-foot">
            <router-link to="">QQ</router-link>
            <router-link to="">微信</router-link>
            <router-link to="">微博</router-link>
            <router-link to="">美付宝</router-link>
            <router-link to="">极信通</router-link>
            <router-link to="">支付宝</router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .login i{
    display: inline-block;
    vertical-align: middle;
    background: url('../../public/img/static/bg-login.png') no-repeat;
  }
  .login .w-990{
    width: 990px; 
    margin: 0 auto;
  }
  .login .head{
    height: 120px;
    overflow: hidden;
    position: relative;
  }
  .login .head img{
    position: absolute;
    top: 50%;
    margin-top: -28px;
    margin-left: -124px;
  }
  .login .head a{
    position: absolute;
    right: 0; bottom: 5px;
    color: #888;
    height: 20px;
    line-height: 20px;
  }
  .login .head a:hover{
    color: #e3101e;
    text-decoration: underline;
  }
  .login .head a i{
    width: 15px; height: 19px;
    margin-right: 8px;
    background-position: 0 -257px;
  }
  .login .safe-tip{
    background: #fff4e3;
    border-top: 1px solid #fee6bc;
  }
  .login .safe-tip > div{
    height: 30px;
    line-height: 30px;
    color: #ff7f23;
    text-align: center;
  }
  .login .safe-tip i{
    width: 16px; height: 16px;
    margin-right: 5px;
    background-position: -28px 0;
  }
  .login .safe-tip a{
    color: #2875cc;
    margin: 0 3px;
  }
  .login .content-bg{
    background: #fff1e8;
  }
  .login .content-bg .main{
    width: 1200px;
    height: 480px;
    margin: 0 auto;
    background: url('../../public/img/static/login-big.jpg') no-repeat;
  }
  .login .main .login-box{
    width: 350px;
    margin-top: 24px;
    margin-right: 105px;
    background: #fff;
  }
  .login .login-box .login-head{
    border-bottom: 1px solid #f4f4f4;
  }
  .login .login-box .login-head a{
    width: 174px; 
    margin: 18px 0;
    font-size: 18px;
    font-weight: 500;
    color: #5e5e5e;
    text-align: center;
  }
  .login .login-box .login-head a:first-child{
    border-right: 1px solid #f4f4f4;
  }
  .login .login-box .login-head .active{
    color: #e3101e;
  }
  .login .login-box .login-body{
    position: relative;
    height: 280px;
  }
  .login .login-box .login-body > div{
    position: absolute;
    /* saoma图片都脱离文档流了，不继承宽度，重新定义一次 */
    width: 350px;
  }
  .login .login-box .login-body .saoma{
    height: 260px;
    padding-top: 20px;
  }
  .login .login-body .saoma .img-carrier{
    height: 173px;
  }
  .login .login-body .saoma .erweima{
    position: absolute;
    left: 50%;
    margin-left: -82px;
    border: 1px solid #e6e6e6;
    transition: .5s;
  }
  .login .login-body .saoma .saoyisao{
    position: absolute;
    right: 15px;
  }
  .login .login-body .saoma .erweima:hover{
    left: 15px;
    margin-left: 0;
  }
  .login .login-body .saoma .qrcode-desc,
  .login .login-body .saoma .scan-code{
    height: 14px;
    line-height: 14px;
    margin-top: 17px;
    color: #5e5e5e;
    text-align: center;
  }
  .login .login-body .saoma .qrcode-desc a{
    color: #ff5757;
    margin-left: 5px;
  }
  .login .login-body .saoma .qrcode-desc a:hover,
  .login .login-body .saoma > a:hover,
  .login .login-box .login-foot a:hover,
  .login .login-body .zhanghu .operation a:hover{
    color: #e3101e;
    text-decoration: underline;
  }
  .login .login-body .saoma .scan-code{
    margin-top: 5px;
  }
  .login .login-body .saoma > a{
    position: absolute;
    right: 10px; bottom: 10px;
    width: 50px; height: 18px;
    line-height: 18px;
    color: #069;
  }
  .login .login-body .zhanghu{
    height: 275px;
    padding-top: 5px;
  }
  .login .login-body .zhanghu .login-same-div{
    width: 270px; height: 24px;
    line-height: 24px;
    margin: 0 auto;
    padding: 0 10px;
  }
  .login .login-body .zhanghu .login-same-i{
    width: 14px; height: 15px;
    margin-right: 5px;
  }
  .login .login-body .zhanghu .login-tip{
    background: #ffeede;
    color: #ff8001;
  }
  .login .login-body .zhanghu .login-tip i{
    background-position: 0 -54px;
  }
  .login .login-body .zhanghu .login-fail{
    background: #fee;
    color: #e3111e;
  }
  .login .login-body .zhanghu .login-fail i{
    background: url('../../public/img/static/bg-login2.png') no-repeat -41px -54px;
  }
  .login .login-body .zhanghu .input-carrier{
    text-align: center;
  }
  .login .login-body .zhanghu .input-carrier > div{
    position: relative;
  }
  .login .login-body .zhanghu .input-carrier a{
    position: absolute;
    width: 12px; height: 12px;
    top: 26px; right: 40px;
    background: url('../../public/img/static/bg-login2.png') no-repeat -20px -90px;
  }
  .login .login-body .zhanghu .input-carrier a:hover{
    background-position: -36px -90px;
  }
  .login .login-body .zhanghu input.txt{
    width: 272px; height: 25px;
    line-height: 25px;
    padding: 8px;
    outline: 0;
    border: 1px solid #ccc;
    margin-top: 10px;
  }
  .login .login-body .zhanghu .operation{
    width: 290px;
    margin: 20px auto;
  }
  .login .login-body .zhanghu .operation input{
    vertical-align: text-top;
  }
  .login .login-body .zhanghu .operation label{
    padding-left: 5px;
    cursor: pointer;
  }
  .login .login-body .zhanghu .operation .fr{
    width: 120px;
  }
  .login .login-body .zhanghu .operation .forget{
    color: #5e5e5e;
  }
  .login .login-body .zhanghu .operation .register{
    color: #2875cc;
  }
  .login .login-body .zhanghu .operation span{
    color: #ccc;
    margin: 0 10px;
  }
  .login .login-body .zhanghu .btn-login{
    display: block;
    width: 290px; height: 42px;
    line-height: 42px;
    text-align: center;
    margin: 0 auto;
    background: #ff5757;
    font-weight: 500;
    font-size: 18px;
    color: #fff;
    word-spacing: 3px; /* 字间距 */
  }
  .login .login-body .zhanghu .btn-login:hover{
    background: #f64949;
  }
  .login .login-body .zhanghu .quick-login{
    width: 290px;
    margin: 15px auto 0;
  }
  .login .login-body .zhanghu .quick-login a{
    color: #2875cc;
  }
  .login .login-body .zhanghu .quick-login a:hover{
    text-decoration: underline;
  }
  .login .login-box .login-foot{
    background: #fcfcfc;
    border: 1px solid #f0f0f0;
    padding: 10px;
    text-align: center;
  }
  .login .login-box .login-foot a{
    color: #5e5e5e;
    padding: 0 8px;
  }
  .login .login-box .login-foot a:not(:last-child){
    border-right: 1px solid #e6e6e6;
  }
</style>

<script>
import { mapState,mapActions,mapMutations } from 'vuex';
export default {
  data(){
    return {
      loginMode:0, // 登录方式
      saoyisao:0,  // 是否显示扫一扫png 
      isTran:true, // 是否添加transitionend事件，true添加，false去除,
      userNameOrPhone:'', // 用户名或手机
      password:'',        // 密码
    }
  },
  methods:{
    ...mapActions(["userLogin"]),
    ...mapMutations(["setLoginState"]),

    changeLoginMode(n){
      this.loginMode = n;
    },
    changeTran(n){
      if(n==1){
        // 鼠标移入时，添加transitionend事件
        this.isTran = true;
      }else if(n==0){
        // 鼠标移出时，去除transitionend事件（如果我们不去除过渡结束事件，那么元素过渡到指定位置后，会触发showSao，元素复原后，还会再次触发showSao）
        this.isTran = false;
        this.saoyisao = 0;
      }
    },
    showSao(){
      this.saoyisao = 1;
    },
    login(){
      let obj = {
        userNameOrPhone:this.userNameOrPhone,
        password:this.password
      }
      this.userLogin(obj);
    }
  },
  computed:{
    ...mapState(["loginState"])
  },
  beforeDestroy(){
    // 如果没登陆成功，离开路由前就把登录状态改回未登录，不然下次进来页面还是登陆失败的提示
    if(this.loginState != 1){
      this.setLoginState(0);
    }
  }
}
</script>