import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '../views/Index.vue'

/* 重复点击路由会在控制台报 NavigationDuplicated: Avoided redundant navigation to current location 这样的错误 
   它的提示是 避免到当前位置的冗余导航。简单来说就是重复触发了同一个路由。比如已经在商品列表页，仍继续通过上面的搜索框搜索同一个关键词，再次进入商品列表页。
   解决方法如下：
*/
const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err);
}

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: Index
  },
  {
    path: '/list/:kw',
    component: () => import( /* webpackChunkName:"list" */ '../views/PList.vue'),
    props: true
  },
  {
    path: '/details/:pid/:kw/:comment/:pname',
    component: () => import( /* webpackChunkName:"details" */ '../views/Details.vue'),
    props: true
  },
  {
    path: '/sctransfer/:lg_pic_prefix/:lg_pic_suffix/:pname/:count/:kw',
    component: () => import( /* webpackChunkName:"sctransfer" */ '../views/SCTransfer.vue'),
    props: true
  },
  {
    path: '/shoppingcart',
    component: () => import( /* webpackChunkName:"shoppingcart" */ '../views/ShoppingCart.vue')
  },
  {
    path: '/login',
    component: () => import( /* webpackChunkName:"login" */ '../views/Login.vue')
  },
  {
    path: '/register',
    component: () => import( /* webpackChunkName:"register" */ '../views/Register.vue')
  },
  {
    path: '*',
    component: () => import( /* webpackChunkName:"notfound" */ '../views/NotFound.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
