<template>
  <div class="carousel">
    <ul class="carousel-box" @mouseenter="stop" @mouseleave="go">
      <li class="pic same" v-for="item of carousel" :key="item.carousel_id" :style="{background}" :class="{ opacity1: n==item.carousel_id }">
        <router-link to="" :title="item.carousel_id">
          <img :src="`img/carousel/${item.carousel_img}`">
        </router-link>
      </li>
      <li class="arrow same">
        <div class="arrow_carrier">
          <a href="javascript:;" class="left" @click="prev"></a>
          <a href="javascript:;" class="right" @click="next"></a>
        </div>
      </li>
      <li>
        <ul class="indicator">
          <li v-for="item of carousel" 
          :key="item.carousel_id" 
          :class="{ active: n==item.carousel_id }" 
          @mouseenter="change(item.carousel_id)">
          </li>
        </ul>
      </li>
    </ul>
  </div>
</template>

<style>
  .carousel .carousel-box{
    width: 100%;
    position: relative;
    height: 450px;
    z-index: 2; /* 防止li盖住 */
  }
  .carousel .carousel-box li.same{
    width: 100%; height: 450px;
    position: absolute;
    left: 0; top: 0;
  }
  .carousel .carousel-box li.pic{
    opacity: 0;
    transition: .7s;
  }
  .carousel .carousel-box li.pic a,
  .carousel .carousel-box li.arrow .arrow_carrier{
    position: absolute;
    left: 50%;
    margin-left: -400px;
  }
  .carousel .carousel-box li.arrow .arrow_carrier{
    width: 750px; height: 450px;
  }
  .carousel .carousel-box li.pic a img{
    display: block;
  }
  .carousel .carousel-box li.opacity1{
    opacity: 1;
    z-index: 1; /* 覆盖其他li */
  }
  .carousel .carousel-box li.arrow a{
    width: 4%; height: 20%;
    background: #000 url('../../public/img/carousel/arrow-left.png') no-repeat center;
    position: absolute;
    top: 40%;
    border-radius: 3px;
    opacity: .2;
    z-index: 2; /* 防止li盖住 */
  }
  .carousel .carousel-box li.arrow a:hover{
    opacity: .5;
  }
  .carousel .carousel-box li.arrow a.left{
    left: 5px;
  }
  .carousel .carousel-box li.arrow a.right{
    right: 5px;
    background-image: url('../../public/img/carousel/arrow-right.png');
  }
  .carousel .carousel-box ul.indicator{
    width: 266px;
    position: absolute;
    left: 50%; bottom: 10px;
    margin-left: -133px;
    z-index: 2; /* 防止li盖住 */
  }
  .carousel .carousel-box ul.indicator > li{
    float: left;
    width: 30px; height: 5px;
    margin: 0 4px;
    cursor: pointer;
    background: #D3D3D3;
  }
  .carousel .carousel-box ul.indicator .active{
    background: #f00;
  }
</style>

<script>
export default {
  data(){
    return {
      n:1,
      carousel:[],
      timer:'',
      background:"rgb(234,237,255)",
      openanimate: true // 只控制carouse-box上的openanimate类，图片上的有自身的判定条件
    }
  },
  methods:{
    go(){
      this.timer = setInterval(()=> {
        if(this.n == this.carousel.length){
          this.n = 1;
        }else{
          this.n++;
        }
      },4000)
    },
    stop(){
      clearInterval(this.timer);
    },
    prev(){
      if(this.n>1){
        this.n--;
      }else{
        this.n = this.carousel.length;
      }
    },
    next(){
      if(this.n<7){
        this.n++;
      }else{
        this.n = 1;
      }
    },
    change(id){
      this.n = id;
    },
    stop_animate(){
      // carousel-box上的openanimate类 动画执行完毕后，去掉该类
      this.openanimate = false;
    }
  },
  watch:{
    n(){
      switch(this.n){
        case 1: this.background = "rgb(234,237,255)";break;
        case 2: this.background = "rgb(0,0,0)";break;
        case 3: this.background = "rgb(229,248,192)";break;
        case 4: this.background = "rgb(236,227,255)";break;
        case 5: this.background = "rgb(233,236,255)";break;
        case 6: this.background = "rgb(232,221,255)";break;
        case 7: this.background = "rgb(255,225,223)";break;
      }
      // 当n发生变化时，我们再给carousel-box添加该类（这样就可以保证每次图片改变时，背景色都有过渡效果）
      this.openanimate = true;
    }
  },
  mounted(){
    this.go();
    this.axios.get("/v1/products/carousel").then(res=>{
      this.carousel = res.data;
    });
  },
  beforeDestroy(){
    clearInterval(this.timer);
  }
}
</script>