<template>
  <div class="everyday">
    <div class="product">
      <div class="product_top">
        <div class="left">
          <i></i>
          <h3>每日必抢</h3>
        </div>
        <div class="right">
          <h3>本场次剩余时间</h3>
          <!-- 定时器 -->
          <count-time :list_switch="list_switch" @get_list="get_list"></count-time>
        </div>
      </div>
      <div class="product_content">
        <ul v-for="(lp,li) of list" :key="li" :class="{opacity1: list_chose == li}">
          <li v-for="p of lp" :key="p.list_id">
            <router-link to="" :title="p.list_name">
              <img :src="`img/every/${p.list_img}`">
              <div class="price">
                <i>&yen;{{p.list_newPrice}}</i>
                <i class="oldPrice">&yen;{{p.list_oldPrice}}</i>
              </div>
             <p class="name">{{p.list_name}}</p>
            </router-link>
          </li>
        </ul>
        <a class="left" href="javascript:;" @click="pageDown"></a>
        <a class="right" href="javascript:;" @click="pageDown"></a>
      </div>
    </div>
    <div class="kitchen">
      <!-- 不用设置a元素的尺寸跟子元素一边大，
      只要是被a包裹的子元素，不管点哪里都会跳转链接 -->
      <router-link to="" title="秒杀">
        <img src="img/static/kitchen.jpg">
      </router-link>
    </div>
  </div>
</template>

<style>
  .everyday{
    width: 1200px; height: 253px;
    background: #fff;
    margin: 20px auto 0;
  }
  .everyday .product{
    /* 950 减去 2px边框 */
    width: 948px; height: 251px;
    float: left;
    border: 1px solid #e6e6e6;
    border-top-color: #b20fd3;
  }
  .everyday .product .product_top{
    height: 40px;
    line-height: 40px;
    border-bottom: 1px solid #e6e6e6;
  }
  .everyday .product_top .left{
    float: left;
    width: 201px; height: 40px;
  }
  .everyday .product_top .left i{
    float: left;
    display: block;
    width: 40px; height: 40px;
    background: url('../../public/img/static/clock.jpg') no-repeat;
    margin-left: 5px;
  }
  .everyday .product_top .left h3{
    float: left;
    font-size: 18px;
    color: #b20fd3;
    font-weight: 500;
  }
  .everyday .product_top .right{
    float: right;
    width: 238px; height: 40px;
  }
  .everyday .product_top .right h3{
    float: left;
    margin-right: 10px;
    font-size: 12px;
    color: #b20fd3;
    font-weight: normal;
  }
  .everyday .product .product_content{
    height: 210px;
    position: relative;
  }
  .everyday .product .product_content ul{
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 210px;
    opacity: 0;
    transition: .7s;
  }
  .everyday .product .product_content .opacity1{
    opacity: 1;
    z-index: 10;
  }
  .everyday .product .product_content ul>li{
    float: left;
    width: 237px; height: 210px;
  }
  .everyday .product_content ul>li a{
    display: block;
    height: 195px;
    border-right: 1px dashed #eee;
    padding-top: 15px;
  }
  .everyday .product_content ul>li:last-child a{
    border-right: 0;
  }
  .everyday .product_content ul li img{
    display: block;
    width: 120px; height: 120px;
    /* (237-120)/2  */
    margin-left: 58px;
  }
  .everyday .product_content ul li .price{
    margin: 6px 0 0 20px;
    font-size: 20px;
    color: #ff0027;
  }
  .everyday .product_content ul li i{
    /* normal为默认值，写在父元素.price中，不能被继承。而italic可以被继承 */
    font-style: normal;
  }
  .everyday .product_content ul li .oldPrice{
    margin-left: 5px;
    font-size: 12px;
    color: #999;
    text-decoration: line-through;
  }
  .everyday .product_content ul li .name{
    /* (237-196)/2 */
    margin-left: 20px;
    color: #5e5e5e;
    width: 196px; height: 18px;
    line-height: 18px;
    /* 缺一不可 */
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .everyday .product_content ul li:hover .name{
    color: #b20fd3;
  }
  .everyday .product_content>a{
    width: 3%; height: 30%;
    background: #000 url('../../public/img/carousel/arrow-left.png') no-repeat center;
    position: absolute;
    top: 50%;
    margin-top: -35px;
    border-radius: 3px;
    opacity: .2;
    z-index: 11;
  }
  .everyday .product_content>a:hover{
    opacity: .5;
  }
  .everyday .product_content .left{
    left: 5px;
  }
  .everyday .product_content .right{
    right: 5px;
    background-image: url('../../public/img/carousel/arrow-right.png');
  }
  .everyday .kitchen{
    /* 242 减去 2px边框 */
    width: 240px; height: 252px;
    float: left;
    margin-left: 8px;
    border: 1px solid #e6e6e6;
    /* 图片上面有一个边框。尺寸是252*240 */
    border-top: 0;
  }
  .everyday .kitchen img:hover{
    opacity: .8;
  }
</style>

<script>
import countTime from '../components/CountTime.vue';
export default {
  components: { countTime },
  data(){
    return {
      list_1:[],
      list_2:[],
      list:[],
      list_chose:0,
      // 数据之间的切换 0：今天 1：明天
      list_switch:1
    }
  },
  methods:{
    pageDown(){
      this.list_chose = this.list_chose==0? 1 : 0;
    },
    // 格式化数据，方便挂载
    list_format(data){
      for(var obj of data){
        // 前4个给list_1，后4个给list_2
        if(this.list_1.length!=4){
          this.list_1.push(obj);
        }else{
          this.list_2.push(obj);
        }
      }
      // 这样做是为了创建多个ul
      this.list.push(this.list_1);
      this.list.push(this.list_2);
    },
    // data就是子组件传递过来的参数
    get_list(data){
      // 重新赋值
      this.list_1 = [];
      this.list_2 = [];
      this.list = [];
      this.list_format(data);
      localStorage.setItem('list_switch',this.list_switch);
      this.list_switch = this.list_switch==1? 0 : 1;
    },
    get_init_Data(){
      this.axios.get("/v1/products/every_grab",{params:{list_switch:0}}).then(res=>{
        this.list_format(res.data);
      })
    }
  },
  mounted(){
    // 1、先判断本地存储中是否含有list_switch
    let list_switch = localStorage.getItem('list_switch');
    if(list_switch != null){
      // 取反，保证下次拿取不同的数据
      this.list_switch = list_switch==1? 0 : 1;
      // 2、再判断list_switch的值
      let data = null;
      if(list_switch == 0){
        data = JSON.parse(localStorage.getItem("today_list"));
      }else if(list_switch == 1){
        data = JSON.parse(localStorage.getItem("tomorrow_list"))
      }
      this.list_format(data);
    }else{
      // 为空，那我们就存入0，并获取今天的数据
      localStorage.setItem('list_switch',0);
      this.get_init_Data();
    }
  }
}
</script>