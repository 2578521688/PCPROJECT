<template>
  <div class="params clearfix">
    <div class="p-left fl">
      <div class="box">
        <div class="title">
          国美{{brand}}产品专营店<i class="service-icon fr"></i>
        </div>
        <div class="logo">
          <router-link to="">
            <img :src="`img/${store_img}`" v-if="store_img != ''">
          </router-link>
        </div>
        <div class="btn">
          <router-link to="">进入店铺</router-link>
          <router-link to="">收藏店铺</router-link>
        </div>
      </div>
      <div class="box">
        <div class="title strong">相关分类</div>
        <div class="sort clearfix">
          <router-link to="" v-for="(p,i) of relevant" :key="i" class="fl">{{p}}</router-link>
        </div>
      </div>
      <div class="box">
        <div class="title strong">同类其他品牌</div>
        <div class="sort clearfix">
          <router-link to="" v-for="(p,i) of other_brand" :key="i" class="fl">{{p}}</router-link>
        </div>
      </div>
    </div>
    <div class="p-right fl">
      <div class="head clearfix">
        <a href="javascript:;" class="fl">商品详情</a>
      </div>
      <div class="content">
        <div class="params-carrier clearfix">
          <div class="params-panel fl">
            <div class="params-item">
              <div class="title">
                <img src="img/params/smallimg/params1.jpg"><span>主体</span><i></i>
              </div>
              <ul>
                <li>
                  <span class="key">品牌：</span>
                  <span>{{body[0]}}</span>
                </li>
                <li>
                  <span class="key">型号：</span>
                  <span>{{body[1]}}</span>
                </li>
                <li>
                  <span class="key">入网许可证编号：</span>
                  <span>{{body[2]}}</span>
                </li>
              </ul>
            </div>
          </div>
          <div class="params-panel fl">
            <div class="params-item">
              <div class="title">
                <img src="img/params/smallimg/params2.jpg"><span>操作系统</span><i></i>
              </div>
              <ul>
                <li>
                  <span class="key">操作系统：</span>
                  <span>{{os}}</span>
                </li>
              </ul>
            </div>
          </div>
          <div class="params-panel fl">
            <div class="params-item">
              <div class="title">
                <img src="img/params/smallimg/params3.jpg"><span>网络</span><i></i>
              </div>
              <ul>
                <li>
                  <span class="key">双卡机类型：</span>
                  <span>{{network}}</span>
                </li>
              </ul>
            </div>
          </div>
          <div class="params-panel fl">
            <div class="params-item">
              <div class="title">
                <img src="img/params/smallimg/params4.jpg"><span>存储</span><i></i>
              </div>
              <ul>
                <li>
                  <span class="key">机身存储：</span>
                  <span>{{memory[0]}}</span>
                </li>
                <li>
                  <span class="key">运行内存</span>
                  <span>{{memory[1]}}</span>
                </li>
              </ul>
            </div>
          </div>
          <div class="params-panel fl ml-0 mt-10">
            <div class="params-item">
              <div class="title">
                <img src="img/params/smallimg/params5.jpg"><span>显示</span><i></i>
              </div>
              <ul>
                <li> 
                  <span class="key">屏幕尺寸</span>
                  <span>{{screen[0]}}</span>
                </li>
                <li>
                  <span class="key">分辨率</span>
                  <span>{{screen[1]}}</span>
                </li>
              </ul>
            </div>
          </div>
          <div class="params-panel fl mt-10">
            <div class="params-item">
              <div class="title">
                <img src="img/params/smallimg/params6.jpg"><span>摄像功能</span><i></i>
              </div>
              <ul>
                <li>
                  <span class="key">后置摄像头：</span>
                  <span>{{camera[0]}}</span>
                </li>
                <li>
                  <span class="key">前置摄像头：</span>
                  <span>{{camera[1]}}</span>
                </li>
                <li>
                  <span class="key">自动对焦：</span>
                  <span>{{camera[2]}}</span>
                </li>
              </ul>
            </div>
          </div>
          <p class="params-more">
            <a href="javascript:;">更多参数 ></a>
          </p>
        </div>
        <div class="img">
          <ul>
            <li v-for="(p,i) of img" :key="i">
              <img :src="`img/${p}`">
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  .params{
    width: 1200px;
    margin: 30px auto 0;
  }
  .params .p-left{
    width: 210px;
    margin-right: 10px;
    font-size: 14px;
  }
  .params .p-left .box{
    width: 208px;
    border: 1px solid #eee;
    background: #fff;
    margin-bottom: 10px;
  }
  .params .p-left .title{
    padding: 8px 9px;
    background: #f6f6f6;
  }
  .params .p-left .service-icon{
    width: 21px; height: 20px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -167px;
  }
  .params .p-left .logo{
    width: 120px; height: 60px;
    margin: 20px auto;
  }
  .params .p-left .logo img{
    display: block;
    width: 120px; height: 40px;
  }
  .params .p-left .btn{
    padding-bottom: 14px;
    text-align: center;
  }
  .params .p-left .btn a{
    display: inline-block;
    color: #5e5e5e;
    border: 1px solid #ddd;
    border-radius: 2px;
    width: 90px; height: 24px;
    line-height: 24px;
  }
  .params .p-left .btn a + a{
    margin-left: 5px;
  }
  .params .p-left .strong{
    color: #666;
    font-weight: 600;
  }
  .params .p-left .sort{
    padding: 10px;
  }
  .params .p-left .sort a{
    width: 94px; height: 30px;
    line-height: 30px;
    color: #666;
  }
  .params .p-right{
    width: 980px;
  }
  .params .p-right .head{
    height: 36px;
    line-height: 36px;
    background: #f6f6f6;
    border: 1px solid #eee;
  }
  .params .p-right .head a{
    height: 34px;
    border-top: 3px solid #e3101e;
    /* 如果不想让文字下沉，那就要加 margin-top: -3px */
    background: #fff;
    color: #e3101e;
    padding: 0 20px;
  }
  .params .p-right .content{
    margin-top: 30px;
    padding: 0 60px;
  }
  .params .p-right .content .params-carrier{
    margin-bottom: 50px;
    position: relative;
  }
  .params .p-right .content .params-panel{
    width: 195px; height: 91px;
  }
  .params .p-right .content .params-panel + .params-panel{
    margin-left: 20px;
  }
  .params .p-right .content .params-carrier .ml-0{
    margin-left: 0;
  }
  .params .p-right .content .params-carrier .mt-10{
    margin-top: 10px;
  }
  /* 如果params-carrier没有具体高度，我们就要除了panel以外再创建一个div用来设置auto，
  不然的话，直接给panel设置:hover auto，就会改变布局，因为没有固定高度了，下面的div就会来回乱动，
  所以我们再写一个item用来设置auto来显示剩下的参数，而用panel当固定高度，用来撑开元素！！ */
  .params .p-right .content .params-item{
    height: 91px;
    /* 防止参数过少时，设置auto时，就缩成一个小块，其实就是为了美观 */
    min-height: 90px;
    position: relative;
  }
  .params .p-right .content .params-item:hover{
    height: auto;
    background: #fff;
    box-shadow:
    0 0 2px rgba(211, 200, 200, .5),
    0 0 0 rgba(211, 200, 200, .5),
    0 0 0 rgba(211, 200, 200, .5),
    0 4px 4px rgba(211, 200, 200, .5);
    z-index: 10;
  }
  .params .p-right .content .params-item:hover i{
    transform: rotate(180deg);
  }
  .params .p-right .content .params-item:hover ul{
    height: auto;
  }
  .params .p-right .content .params-item .title{
    height: 26px;
    line-height: 26px;
    background: #fff8f8;
    color: #ff8e8e;
    position: relative;
  }
  .params .p-right .content .params-item .title img{
    vertical-align: middle;
    margin: -1px 5px 0;
  }
  .params .p-right .content .params-item .title i{
    width: 11px; height: 5px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -1599px;
    position: absolute;
    top: 10px; right: 10px;
    transition: .2s ease-in .1s;
  }
  .params .p-right .content .params-item ul{
    height: 42px;
    padding: 8px 21px 5px 34px;
    overflow: hidden;
    color: #5e5e5e;
  }
  .params .p-right .content .params-item ul li{
    /* height: 21px; 不能设置固定高度，不然有的长文字显示不全 */
    line-height: 21px;
  }
  .params .p-right .content .params-item ul .key{
    font-weight: 700;
  }
  .params .p-right .content .params-carrier > p{
    position: absolute;
    /* 元素脱离文档流，没设置宽度，则靠内容撑开，
    但是同时设置了left: 0; right: 0; 可以把元素撑开，你按照哪个元素做的定位？
    撑开后宽度就跟那个元素的宽度一样 */
    left: 0; right: 0;
    bottom: -20px;
    text-align: right;
    border-bottom: 1px solid #eee;
    padding-bottom: 8px;
  }
  .params .p-right .content .params-carrier > p > a{
    color: #069;
  }
  .params .p-right .content .img img{
    display: block;
    margin: 0 auto;
  }
</style>

<script>
export default {
  props:["pid"],
  data(){
    return {
      brand:"",       // 当前品牌
      body:[],        // 主体
      os:"",          // 操作系统
      network:"",     // 网络
      memory:[],      // 存储
      screen:"",      // 显示
      camera:[],      // 摄像
      img:[],         // 商品详细图片
      relevant:[],    // 相关分类
      other_brand:[], // 其他品牌
      store_img:""    // 商店图片
    }
  },
  mounted(){
    this.axios.get('/v1/products/get_params',{
      params:{
        pid:this.pid
      }
    }).then(res=>{
      let data = res.data[0];
      this.body = data.body.split("|");
      this.brand = this.body[0].slice(0,2); // 去除品牌后面的英文名
      this.os = data.os;
      this.network = data.network;
      this.memory = data.memory.split("|");
      this.screen = data.screen.split("|");
      this.camera = data.camera.split("|");
      this.img = data.img.split("|");
      this.store_img = data.store_img;
    })
    this.axios.get('/v1/products/get_relevant').then(res=>{
      this.relevant = res.data[0].r_name.split('|');
      this.other_brand = res.data[1].r_name.split('|');
    })
  }
}
</script>