<template>
  <div class="bottom">
    <div class="head clearfix">
      <a href="javascrpt:;" class="fl" :class="{ active:bottom_chose == 0 }" @mouseenter="bottom_change(0)">为您推荐</a>
      <a href="javascrpt:;" class="fl" :class="{ active:bottom_chose == 1 }" @mouseenter="bottom_change(1)">最近浏览</a>
    </div>
    <div class="content">
      <div class="recommend" v-show="bottom_chose == 0">
        <ul class="clearfix">
          <li v-for="(p,i) of recommend" :key="i" class="fl">
            <router-link to="" :title="p.sale_name">
              <img :src="`img/${p.sale_img}`">
              <p class="name c333">{{p.sale_name}}</p>
              <p class="price">&yen;{{p.sale_price.toFixed(2)}}</p>
            </router-link>
          </li>
        </ul>
      </div>
      <div class="recent" v-show="bottom_chose == 1">
        <ul class="clearfix">
          <li v-for="(p,i) of shoppingCartList" :key="i" class="fl">
            <router-link to="" :title="p.us_name">
              <img :src="`img/${p.us_img}`">
              <p class="name c333">{{p.us_name}}</p>
              <p class="price">&yen;{{Number(p.us_price).toFixed(2)}}</p>
            </router-link>
          </li>
          <p class="go-shopping" v-show="shoppingCartList.length == 0">快去浏览一些商品吧！</p>
        </ul>
      </div>
    </div>
    
  </div>
</template>

<style>
  .bottom{
    margin-top: 20px;
    width: 990px;
    margin: 20px auto 0;
  }
  .bottom .head a{
    color: #333;
    height: 30px;
    line-height: 30px;
    padding: 0 33px;
    border: 1px solid #fff;
    border-bottom-color: #e6e6e6;
    position: relative;
    bottom: -1px;
    z-index: 1;
  }
  .bottom .head .active{
    color: #e3101e;
    border-color: #e6e6e6;
    border-bottom-color: #fff;
    font-weight: 700;
  }
  .bottom .content{
    border: 1px solid #e6e6e6;
    padding: 20px;
    text-align: center;
  }
  .bottom .content > div{
    height: 171px;
    overflow: hidden;
  }
  .bottom .content li{
    width: 169px;
    margin: 0 10px;
  }
  .bottom .content a{
    display: block;
  }
  .bottom .content a:hover .name{
    color: #d70010;
  }
  .bottom .content img{
    width: 100px; height: 100px;
    vertical-align: middle;
    image-rendering: -webkit-optimize-contrast;
  }
  .bottom .content .name{
    height: 38px;
    margin-top: 15px;
    overflow: hidden;
  }
  .bottom .content .price{
    color: #d70010;
    font-weight: 700;
    height: 18px;
    line-height: 18px;
  }
  .bottom .content .go-shopping{
    line-height: 171px;
  }
</style>

<script>
import { mapState } from 'vuex';
export default {
  data(){
    return {
      recommend:[],   // 热销推荐
      bottom_chose:0
    }
  },
  methods:{
    bottom_change(n){
      this.bottom_chose = n;
    }
  },
  computed:{
    // 最近浏览直接遍历购物车
    ...mapState(["shoppingCartList"])
  },
  mounted(){
    this.axios.get('/v1/products/hot').then(res=>{
      this.recommend = res.data;
    })
  }
}
</script>