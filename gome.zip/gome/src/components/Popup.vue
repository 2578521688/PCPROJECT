<template>
  <div class="popup-mask" v-show="popup_show == 1">
    <div class="popup">
      <a href="javascript:;" @click="popup_close"></a>
      <div class="popup-body">
        <p class="login">请先登录</p>
        <img src="img/static/item2.png">
        <p class="saoyisao">扫一扫，开启美好之旅</p>
      </div>
    </div>
  </div>
</template>

<style>
  .popup-mask{
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, .5);
    z-index: 9998;
  }
  .popup-mask .popup{
    /* 儿子永远压着爹，不写z-index也可以 */
    width: 363px; height: 433px;
    position: fixed;
    top: 50%; left: 50%;
    margin-top: -216px;
    margin-left: -181px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2852px;
  }
  .popup-mask .popup .popup-body{
    padding: 110px 53px 86px 59px;
    text-align: center;
  }
  .popup-mask .popup a{
    position: absolute;
    width: 14px; height: 14px;
    top: 78px; right: 63px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -3305px;
  }
  .popup-mask .popup .login{
    font-size: 24px;
    color: #000;
  }
  .popup-mask .popup img{
    vertical-align: middle;
    margin: 8px 0 5px;
  }
  .popup-mask .popup .saoyisao{
    font-size: 16px;
    height: 36px;
    line-height: 36px;
    color: #555;
  }
</style>

<script>
import { mapState } from 'vuex';
export default {
  data(){
    return {
      popup_show:0
    }
  },
  methods:{
    // 判断
    judge(){
      if(this.loginState != 1){
        this.popup_show = 1;
      }else{
        this.$router.push('/shoppingcart');
      }
    },
    popup_close(){
      // 关闭弹窗
      this.popup_show = 0;
      // 并且跳到登录界面
      this.$router.push('/login');
    }
  },
  computed:{
    ...mapState(["loginState"])
  }
}
</script>