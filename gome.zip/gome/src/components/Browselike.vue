<template>
  <div class="browselike fl">
    <div class="carrier">
      <div class="head">
        <p class="fl c5e5e5e">根据浏览猜你喜欢</p>
        <p class="fr c5e5e5e he3101e" @click="browse_change">换一组<i></i></p>
      </div>
      <ul v-for="(p,i) of browselike" :key="i" class="clearfix" :class="{opacity1: browse_chose == i}">
        <li class="fl" v-for="(bp,bi) of browselike[i]" :key="bi">
          <router-link to="" :title="bp.browse_name">
            <img :src="`img/browselike/${bp.browse_img}`">
            <p class="name">{{bp.browse_name}}</p>
            <p class="price ce3101e">&yen;{{bp.browse_price.toFixed(2)}}</p>
          </router-link>
        </li>
      </ul>
    </div>
  </div>
</template>

<style>
  .browselike{
    width: 1200px;
    margin: 40px auto 10px;
  }
  .browselike .carrier{
    height: 277px;
    border: 1px solid #e0e0e0;
    position: relative;
  }
  .browselike .carrier .c5e5e5e{
    color: #5e5e5e;
  }
  .browselike .carrier .he3101e:hover,
  .browselike .carrier .ce3101e{
    color: #e3101e;
  }
  .browselike .carrier .head{
    padding: 0 10px;
    height: 30px;
    line-height: 30px;
  }
  .browselike .carrier .head > p:first-child{
    font-size: 15px;
  }
  .browselike .carrier .head > p:last-child{
    cursor: pointer;
  }
  .browselike .carrier .head > p:last-child > i{
    display: inline-block;
    width: 16px; height: 16px;
    margin: -2px 0 0 5px;
    background: url('../../public/img/static/searchui.png') no-repeat -35px -15px;
    vertical-align: middle;
  }
  .browselike .carrier ul{
    height: 227px;
    position: absolute;
    top: 0; left: 0;
    opacity: 0;
    transition: .7s;
    margin: 30px 29px 20px;
  }
  .browselike .carrier .opacity1{
    opacity: 1;
    z-index: 10;
  }
  .browselike .carrier ul li{
    width: 160px;
    margin: 0 15px;
  }
  .browselike .carrier ul li img{
    display: block;
    margin: 0 auto;
  }
  .browselike .carrier ul li .name{
    margin: 10px 0 0;
    height: 36px;
    line-height: 18px;
    overflow: hidden;
  }
  .browselike .carrier ul li .price{
    font-size: 14px;
  }
</style>

<script>
export default {
  data(){
    return {
      browselike:[],    // 将两组数据放在一起，方便遍历
      browselike_1:[],  // 第一组数据
      browselike_2:[],  // 第二组数据
      browse_chose:0    // 当前显示哪组数据
    }
  },
  methods:{
    browse_change(){
      this.browse_chose = !this.browse_chose;
    }
  },
  mounted(){
    this.axios.get('/v1/products/browse_like').then(res=>{
      for(let obj of res.data){
        if(this.browselike_1.length != 6){
          this.browselike_1.push(obj);
        }else{
          this.browselike_2.push(obj);
        }
      }
      this.browselike = [this.browselike_1,this.browselike_2];
    })
  }
}
</script>