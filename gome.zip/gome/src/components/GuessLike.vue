<template>
  <div class="guesslike">
    <div class="title">
      <h2>猜你喜欢</h2>
      <span>YOU MAY LIKE</span>
      <div class="btn">
        <a class="prev" href="javascript:;" @click="pageDown"></a>
        <a class="next" href="javascript:;" @click="pageDown"></a>
      </div>
    </div>
    <div class="content">
      <ul v-for="(gp,gi) of guesslike" :key="gi" :class="{ opacity1: guesslike_chose == gi }">
        <li v-for="p of gp" :key="p.guesslike_id">
          <router-link to="" :title="p.guesslike_name">
            <img :src="`img/guesslike/${p.guesslike_img}`">
            <p class="name">{{p.guesslike_name}}</p>
            <p class="price">&yen;{{p.guesslike_price.toFixed(2)}}</p>
          </router-link>
        </li> 
      </ul>
    </div>
  </div>
</template>

<style>
  .guesslike{
    width: 1200px;
    margin: 0 auto;
  }
  .guesslike .title{
    height: 60px;
  }
  .guesslike .title h2{
    font-size: 18px;
    color: #333;
    margin-top: 28px;
    font-weight: 400;
    float: left;
  }
  .guesslike .title span{
    display: block;
    float: left;
    font-size: 20px;
    color: #ccc;
    padding: 27px 0 0 9px;
  }
  .guesslike .title .btn{
    float: right;
    width: 54px; height: 60px;
  }
  .guesslike .title .btn a{
    display: block;
    width: 23px; height: 23px;
    margin-top: 30px;
    float: left;
    margin-left: 3px;
    background-image: url('../../public/img/static/ui2.png');
    background-repeat: no-repeat;
  }
  .guesslike .title .btn .prev{
    background-position: -126px -104px;
  }
  .guesslike .title .btn .prev:hover{
    background-position: -126px -78px;
  }
  .guesslike .title .btn .next{ 
    background-position: -126px -182px;
  }
  .guesslike .title .btn .next:hover{
    background-position: -126px -156px;
  }
  .guesslike .content{
    /* 1200 减去 2px边框 */
    width: 1198px; height: 264px;
    border: 1px solid #eee;
    position: relative;
    overflow: hidden;
  }
  .guesslike .content ul{
    width: 1200px; height: 264px;
    position: absolute;
    top: 0; left: 0;
    opacity: 0;
    transition: .7s;
  }
  .guesslike .content .opacity1{
    opacity: 1;
    z-index: 10;
  }
  .guesslike .content ul>li{
    width: 200px; height: 224px;
    margin-top: 20px;
    float: left;
  }
  .guesslike .content ul>li a{
    display: block;
    width: 199px; height: 210px;
    border-right: 1px dashed #eee;
    /* 想移动内容区域，又不想让边框跟着移动，就用padding。边框可以包裹padding */
    padding-top: 15px;
  }
  .guesslike .content ul>li img{
    /* 清除幽灵间隙 */
    display: block;
    width: 120px; height: 120px;
    margin-left: 40px;
  }
  .guesslike .content ul>li .name{
    width: 167px; height: 36px;
    line-height: 18px;
    margin: 32px 0 0 20px;
    color: #5e5e5e;
    overflow: hidden;
  }
  .guesslike .content ul>li:hover .name{
    color: #b20fd3;
  }
  .guesslike .content ul>li .price{
    color: #ff0027;
    height: 16px;
    line-height: 16px;
    font-size: 16px;
    margin: 8px 0 0 20px;
  }
</style>

<script>
export default {
  data(){
    return {
      guesslike_1:[],
      guesslike_2:[],
      guesslike:[],
      guesslike_chose:0
    }
  },
  methods:{
    pageDown(){
      this.guesslike_chose = this.guesslike_chose==0? 1 : 0;
    }
  },
  mounted(){
    this.axios.get('/v1/products/guesslike').then(res=>{
      for(var obj of res.data){
        // 前6个给guesslike_1，后6个给guesslike_2
        if(this.guesslike_1.length!=6){
          this.guesslike_1.push(obj);
        }else{
          this.guesslike_2.push(obj);
        }
      }
      // 这样做是为了创建多个ul
      this.guesslike.push(this.guesslike_1);
      this.guesslike.push(this.guesslike_2);
    })
  }
}
</script>