<template>
  <div class="similar">
    <p>其他类似商品</p>
    <div class="other_goods">
      <div class="goods">
        <ul class="clearfix" :style="{ left }" :class="{ transition }" @transitionend="isTran && back()">
          <li class="fl" v-for="(p,i) of similar_data" :key="i">
            <router-link to="" :title="p.product_name">
              <img :src="`img/${p.product_img}`">
              <p class="name same-p">{{p.product_name}}</p>
              <p class="price same-p">&yen;{{p.product_price.toFixed(2)}}</p>
            </router-link>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="left" @click="prev()"></a>
      <a href="javascript:;" class="right" @click="next()"></a>
    </div>
  </div>
</template>

<style>
  .similar{
    width: 1200px; height: 258px;
    margin: 25px auto 0;
    border: 1px solid #eee;
  }
  .similar > p{
    height: 36px;
    line-height: 36px;
    padding-left: 10px;
    color: #666;
    background: #f6f6f6;
    font-weight: 600;
  }
  .similar .other_goods{
    position: relative;
  }
  .similar .other_goods .goods{
    width: 1110px; height: 210px;
    margin: 0 45px;
    padding: 10px 0;
    overflow: hidden;
  }
  .similar .other_goods .goods > ul{
    width: 7770px;
    position: relative;
  }
  .similar .other_goods .goods .transition{
    transition: .5s ease-out;
  }
  .similar .other_goods .goods > ul > li{
    width: 185px;
  }
  .similar .other_goods .goods > ul > li > a{
    display: block;
  }
  .similar .other_goods .goods > ul > li > a > img{
    display: block; /* 去除幽灵间隙 vertical-align: middle 也行 */
    margin: 0 auto;
  }
  .similar .other_goods .goods .same-p{
    width: 155px; 
    margin: 0 auto;
  }
  .similar .other_goods .goods .name{
    height: 36px;
    margin: 5px auto;
    color: #666;
    overflow: hidden;
  }
  .similar .other_goods .goods .name:hover{
    text-decoration: underline;
    color: #e3101e;
  }
  .similar .other_goods .goods .price{
    font-size: 18px;
    color: #e3101e;
  }
  .similar .other_goods > a{
    position: absolute;
    width: 13px; height: 18px;
    background: url('../../public/img/static/bg-sprite.png') no-repeat 0 -2059px;
    top: 50%;
    margin-top: -9px;
  }
  .similar .other_goods > .left{
    left: 20px;
  }
  .similar .other_goods > .left:hover{
    background-position: 0 -2115px;
  }
  .similar .other_goods > .right{
    right: 20px;
    background-position: 0 -2087px;
  }
  .similar .other_goods > .right:hover{
    background-position: 0 -2143px;
  }
</style>

<script>
// 过渡弊病：点太快时过渡还未结束，就会超出ul尺寸，出现空白
/* 思路： 1 2 3 1 2 3 1  一共7组，每组6条数据
        0 -1110 -2220 -3330 -4440 -5550 -6660
  中间的1 是默认显示列表 无论是向前移动还是向后移动 只要触碰到开头的1或者结尾的1，就瞬间取消过渡，跳到中间的1即可。
*/ 
export default {
  props:["kw"],
  data(){
    return {
      similar_data:[],
      left:'-3330px',
      transition:true,
      isTran:false   // 是否添加过渡结束事件
    }
  },
  methods:{
    prev(){
      let left = '';
      if(this.left == `-3330px`){
        // 恢复原位时，添加过渡【不写在watch，是因为watch比过渡快，过渡结束事件刚刚去除过渡，watch反手就把过渡给加上了，所以写在函数内】
        this.transition = true;
      }
      // 去除开头-号和结尾px
      if(this.left == '0px'){
        // -0 + 'px' = '0px' 这时就不能用slice(1,-2)了
        left = this.left.slice(0,-2);
      }else{
        left = this.left.slice(1,-2)
      }
      this.left = -(Number(left)-1110)+'px';
    },
    next(){
      if(this.left == `-3330px`){
        // 恢复原位时，添加过渡
        this.transition = true;
      }
      // 去除开头-号和结尾px
      let left = this.left.slice(1,-2);
      this.left = -(Number(left)+1110)+'px';
    },
    back(){
      this.isTran = false;       // 去除过渡结束事件
      this.transition = false;   // 去除过渡
      this.left = `-3330px`;     // 立刻返回中间的1
    }
  },
  watch:{
    left(newValue){
      if(newValue == `-6660px` || newValue == '0px'){
        // 添加过渡结束事件
        this.isTran = true;
      }
    }
  },
  mounted(){
    this.axios.get('/v1/products/get_similar',{
      params:{
        kw:this.kw
      }
    }).then(res=>{
      let arr1 = res.data; // 1 2 3
      let arr2 = res.data; // 1 2 3
      let arr3 = [];       // 1
      for(let obj of res.data){
        if(arr3.length != 6){
          arr3.push(obj);
        }
      }
      this.similar_data = [...arr1,...arr2,...arr3]; // 1 2 3 1 2 3 1
    })
  }
}
</script>