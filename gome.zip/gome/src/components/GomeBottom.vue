<template>
  <div class="gome-bottom">
    <div class="help">
      <ul class="clearfix">
        <li>
          <router-link to="">
            <i></i>
            品质
            <em></em>
            <span>正品行货 购物无忧</span>
          </router-link>
        </li>
        <li>
          <router-link to="">
            <i></i>
            低价
            <em></em>
            <span>普惠实价 帮你省钱</span>
          </router-link>
        </li>
        <li>
          <router-link to="">
            <i></i>
            速达
            <em></em>
            <span>专业配送 按时按需</span>
          </router-link>
        </li>
      </ul>
      <div class="help-box">
        <dl v-for="(hp,hi) of help_title" :key="hi">
          <dt>{{hp}}</dt>
          <dd v-for="(p,i) of help_content[hi]" :key="i">
            <router-link to="">{{p}}</router-link>
          </dd>
        </dl>
      </div>
    </div>
    <div class="foot">
      <div class="foot-box">
        <div class="clearfix">
          <div class="service">
            <i></i>
            <p>
              <span>门店服务</span>
              <router-link to="">国美门店全国共计2000余家</router-link>
            </p>
          </div>
          <div class="service different">
            <i></i>
            <p>
              <span>用户体验</span>
              <router-link to="">参与用户体验改进计划</router-link>
              <router-link to="">用户反馈</router-link>
            </p>
          </div>
          <div class="mobile">
            <div class="wx sm" @mouseenter="wx_change" @mouseleave="wx_change">
              <i></i>
              <p>公众号</p>
              <div class="scan-code" v-show="wx_chose">
                <img src="img/static/QRCode1.jpg">
                <i></i>
              </div>
            </div>
            <div class="site sm" @mouseenter="site_change" @mouseleave="site_change">
              <i></i>
              <p>手机站点</p>
              <div class="scan-code" v-show="site_chose">
                <img src="img/static/QRCode2.jpg">
                <i></i>
              </div>
            </div>
            <div class="app">
              <img src="img/static/QRCode3.jpg">
              <p>扫描下载客户端</p>
            </div>
          </div>
          <ul>
            <li v-for="(p,i) of footer_content_1" :key="i">
              <router-link to="">{{p}}</router-link>
            </li>
          </ul>
          <span>|</span>
          <ul>
            <li v-for="(p,i) of footer_content_2" :key="i">
              <router-link to="">{{p}}</router-link>
            </li>
          </ul>
          <span>|</span>
          <ul>
            <li v-for="(p,i) of footer_content_3" :key="i">
              <router-link to="">{{p}}</router-link>
            </li>
          </ul>
        </div>
        <p>
          本公司游戏产品适合18岁以上成年人使用  违法和不良信息举报电话：021-39900132
          <router-link to="">互联网药品信息服务资格证编号（沪）-经营性-2019-0006</router-link>
        </p>
        <p>
          网络食品销售第三方平台提供者备案：沪网食备A0015号
          <router-link to="">网络文化经营许可证沪网文[2021] 0385-031 号</router-link>
          <router-link to="">增值电信业务经营许可证</router-link>
        </p>
        <p>
          客服电话:4008113333
          <router-link to="">沪ICP备11009419号/京ICP备 19011786号</router-link>
          <router-link to="">京B2-20191290</router-link>
          <router-link to="">经营执照</router-link>
          <router-link to="">营业执照</router-link>
          <router-link to="">出版物经营许可证</router-link>
        </p>
        <p>
          ©2000-2021 国美在线电子商务有限公司版权所有
          <router-link to="">
            <i class="police-badge"></i>
            京公网安备 11010502038379号
          </router-link>
        </p>
        <div class="foot-credit clearfix">
          <router-link to="" class="baxx">
            <i></i>
            <b>经营性网站备案信息</b>
          </router-link>
          <router-link to="" class="xypj">
            <i></i>
            <b>可信网站信用评价</b>
          </router-link>
          <router-link to="" class="cxwz">
            <i></i>
            <b>诚信网站</b>
          </router-link>
          <router-link to="" class="cyjc">
            <i></i>
            <b>朝阳网络警察</b>
          </router-link>
          <router-link to="" class="wgdj">
            <i></i>
            <b>网购大家评</b>
          </router-link>
          <router-link to="" class="report">
            <i></i>
            <b>上海市互联网违法和不良信息举报中心</b>
          </router-link>
          <router-link to="" class="harmful">
            <i></i>
            <b>网上有害信息举报专区</b>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
  
  .gome-bottom a:hover,
  .gome-bottom a:hover span{
    color: #b20fd3 !important;
  }
  .gome-bottom .help{
    width: 1200px;
    margin: 30px auto 0;
  }
  .gome-bottom .help ul{
    background: #f5f5f5;
    padding: 15px 0;
  }
  .gome-bottom .help ul>li{
    float: left;
    width: 400px; height: 42px;
    line-height: 42px;
  }
  .gome-bottom .help ul>li a{
    display: block;
    width: 300px; height: 42px;
    margin: 0 auto;
    font-size: 18px;
    font-weight: bold;
    color: #404040;
    text-align: center;
  }
  .gome-bottom .help ul>li i{
    display: inline-block;
    width: 40px; height: 42px;
    background: url('../../public/img/static/ui.png') no-repeat 0 -1469px;
    margin-right: 10px;
    vertical-align: middle;
  }
  .gome-bottom .help ul>li em{
    display: inline-block;
    width: 3px; height: 3px;
    background: url('../../public/img/static/ui.png') no-repeat -120px -1489px;
    margin: 0 16px;
    vertical-align: middle;
  }
  .gome-bottom .help ul>li span{
    font-weight: 400;
    color: #404040;
  }
  .gome-bottom .help ul>li:nth-child(2) i{
    background-position: -40px -1469px;
  }
  .gome-bottom .help ul>li:nth-child(3) i{
    background-position: -80px -1469px;
  }
  .gome-bottom .help .help-box{
    display: flex;
    justify-content: space-around;
    margin-top: 15px;
  }
  .gome-bottom .help .help-box dt{
    font-size: 16px;
    color: #5e5e5e;
    line-height: 25px;
  }
  .gome-bottom .help .help-box dd{
    line-height: 22px;
  }
  .gome-bottom .help .help-box a{
    color: #a5a5a5;
  }
  .gome-bottom .foot{
    border-top: 1px solid #b20fd3;
    background: #f7f7f7;
    margin-top: 15px;
  }
  .gome-bottom .foot-box{
    width: 1200px;
    margin: 0 auto;
    padding-top: 20px;
  }
  .gome-bottom .foot-box .service{
    margin: 0 50px 40px 0;
    float: left;
  }
  .gome-bottom .foot-box .service i{
    float: left;
    width: 45px; height: 45px;
    background: url('../../public/img/static/ui.png') no-repeat 0 -135px;
  }
  .gome-bottom .foot-box .service p{
    float: left;
    width: 210px; height: 45px;
    color: #999;
    margin-left: 10px;
  }
  .gome-bottom .foot-box .service span{
    display: block;
    font-size: 16px;
    line-height: 25px;
    color: #333;
    margin-bottom: 3px;
  }
  .gome-bottom .foot-box .service a{
    color: #999;
  }
  .gome-bottom .foot-box .different i{
    background-position: -45px -135px;
  }
  .gome-bottom .foot-box .different a:last-child{
    margin-left: 5px;
  }
  .gome-bottom .foot-box .mobile{
    float: right;
  }
  .gome-bottom .foot-box .mobile>div{
    float: left;
  }
  .gome-bottom .foot-box .mobile .sm{
    width: 50px;
    margin: 0 10px;
    text-align: center;
    position: relative;
  }
  .gome-bottom .foot-box .mobile .sm p{
    color: #999;
    line-height: 22px;
  }
  .gome-bottom .foot-box .mobile .sm>i{
    display: inline-block;
    width: 40px; height: 25px;
    background: url('../../public/img/static/ui.png') no-repeat;
  }
  .gome-bottom .foot-box .mobile .wx>i{
    background-position: -105px -135px;
  }
  .gome-bottom .foot-box .mobile .site>i{
    background-position: -185px -135px;
  }
  .gome-bottom .sm .scan-code{
    position: absolute;
    left: -50px; bottom: 54px;
    z-index: 10;
    padding: 10px;
    border: 1px solid #eee;
    background: #fff;
  }
  .gome-bottom .sm .scan-code img{
    display: block;
    width: 171px;
  }
  .gome-bottom .sm .scan-code i{
    position: absolute;
    width: 13px; height: 8px;
    top: 100%; left: 68px;  
    background: url('../../public/img/static/ui.png') no-repeat -67px -127px;
  }
  .gome-bottom .mobile .app{
    width: 110px;
    text-align: center;
  }
  .gome-bottom .mobile .app img{
    display: block;
    margin: 0 auto;
    width: 90px; height: 90px;
  }
  .gome-bottom .mobile .app p{
    color: #999;
    line-height: 22px;
  }
  .gome-bottom .foot-box .clearfix>ul{
    float: left;
    height: 22px;
    line-height: 22px;
  }
  .gome-bottom .foot-box .clearfix>ul>li{
    float: left;
    height: 22px;
    margin-right: 13px;
  }
  .gome-bottom .foot-box .clearfix>ul>li a{
    color: #666;
  }
  .gome-bottom .foot-box .clearfix>span{
    float: left;
    height: 22px;
    line-height: 22px;
    margin-right: 13px;
    color: #ccc;
  }
  .gome-bottom .foot-box>p{
    color: #999;
    height: 22px;
    line-height: 22px;
  }
  .gome-bottom .foot-box>p>a{
    color: #999;
    margin-left: 5px;
  }
  .gome-bottom .foot-box>p .police-badge{
    display: inline-block;
    width: 18px; height: 20px;
    background: url('../../public/img/static/ui.png') no-repeat 0 -1712px;
    vertical-align: middle;
  }
  .gome-bottom .foot-credit{
    margin-top: 5px;
    border-top: 1px solid #e6e6e6;
    padding: 10px 0 25px;
  }
  .gome-bottom .foot-credit a{
    margin-right: 20px;
    float: left;
  }
  .gome-bottom .foot-credit i{
    float: left;
    width: 35px; height: 35px;
    background: url('../../public/img/static/ui.png') no-repeat;
  }
  .gome-bottom .foot-credit b{
    float: left;
    width: 50px;
    color: #999;
    margin-left: 5px;
    font-weight: normal;
  }
  .gome-bottom .foot-credit .baxx i{
    background-position: 0 -180px;
  }
  .gome-bottom .foot-credit .baxx b{
    width: 60px;
  }
  .gome-bottom .foot-credit .xypj i{
    background-position: -35px -180px;
  }
  .gome-bottom .foot-credit .cxwz i{
    background-position: -70px -180px;
  }
  .gome-bottom .foot-credit .cxwz b{
    height: 35px;
    line-height: 35px;
  }
  .gome-bottom .foot-credit .cyjc i{
    background-position: -105px -180px;
  }
  .gome-bottom .foot-credit .wgdj i{
    background-position: -140px -180px;
  }
  .gome-bottom .foot-credit .wgdj b{
    width: 60px; height: 35px;
    line-height: 35px;
  }
  .gome-bottom .foot-credit .report i{
    background-position: -175px -180px;
  }
  .gome-bottom .foot-credit .report b{
    width: 110px;
  }
  .gome-bottom .foot-credit .harmful i{
    background-position: -238px -180px;
  }
  .gome-bottom .foot-credit .harmful b{
    width: 80px;
  }
</style>

<script>
export default {
  data(){
    return {
      help_title:[],
      help_content:[],
      wx_chose:0,
      site_chose:0,
      footer_content_1:[],
      footer_content_2:[],
      footer_content_3:[],
    }
  },
  methods:{
    wx_change(){
      this.wx_chose = this.wx_chose==0? 1 : 0;
    },
    site_change(){
      this.site_chose = this.site_chose==0? 1 : 0;
    }
  },
  mounted(){
    this.axios.get('/v1/products/help').then(res=>{
      for(var obj of res.data){
        this.help_title.push(obj.help_title);
        var arr = obj.help_content.split('|');
        this.help_content.push(arr);
      }
    }),
    this.axios.get('/v1/products/footer').then(res=>{
      for(var obj of res.data){
        var arr = obj.footer_content.split('|');
        if(this.footer_content_1.length == 0){
          this.footer_content_1 = arr;
        }else if(this.footer_content_2.length == 0){
          this.footer_content_2 = arr;
        }else{
          this.footer_content_3 = arr;
        }
      }
    })
  }
}
</script>