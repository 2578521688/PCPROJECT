<template>
  <!-- 该定时器组件，仍有bug没有解决，已放弃。不过效果确实现了。时间：2021/5/27 -->
  <div class="CountTime">
    <!-- <span>{{dayString}}</span> -->
    <span>{{hourString}}</span><strong>:</strong>
    <span>{{minuteString}}</span><strong>:</strong>
    <span>{{secondString}}</span>
  </div>
</template>

<script>
export default {
  props:["list_switch"],
  data() {
    return {
      d: "",
      h: "",
      m: "",
      s: "",
      timer: "",
      endTime: "",
      today_list:[],
      tomorrow_list:[]
    }
  },
  methods: {
    setEndTime() {
      // 2、获取计算机当前系统时间 并设置结束时间
      this.endTime = new Date().getTime() + 15 * 1000;
      localStorage.setItem("endTime",this.endTime);
    },
    countTime() {
      // 4、是new Date()参与运算 自动调用getTime()函数	 
      // 这里使用Math.ceil的原因是 第一次second的计算结果不是整数 而是14.994 所以我们要向上取整 可以查看笔记js文件夹下的‘有关项目定时器的问题文件夹’
      var second = Math.ceil((this.endTime - new Date()) / 1000);
      if (second >= 0) {
        // var d = parseInt(second / 3600 / 24);
        var h = parseInt(second % (3600 * 24) / 3600);
        var m = parseInt((second % 3600) / 60);
        var s = parseInt(second % 60);
        // this.d = d;
        this.h = h;
        this.m = m;
        this.s = s;
      } else {
        // 清除上一个定时器，保证每次重新设置定时器时，程序中只存在一个
        clearInterval(this.timer);
        // 时间归零后 开始传递数据：
        this.transmitList();
        this.setEndTime();
        this.timer = setInterval(this.countTime(), 1000);
      }
      return this.countTime;
    },
    formatNum(num) {
      return num < 10 ? "0" + num : "" + num;
    },
    transmitList(){
      // 如果父组件传递过来的值是0，我们就请求今天的数据，否则请求明天的数据。
      if(this.list_switch == 0){
        // $emit子给父传参，通过父组件内子组件标签的get_list属性名，调用等号后面的方法。
        this.$emit('get_list',this.today_list);
      }else if(this.list_switch == 1){
        this.$emit('get_list',this.tomorrow_list);
      }
    }
  },
  computed: {
    // dayString() {
    //   return this.formatNum(this.d);
    // },
    hourString() {
      return this.formatNum(this.h);
    },
    minuteString() {
      return this.formatNum(this.m);
    },
    secondString() {
      return this.formatNum(this.s);
    }
  },
  //1、创建模型对象后，就给endTime赋值
  created() {
    if(localStorage.getItem("endTime")==null){
      this.setEndTime();
    }else{
      this.endTime = localStorage.getItem("endTime");
    }
  },
  //3、数据挂载后 执行定时器
  mounted() {
    // 函数加括号：第一次立即执行，并返回该函数，之后按毫秒数等待执行
    this.timer = setInterval(this.countTime(), 1000);
    // 请求今天的数据：
    let today = JSON.parse(localStorage.getItem("today_list"));
    if(today == null){
      this.axios.get('/v1/products/every_grab',{params:{list_switch:0}}).then(res=>{
        this.today_list = res.data;       // 本地存储只能存字符串，所以我们通过JSON来转换、解析字符串
        localStorage.setItem("today_list",JSON.stringify(res.data));
      })
    }else{
      this.today_list = today;
    }
    // 请求明天的数据：
    let tomorrow = JSON.parse(localStorage.getItem("tomorrow_list"));
    if(tomorrow == null){
      this.axios.get('/v1/products/every_grab',{params:{list_switch:1}}).then(res=>{
        this.tomorrow_list = res.data;       // 本地存储只能存字符串，所以我们通过JSON来转换、解析字符串
        localStorage.setItem("tomorrow_list",JSON.stringify(res.data));
      })
    }else{
      this.tomorrow_list = tomorrow;
    }
  },
  /* 
     路由跳转时，当前子组件销毁前，清除定时器，
     此时的定时器在新的页面不会继续运行（正常），
     但是在原页面仍会继续运行（不知原因，却能实现功能）。
  */
  beforeDestroy() {
    clearInterval(this.timer);
    // localStorage.removeItem("endTime");
  }
}
</script>

<style>
  .CountTime span {
    display: inline-block;
    width: 25px; height: 25px;
    line-height: 25px;
    border-radius: 5px;
    background-color: #B20FD3;
    color: #fff;
    text-align: center;
    font-size: 18px;
  }
  /* .CountTime span:first-child{
    margin-right: 12px;
  } */
  .CountTime strong{
    margin: 0 5px;
    font-size: 16px;
    color: #B20FD3;
  }
</style>