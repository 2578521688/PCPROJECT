<template>
  <div class="gome_top">
    <div class="carrier">
      <div class="nav clearfix">
        <ul class="nav_both nav_left">
          <li class="box" @mouseenter="dropdown_change(0)" @mouseleave="dropdown_change(0)">
            <div v-if="loginState != 1">
              <div class="trigger">
                <router-link to="">真快乐会员</router-link>
                <i></i>
              </div>
              <div v-show="chose_arr[0] == true" class="dropdown">
                <div class="login_dropdown">
                  <i></i>
                  <span>欢迎来到真快乐！<router-link to="/login" class="user_login">请登录！</router-link></span>
                </div>
              </div>
            </div>
            <div v-else>
              <div class="trigger level-g1">
                <router-link to="">Hi，{{username}}<em></em><i></i></router-link>
              </div>
              <div v-show="chose_arr[0] == true" class="dropdown">
                <router-link to="">
                  <div class="login_dropdown clearfix">
                    <i class="touxiang fl"></i>
                    <div class="user fl">
                      <div class="name">{{username}}<span class="g1">G1</span></div>
                      <div class="level clearfix">
                        <p class="fl left">100/100</p>
                        <p class="fl right">0/1</p>
                      </div>
                      <div class="disparity">升级到G2还需1个购物天数</div>
                    </div>
                  </div>
                </router-link>
              </div>
            </div>
          </li>
          <li>
            <router-link to="/login" v-if="loginState != 1">登录</router-link>
            <router-link to="" v-else @click.native="logout">注销</router-link>
          </li>
          <li>
            <router-link class="reg_hover" to="/register">注册有礼</router-link>
            <em class="reg_icon"></em>
          </li>
        </ul>
        <ul class="nav_both nav_right">
          <li>
            <router-link to="">我的订单</router-link>
          </li>
          <li class="box" @mouseenter="dropdown_change(1)" @mouseleave="dropdown_change(1)">
            <div class="trigger">
              <router-link to="">个人中心</router-link>
              <i></i>
            </div>
            <div v-show="chose_arr[1]" class="dropdown">
              <div class="center_dropdown">
                <div class="order">
                  <p v-if="loginState == 1" class="c069">{{username}}的真快乐</p>
                  <p v-else>个人中心，<router-link to="/login" class="user_login">请登录!</router-link></p>
                  <ul class="order_list clearfix">
                    <li><router-link to="" @click.native="into_shop">待处理订单<b v-show="loginState == 1" class="order_count">{{shoppingCartList.length}}</b></router-link></li>
                    <li><router-link to="">我的收藏</router-link></li>
                    <li><router-link to="">个人资料</router-link></li>
                  </ul>
                  <p><router-link to="">我的真快乐卷 - </router-link></p>
                </div>
                <div class="track">
                  <p>足迹</p>
                  <ul class="track_list">
                    <li v-for="i of 4" :key="i"></li>
                  </ul>
                </div>
              </div>
            </div>
          </li>
          <li class="box" @mouseenter="dropdown_change(2)" @mouseleave="dropdown_change(2)">
            <div class="trigger">
              <router-link to="">企业导购</router-link>
              <i></i>
            </div>
            <div v-show="chose_arr[2]" class="dropdown">
              <div class="company_dropdown clearfix">
                <ul class="company_list">
                  <li v-for="(p,i) of company" :key="i">
                    <router-link to="">{{p}}</router-link>
                  </li>
                </ul>
                <router-link to=""></router-link>
              </div>
            </div>
          </li>
          <li class="box" @mouseenter="dropdown_change(3)" @mouseleave="dropdown_change(3)">
            <div class="trigger">
              <em class="service_icon"></em>
              <router-link to="">服务中心</router-link>
              <i></i>
            </div>
            <div v-show="chose_arr[3]" class="dropdown">
              <div class="service_dropdown">
                <p>用户服务</p>
                <ul class="clearfix">
                  <li v-for="(p,i) of user_service" :key="i">
                    <router-link to="">{{p}}</router-link>
                  </li>
                </ul>
                <p>商家服务</p>
                <ul class="clearfix">
                  <li v-for="(p,i) of Business_service" :key="i">
                    <router-link to="">{{p}}</router-link>
                  </li>
                </ul>
                <router-link to="" class="service_a"><em class="online_icon"></em>在线客服</router-link>
              </div>
            </div>
          </li>
          <li class="box sitemap" @mouseenter="dropdown_change(4)" @mouseleave="dropdown_change(4)">
            <div class="trigger">
              <router-link to="">网站导航</router-link>
              <i></i>
            </div>
            <div v-show="chose_arr[4]" class="dropdown">
              <div class="website_dropdown">
                <dl>
                  <dt>主题促销</dt>
                  <dd>
                    <ul>
                      <li><router-link to="">抢购</router-link></li>
                    </ul>
                    <ul>
                      <li><router-link to="">服装城</router-link></li>
                      <li><router-link to="">超市</router-link></li>
                    </ul>
                    <ul>
                      <li><router-link to="">智能</router-link></li>
                      <li><router-link to="">家居安装</router-link></li>
                    </ul>
                  </dd>
                </dl>
                <dl>
                  <dt>特色分类</dt>
                  <dd>
                    <ul>
                      <li v-for="(p,i) of electric" :key="i">
                        <router-link to="">{{p}}</router-link>
                      </li>
                    </ul>
                    <ul>
                      <li v-for="(p,i) of digital" :key="i">
                        <router-link to="">{{p}}</router-link>
                      </li>
                    </ul>
                    <ul>
                      <li v-for="(p,i) of furniture" :key="i">
                        <router-link to="">{{p}}</router-link>
                      </li>
                    </ul>
                    <ul>
                      <li v-for="(p,i) of clothes" :key="i">
                        <router-link to="">{{p}}</router-link>
                      </li>
                    </ul>
                    <ul>
                      <li v-for="(p,i) of others" :key="i">
                        <router-link to="">{{p}}</router-link>
                      </li>
                    </ul>
                  </dd>
                </dl>
                <dl>
                  <dt>便捷服务</dt>
                  <dd>
                    <ul> 
                      <li><router-link to="">话费充值</router-link></li>
                    </ul>
                    <ul> 
                      <li><router-link to="">上门服务</router-link></li>
                    </ul>
                  </dd>
                </dl>
                <dl>
                  <dt>更多热点</dt>
                  <dd>
                    <ul>
                      <li><router-link to="">加盟国美</router-link></li>
                      <li><router-link to="">招商合作</router-link></li>
                      <li>
                        <router-link to="">企业采购</router-link>
                        <i class="hot"></i>
                      </li>
                    </ul>
                  </dd>
                </dl>
                <dl>
                  <dt>国美旗下</dt>
                  <dd>
                    <ul>
                      <li><router-link to="">国美管家</router-link></li>
                      <li><router-link to="">美锅优惠</router-link></li>
                    </ul>
                  </dd>
                </dl>
              </div>
            </div>
          </li>
          <li class="box app" @mouseenter="dropdown_change(5)" @mouseleave="dropdown_change(5)">
            <div class="trigger">
              <em class="phone_icon"></em>
              <router-link to="">真快乐APP</router-link>
              <i></i>
            </div>
            <div v-show="chose_arr[5]" class="dropdown">
              <div class="app_dropdown">
                <router-link to=""></router-link>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <!-- 搜索 -->
    <search></search>
    <!-- 遮罩层 -->
    <popup ref="popupMask"></popup>
  </div>
</template>

<style>
  .gome_top>.carrier{
    background-color: #f8f8f8;
    border-bottom: 1px solid #f3f3f3;
    height: 30px;
  }
  .gome_top .nav{
    width: 1200px;
    margin: 0 auto;
    /* 为网站导航做铺垫 */
    position: relative;
  }
  .gome_top .nav_both>li{
    /* 为下拉列表做绝对定位 
    relative和float不冲突 */
    position: relative;
    float: left;
    height: 30px;
    line-height: 30px;
    border: 1px solid #f8f8f8;
    border-bottom: 0;
  }
  .gome_top .nav_left>li{
    margin-right: 12px;
  }
  .gome_top li.box:hover{
    border-color: #e6e6e6;
  }
  .gome_top li.box .level-g1 em{
    display: inline-block;
    width: 14px; height: 14px;
    background: url('../../public/img/static/ui.png') no-repeat 0 -658px;
    vertical-align: middle;
    margin: -2px 0 0 3px;
  }
  .gome_top .trigger{
    /* 压住下面的下拉列表 */
    position: relative;
    z-index: 12;
    padding: 0 20px 0 10px;
  }
  .gome_top li.box:hover .trigger{
    background-color: #fff;
  }
  .gome_top li.box:hover .trigger a{
    color: #b20fb3;
  }
  .gome_top li.box .trigger i{
    width: 7px; height: 4px;
    /* 脱离文档流：变成块级元素 */
    position: absolute;
    top: 13px; right: 8px;
    background: url('../../public/img/static/ui.png') -62px -433px;
  }
  .gome_top li.box:hover .trigger i{
    background-position: -55px -433px;
  }
  .gome_top .nav_both a{
    color: #888;
  }
  .gome_top .nav_both a:hover{
    color: #b20fb3;
  }
  .gome_top .reg_icon{
    display: inline-block;
    width: 12px; height: 13px;
    background: url('../../public/img/static/ui.png') no-repeat -145px -1496px;
    margin-left: 3px;
    /* 把元素的顶端与父元素字体的顶端对齐 */
    vertical-align: text-top;
  }
  .gome_top .nav_left .reg_hover{
    color: #b20fb3
  }
  .gome_top .nav_right{
    float: right;
  }
  .gome_top .nav_right>li:first-child{
    margin-right: 12px;
  }
  .gome_top .service_icon{
    display: inline-block;
    width: 20px; height: 21px;
    background: url('../../public/img/static/service.png') no-repeat;
    vertical-align: middle;
  }
  .gome_top .phone_icon{
    display: inline-block;
    width: 20px; height: 21px;
    background: url('../../public/img/static/phone.png') no-repeat;
    vertical-align: middle;
  }
  .gome_top .dropdown{
    background: #fff;
    position: absolute;
    /* 父元素li 有一个1px的边框，所以left不是0而是-1
    li高30px，加上 上边框31px，定位从内容区域开始，30px刚好与被清除下边框的div重叠。
    所应该写29px 而不是30px*/
    left: -1px; top: 29px;
    border: 1px solid #e6e6e6; 
    z-index: 11;
  }
  .gome_top .dropdown > a{
    display: block;
  }
  .gome_top .login_dropdown{
    width: 290px;
    padding: 20px 15px;
  }
  .gome_top .login_dropdown i{
    background: url('../../public/img/static/ui.png') no-repeat 0 -337px;
    display: inline-block;
    width: 55px; height: 55px;
    border-radius: 50px;
    vertical-align: middle;
    margin-right: 20px;
  }
  .gome_top .login_dropdown .touxiang{
    display: block;
    background: url('../../public/img/static/touxiang.jpg');
    background-size: 100%;
    margin-right: 15px;
  }
  .gome_top .login_dropdown span{
    color: #888;
  }
  .gome_top .login_dropdown .user{
    width: 220px;
  }
  .gome_top .login_dropdown .name{
    height: 16px;
    line-height: 16px;
    font-size: 14px;
    font-weight: 700;
    color: #888;
  }
  .gome_top .login_dropdown .name .g1{
    display: inline-block;
    width: 27px; height: 15px;
    margin: -2px 0 0 5px;
    color: #b20fd3;
    background: url('../../public/img/static/ui.png') no-repeat 0 -672px;
    text-align: center;
    vertical-align: middle;
    font-size: 12px;
  }
  .gome_top .login_dropdown .level{
    height: 16px;
    line-height: 16px;
    margin: 5px 0;
    color: #fff;
  }
  .gome_top .login_dropdown .level .left{
    width: 80%; 
    background: #eb5509;
  }
  .gome_top .login_dropdown .level .right{
    width: 18%;
    background: #ffb799;
    margin-left: 2%;
  }
  .gome_top .login_dropdown .disparity{
    color: #888;
    height: 16px;
    line-height: 16px;
  }
  .gome_top .dropdown .user_login,
  .gome_top .dropdown .user_login:hover{
    font-weight: bolder;
    color: #069;
  }
  .gome_top .center_dropdown{
    width: 260px;
  }
  .gome_top .center_dropdown p{
    color: #888;
  }
  /* 这里不直接给center_dropdown设置padding：10px是因为
  .track的背景灰色是贴边的，单独给track设置内边距，既能保证，字不贴边
  又能让背景贴边（背景是可以平铺在内边距上的）。 */
  .gome_top .center_dropdown .order,
  .gome_top .center_dropdown .track{
    padding: 5px 10px;
  }
  .gome_top .center_dropdown .order .c069{
    color: #069;
  }
  .gome_top .center_dropdown .order_list{
    border-bottom: 1px solid #f3f3f3;
    padding-bottom: 9px;
  }
  .gome_top .center_dropdown .order_list>li{
    float: left;
    width: 50%;
    height: 25px;
    line-height: 25px;
  }
  .gome_top .center_dropdown .order_list .order_count{
    color: #b20fd3;
    margin-left: 4px;
  }
  .gome_top .center_dropdown .track{
    background: #f8f8f8;
  }
  .gome_top .center_dropdown .track_list{
    height: 50px;
    padding: 5px 0;
  }
  .gome_top .center_dropdown .track_list>li{
    float: left;
    width: 50px; height: 50px;
    margin: 0 5px;
    background: url('../../public/img/static/ui.png') -2px -397px;
  }
  .gome_top .company_dropdown{
    width: 295px;
    padding: 10px;
  }
  .gome_top .company_dropdown .company_list{
    width: 225px;
    float: left;
  }
  .gome_top .company_dropdown .company_list>li{
    width: 75px;
    float: left;
  }
  .gome_top .company_dropdown>a{
    float: left;
    width: 80px; height: 80px;
    background: url("../../public/img/static/enterprisescode.jpg");
    position: relative;
    /* 
      ul.width + a.width - a.margin-left = 295
      225 + 80 -10 = 295 
    */
    margin-left: -10px;
  }
  .gome_top .service_dropdown{
    width: 210px;
    padding: 10px;
  }
  .gome_top .service_dropdown p{
    font-weight: bolder;
    color: #898989;
  }
  .gome_top .service_dropdown ul{
    padding-bottom: 10px;
  }
  .gome_top .service_dropdown ul>li{
    float: left;
    width: 70px;
    line-height: 24px;
  }
  .gome_top .online_icon{
    display: inline-block;
    width: 18px; height: 20px;
    background: url('../../public/img/static/service_2.png') no-repeat;
    vertical-align: middle;
    margin-right: 5px;
  }
  .gome_top .service_dropdown .service_a{
    color: #fff;
    background: #b20fb3;
    text-align: center;
    display: block;
    height: 25px;
    line-height: 25px;
    cursor: pointer;
  }
  .gome_top .service_dropdown .service_a:hover{
    color: #fff;
  }
  .gome_top li.sitemap{
    position: static;
  }
  .gome_top li.sitemap .dropdown{
    /* 相对.nav做定位。.nav没有边框。所以覆盖left:-1px */
    left: 0;
  }
  .gome_top .website_dropdown{
    /* .nav没有边框，宽度1200px。
    所以 .website_dropdown 的自身宽度 也要减去左右边框2px
    这样才能对齐 */
    width: 1198px;
  }
  .gome_top .website_dropdown dl{
    float: left;
    border-left: 1px solid #f3f3f3;
    padding: 0 15px 0 40px;
    margin: 15px 0;
  }
  .gome_top .website_dropdown dl:first-child{
    border: 0;
  }
  .gome_top .website_dropdown dt{
    color: #5e5e5e;
    font-weight: bolder;
    font-size: 14px;
    line-height: 14px;
    margin-bottom: 14px;
  }
  .gome_top .website_dropdown dd{
    height: 120px;
  }
  .gome_top .website_dropdown ul{
    float: left;
    width: 75px;
  }
  .gome_top .website_dropdown ul>li{
    width: 100%;
    line-height: 24px;
  }
  .gome_top .website_dropdown .hot{
    display: inline-block;
    width: 11px; height: 14px;
    margin: 0 0 9px 2px;
    background: url("../../public/img/static/ui.png") no-repeat 0 -452px;
    vertical-align: middle;
  }
  .gome_top .app .dropdown{
    /* 从根据父元素左上角做偏移，改成右上角 保证二维码不出.nav范围 */
    left: auto; right: -1px;
  }
  .gome_top .app_dropdown{
    padding: 15px;
  }
  .gome_top .app_dropdown a{
    display: inline-block;
    width: 130px; height: 170px;
    background: url("../../public/img/static/ui.png") no-repeat 0 -799px;
  }
</style>

<script>
import search from './Search.vue';
import popup from '../components/Popup.vue';
import { mapState,mapMutations } from 'vuex';
export default {
  components:{ search,popup },
  data(){
    return {
      // 个人中心 足迹
      i:1,
      // 企业采购
      company:["企业购首页","企业场景购","政府采购","解决方案","发布采购单","美通卡","联系我们"],
      // 服务中心
      user_service:["售后服务","帮助服务","新手指南","客户服务","用户注销"],
      Business_service:["招商合作","商家登录","广告平台","平台规则","商家培训"],
      // 网站导航 特色分类
      electric:["电视影音","冰洗","洗衣机","空调","厨卫生活"],
      digital:["手机","数码","电脑办公","精品配件","汽车"],
      furniture:["住宅家居","家装建材","家居日用","床品家纺"],
      clothes:["服饰鞋帽","运动户外","箱包奢品","钟表首饰"],
      others:["食品酒水","母婴玩具","美妆个护"],
      chose_arr:[0,0,0,0,0,0]
    }
  },
  methods:{
    ...mapMutations(["clearUserName","clearShoppingCartList"]),

    dropdown_change(index){
      // 0 和 1 之间无限替换
      this.$set(this.chose_arr,index,!this.chose_arr[index]);
    },
    logout(){
      this.clearUserName();
      // 注销后跳到登录界面
      this.$router.push('/login');
      // 并清空购物车
      this.clearShoppingCartList();
    },
    into_shop(){
      // 调用子组件下的方法
      this.$refs.popupMask.judge();
    }
  },
  computed:{
    ...mapState(["username","loginState","shoppingCartList"])
  }
}
</script>