<template>
  <div class="coupons">
    <ul class="clearfix">
      <li v-for="p of coupons" :key="p.coupons_id">
        <router-link to="">
          <img :src="`img/coupons/${p.coupons_img}`">
        </router-link>
      </li>
    </ul>
  </div>
</template>

<style>
  .coupons{
    width: 1200px;
    margin: 20px auto 0;
  }
  .coupons>ul>li{
    float: left;
    overflow: hidden;
  }
  /* 121+208*5+39 = 1200 */
  /* 把第一个li的宽度-1 */
  .coupons>ul>li:first-child{
    width: 121px; height: 110px;
  }
  /* 除了第一个li 和 最后一个li 的 其他li宽度-1 */
  .coupons>ul>li:not(:first-child):not(:last-child){
    width: 208px; height: 110px;
  }
  .coupons img{
    /* 去除幽灵间隙 */
    display: block;
  }
  .coupons img:hover{
    opacity: 0.8;
  }
</style>

<script>
export default {
  data(){
    return {
      coupons:[]
    }
  },
  mounted(){
    this.axios.get('/v1/products/coupons').then(res=>{
      this.coupons = res.data;
    })
  }
}
</script>