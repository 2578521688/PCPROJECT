<template>
  <div class="floor">
    <div v-for="(tp,ti) of floor_title" :key="tp.title_id" :id="`floor_${ti}`">
      <div class="top">
        <div class="top_left">
          <span>{{tp.title_floor}}</span>
          <h2>{{tp.title_name}}</h2>
        </div>
        <ul class="top_right">
          <li v-for="(sp,si) of floor_sort[ti]" :key="si" :class="{ active: sort_chose_arr[ti] == si }" @mouseenter="product_display(ti,si)">
            <router-link to="">{{sp}}</router-link>
          </li>
        </ul>
      </div>
      <div class="content">
        <div class="content_left">
          <router-link to="" v-for="(stp,sti) of floor_static[ti]" :key="sti">
            <img :src="`img/static/${stp}`" >
          </router-link>
          <ul class="channel">
            <li v-for="(cp,ci) of floor_channel[ti]" :key="ci">
              <router-link to="">{{cp}}</router-link>
            </li>
          </ul>
          <div class="keywords">
            <ul v-for="(kp,ki) of floor_keywords[ti]" :key="ki">
              <li v-for="(p,i) of kp" :key="i">
                <router-link to="">{{p}}</router-link>
              </li>
            </ul>
          </div>
        </div>
        <div class="content_right">
          <div class="main" v-show="sort_chose_arr[ti] == 0">
            <div class="main_left">
              <router-link to="" v-for="(bgp,bgi) of floor_bg[ti]" :key="bgi">
                <img :src="`img/static/${bgp}`">
              </router-link>
              <ul>
                <li v-for="(bp,bi) of floor_brand[ti]" :key="bi">
                <!-- 子元素img：block 和 父元素a：block 发生了上边距溢出，需要清除 -->
                  <router-link class="clear-margin-overflow" to="" :title="bp.brand_name">
                    <img :src="`img/${bp.brand_img}`">
                  </router-link>
                </li>
              </ul>
            </div>
            <div class="main_right">
              <ul>
                <li v-for="(mp,mi) of floor_model[ti]" :key="mi">
                  <router-link to="">
                    <img :src="`img/${mp}`">
                  </router-link>
                </li>
              </ul>
            </div>
          </div>
          <div class="main" v-for="(pap,pai) of floor_product_all[ti]" :key="pai" v-show="sort_chose_arr[ti] == pai+1">
            <ul class="main_inner clearfix">
              <li v-for="p of pap" :key="p.product_id">
                <!-- 子元素img：block 和 父元素a：block 发生了上边距溢出，需要清除 -->
                <router-link class="clear-margin-overflow" to="" :title="p.product_name">
                  <img :src="`img/${p.product_img}`">
                  <p class="name">{{p.product_name}}</p>
                  <p class="price">&yen;{{p.product_price.toFixed(2)}}</p>
                </router-link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 楼层快捷跳转 -->
    <div class="elevator" v-show="floor_show == 1">
      <div class="title same-div">楼层导航</div>
      <ul>
        <li v-for="(p,i) of floor_title" :key="i" :class="{active: floor_chose == i}">
          <a href="javascript:;" @click="floor_change(i)">
            <i v-show="floor_chose == i"></i>
            <p>{{p.title_floor}}</p>
            <p>{{p.title_name}}</p>
          </a>
        </li>
      </ul>
      <div class="back same-div">
        <a href="javascript:;" @click="back_to_top"><i></i></a>
      </div>
    </div>
  </div>
</template>

<style>
  /* img亮一下 */
  @keyframes brighten {
    from{opacity: .5;}
    to{opacity: 1;}
  }
  .floor{
    width: 1200px;
    margin: 0 auto;
  }
  .floor > div{
    margin-top: 32px;
  }
  .floor img:hover{
    animation: brighten 2s;
  }
  .floor .top{
    height: 38px;
    border-bottom: 1px solid #719ef7;
  }
  .floor .top .top_left{
    float: left;
    width: 210px; height: 38px;
    line-height: 38px;
    font-size: 20px;
  }
  .floor .top .top_left span{
    float: left;
    padding-right: 6px;
  }
  .floor .top .top_left h2{
    font-weight: 500;
    font-size: 20px;
  }
  .floor .top .top_right{
    float: right;
    margin-top: 8px;
    height: 30px;
  }
  .floor .top .top_right>li{
    float: left;
  }
  .floor .top .top_right>li>a{
    display: inline-block;
    height: 30px;
    line-height: 30px;
    color: #5e5e5e;
    font-size: 14px;
    padding: 0 15px;
  }
  .floor .top .top_right>.active{
    background: rgb(113, 158, 247);
  }
  .floor .top .top_right>.active>a{
    color: #fff;
  }
  .floor .content{
    height: 470px;
  }
  .floor .content .content_left{
    float: left;
    width: 210px; height: 470px;
    background: #719ef7;
    overflow: hidden;
  }
  .floor .content .content_left img{
    display: block;
    width: 220px; height: 278px;
    margin-left: -10px; 
  }
  .floor .content .content_left a{
    color: #f0f0f0;
  }
  .floor .content .content_left a:hover{
    text-decoration: underline;
  }
  .floor .content .content_left .channel{
    width: 210px; height: 32px;
    line-height: 32px;
    background: #6294f6;
  }
  .floor .content_left .channel>li{
    float: left;
    font-size: 14px;
  }
  .floor .content_left .channel>li:first-child{
    margin-left: 15px;
  }
  .floor .content_left .channel>li+li::before{
    content: '/';
    color: #f0f0f0;
    margin: 0 5px;
  }
  .floor .content_left .keywords{
    height: 160px;
    display: flex;
    justify-content: space-around;
  }
  .floor .content_left .keywords ul{
    height: 140px;
    margin-top: 10px;
  }
  .floor .content_left .keywords ul>li{
    height: 28px;
    line-height: 28px;
  }
  .floor .content .content_right{
    float: left;
    width: 990px; height: 470px;
    position: relative;
  }
  .floor .content .content_right .main{
    width: 990px; height: 470px;
  }
  .floor .main .main_left{
    float: left;
    width: 389px; height: 470px;
  }
  .floor .main .main_left ul{
    width: 372px; height: 102px;
    position: absolute;
    left: 10px; bottom: 10px;
  }
  .floor .main .main_left ul>li{
    float: left;
    width: 122px; height: 50px;
    margin: 0 0 1px 1px;
    opacity: .9;
    background: #fff;
  }
  .floor .main .main_left ul>li:hover{
    opacity: 1;
  }
  /* 
    如果img铺满整个div，那么不用设置a的尺寸，也可以将a覆盖整个img和div
    反之：如果img未铺满整个div，那么必须设置a的尺寸，跟div的尺寸一样，才能做到a覆盖整个img和div。
    给a设置尺寸时，如果img有上外边距，记得解决上外边距的溢出问题。
  */
  .floor .main .main_left ul>li a{
    display: block;
    height: 50px;
  }
  .floor .main .main_left ul>li img{
    display: block;
    width: 100px; height: 30px;
    margin: 10px 0 0 11px;
  }
  .floor .main .main_right{
    width: 601px; height: 470px;
    float: left;
  }
  .floor .main .main_right ul{
    width: 600px; height: 470px;
    border-left: 1px solid #eee;
  }
  .floor .main .main_right ul>li{
    float: left;
    width: 199px; height: 234px;
    border-right: 1px solid #eee;
    border-bottom: 1px solid #eee;
  }
  .floor .main .main_inner>li{
    float: left;
    width: 198px; height: 235px;
  }
  .floor .main .main_inner>li a{
    display: block;
    width: 197px; height: 234px;
    border-right: 1px solid #eee;
    border-bottom: 1px solid #eee;
  }
  .floor .main .main_inner>li a:hover .name{
    color: #b20fd3;
  }
  .floor .main .main_inner>li img{
    display: block;
    width: 130px; height: 130px;
    margin: 20px 0 15px 34px;
  }
  .floor .main .main_inner>li .name,
  .floor .main .main_inner>li .price{
    width: 157px; height: 36px;
    margin-left: 20px;
    color: #5e5e5e;
    overflow: hidden;
  }
  .floor .main .main_inner>li .price{
    height: 26px;
    line-height: 26px;
    color: #ff0027;
    font-size: 14px;
  }
  /* 各个楼层 不同的 颜色 */
  .floor>div:nth-child(2) .top{
    border-bottom-color: #50bfec;
  }
  .floor>div:nth-child(2) .top .active{
    background: rgb(80, 191, 236);
  }
  .floor>div:nth-child(2) .content_left{
    background: #50bfec;
  }
  .floor>div:nth-child(2) .content .channel{
    background: #3eb8e9;
  }
  .floor>div:nth-child(3) .top{
    border-bottom-color: #7f86ec;
  }
  .floor>div:nth-child(3) .top .active{
    background: rgb(127, 134, 236);
  }
  .floor>div:nth-child(3) .content_left{
    background: #7f86ec;
  }
  .floor>div:nth-child(3) .content .channel{
    background: #7179ea;
  }
  .floor>div:nth-child(4) .top{
    border-bottom-color: #e85cc5;
  }
  .floor>div:nth-child(4) .top .active{
    background: rgb(232, 92, 197);
  }
  .floor>div:nth-child(4) .content_left{
    background: #e85cc5;
  }
  .floor>div:nth-child(4) .content .channel{
    background: #e744c1;
  }
  .floor>div:nth-child(5) .top{
    border-bottom-color: #829daa;
  }
  .floor>div:nth-child(5) .top .active{
    background: rgb(130, 157, 170);
  }
  .floor>div:nth-child(5) .content_left{
    background: #829daa;
  }
  .floor>div:nth-child(5) .content .channel{
    background: #6a8ea0;
  }
  .floor .elevator{
    width: 66px;
    position: fixed;
    left: 70px; top: 268px;
    text-align: center;
    background: #fff;
    border: 1px solid #e6e6e6;
  }
  .floor .elevator i{
    background: url('../../public/img/static/ui2.png') no-repeat;
  }
  .floor .elevator .same-div{
    height: 30px;
    line-height: 30px;
  }
  .floor .elevator .title{
    background: #f6f6f6;
    color: #5e5e5e;
    font-size: 13px;
    font-weight: 700;
  }
  .floor .elevator .back{
    border-top: 1px solid #e6e6e6;
  }
  .floor .elevator .back a{
    display: block;
    height: 30px;
  }
  .floor .elevator .back a i{
    display: inline-block;
    width: 17px; height: 10px;
    background-position: -216px -52px;
    margin: 10px 0;
  }
  .floor .elevator .back a:hover i{
    background-position: -216px -78px;
  }
  .floor .elevator ul li{
    height: 44px;
    border-top: 1px solid #e6e6e6;
  }
  .floor .elevator ul li a{
    position: relative;
    display: block;
    height: 36px;
    color: #5e5e5e;
    padding: 4px 0;
  }
  .floor .elevator ul li i{
    position: absolute;
    width: 10px; height: 10px;
    top: 0; left: 0;
    background-position: -152px 0;
  }
  .floor .elevator ul .active a{
    color: #b20fd3;
  }
</style>

<script>
export default {
  data(){
    return {
      // 每个元素控制一个楼层的显示和隐藏
      sort_chose_arr:[0,0,0,0,0],
      floor_title:[],
      floor_sort:[],
      floor_static:[],
      floor_bg:[],
      floor_channel:[],
      floor_keywords:[],
      floor_brand:[],
      floor_model:[],
      floor_product_all:[],
      floor_product:[],
      floor_product_1:[],
      floor_product_2:[],
      floor_product_3:[],
      floor_chose:-1,
      floor_show:0,
      active:false
    }
  },
  methods:{
    product_display(index,si){
      // 使用数组[index]的方法修改数值，不会触发页面dom渲染，需要强制改值。
      // 把sort_chose_arr数组中下标为index的元素值修改为si。
      this.$set(this.sort_chose_arr,index,si);
    },
    get_floor_title(){
      this.axios.get('/v1/products/floor_title').then(res=>{
        this.floor_title = res.data;
      })
    },
    get_floor_sort(){
      this.axios.get('/v1/products/floor_sort').then(res=>{
        for(var obj of res.data){
          var arr = obj.sort_name.split('|');
          this.floor_sort.push(arr);
        }
      })
    },
    get_floor_img(){
      this.axios.get('/v1/products/floor_static').then(res=>{
        for(var obj of res.data){
          delete obj.static_id;
          this.floor_static.push(obj);
        }
      })
    },
    get_floor_bg(){
      this.axios.get('/v1/products/floor_bg').then(res=>{
        for(var obj of res.data){
          delete obj.bg_id;
          this.floor_bg.push(obj);
        }
      })
    },
    get_floor_channel(){
      this.axios.get('/v1/products/floor_channel').then(res=>{
        for(var obj of res.data){
          var arr = obj.channel_name.split('|');
          this.floor_channel.push(arr);
        }
      })
    },
    get_floor_keywords(){
      this.axios.get('/v1/products/floor_keywords').then(res=>{
        var arr2 = [];
        for(var obj of res.data){
          var arr = obj.keyword_name.split('|');
          arr2.push(arr);
          if(arr2.length==3){
            this.floor_keywords.push(arr2);
            arr2 = [];
          }
        }
      })
    },
    get_floor_brand(){
      this.axios.get('/v1/products/floor_brand').then(res=>{
        var arr = [];
        for(var obj of res.data){
          arr.push(obj);
          if(arr.length==6){
            this.floor_brand.push(arr);
            arr = [];
          }
        }
      })
    },
    get_floor_model(){
      this.axios.get('/v1/products/floor_model').then(res=>{
        var arr = [];
        for(var obj of res.data){
          arr.push(obj.model_img);
          if(arr.length==6){
            this.floor_model.push(arr);
            arr = [];
          }
        }
      })
    },
    get_floor_product(){
      this.axios.get('/v1/products/floor_product').then(res=>{
        var arr = [];
        for(var obj of res.data){
          arr.push(obj);
          if(arr.length==30){
            for(var obj of arr){
              // 分3个数组装后3个分类对应的数据
              if(this.floor_product_1.length != 10){
                this.floor_product_1.push(obj);
              }else if(this.floor_product_2.length != 10){
                this.floor_product_2.push(obj);
              }else if(this.floor_product_3.length != 10){
                this.floor_product_3.push(obj);
              }
            }
            // 加入到一个数组中，方便v-for创建元素
            this.floor_product.push(this.floor_product_1);
            this.floor_product.push(this.floor_product_2);
            this.floor_product.push(this.floor_product_3);
            // 每个楼层有对应的数据
            this.floor_product_all.push(this.floor_product);
            // 清空数组
            this.floor_product_1 = [];
            this.floor_product_2 = [];
            this.floor_product_3 = [];
            this.floor_product = [];
            arr = [];
          }
        }
      })
    },
    // 元素对象.scrollIntoView block：start 上边框与视窗顶部平齐。 behavior:'smooth' 同返回顶部的behavior都代表平滑过渡 详情查看mdn
    floor_change(i){
      let div = document.getElementById(`floor_${i}`);
      // 滚动元素的父容器，使被调用scrollIntoView()的元素对用户可见
      div.scrollIntoView({
        block:'start',      // 默认值
        behavior:'smooth'   // 平滑过渡
      })
    },
    back_to_top(){
      // 使界面滚动到指定坐标位置。详细查看mdn
      window.scrollTo({
        top: 0,             // 回到顶部
        behavior:'smooth'   // 平滑过渡
      });
    },
    page_scroll(){
      // 解决兼容性问题
      let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
      if(scrollTop >= 320){
        // 打开楼层导航（要一直显示，不能参与楼层判断）
        this.floor_show = 1;
      }
      if(scrollTop >= 1100 && scrollTop<1600){
        // 选中1楼
        this.floor_chose = 0;
      }else if(scrollTop >= 1600 && scrollTop < 2100){
        // 选中2楼
        this.floor_chose = 1;
      }else if(scrollTop >= 2100 && scrollTop < 2600){
        // 选中3楼
        this.floor_chose = 2;
      }else if(scrollTop >= 2600 && scrollTop < 3100){
        // 选中4楼
        this.floor_chose = 3;
      }else if(scrollTop >= 3100 && scrollTop < 3600){
        // 选中5楼
        this.floor_chose = 4;
      }else if(scrollTop >= 3600 || scrollTop < 320){
        // 关闭楼层导航
        this.floor_show = 0;
        this.floor_chose = -1;
      }else if(scrollTop < 1100){
        // 从下往上退回到1100以内，先清除楼层选中
        this.floor_chose = -1;
      }
    }
  },
  mounted(){
    // 获取标题
    this.get_floor_title();
    // 获取分类
    this.get_floor_sort();
    // 获取静态图片
    this.get_floor_img();
    // 获取背景图
    this.get_floor_bg();
    // 获取通道
    this.get_floor_channel();
    // 获取手机关键字
    this.get_floor_keywords();
    // 获取手机品牌
    this.get_floor_brand();
    // 获取手机型号
    this.get_floor_model();
    // 获取手机商品
    this.get_floor_product();
    // 添加页面滚动事件
    window.onscroll = this.page_scroll;
  }
}
</script>