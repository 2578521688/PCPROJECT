<template>
  <div class="roll">
    <ul>
      <li v-for="item of slideList" :key="item.roll_id" :class="n==0? 'li_cut_init' : 'li_cut'">
        <router-link to="">
          <img :src="`img/roll/${item.roll_img}`">
        </router-link> 
      </li>
    </ul>
  </div>
</template>

<style>
  .roll{
    float: right;
  }
  .roll ul{
    width: 170px; height: 40px;
    overflow: hidden;
  }
  .roll ul>li{
    height: 40px;
    transition: 2s;
    position: relative;
  }
  .roll img{
    /* 解决幽灵间隙 */
    display: block;
  }
  .roll .li_cut_init{
    top: 0;
  }
  .roll .li_cut{
    top: -40px;
  }
</style>

<script>
export default {
  data(){
    return {
      n:0,
      slideList:[],
      timer:''
    }
  },
  methods:{
    go(){
      this.timer = setInterval(()=>{
        this.n = this.n==0? 1 : 0;
      },4000)
    },
    // stop(){
    //   clearInterval(this.timer);
    // }
  },
  mounted(){
    this.go();
    this.axios.get('/v1/products/roll').then(res=>{
      this.slideList = res.data;
    })
  }
}
</script>