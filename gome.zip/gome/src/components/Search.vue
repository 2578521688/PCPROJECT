<template>
  <div class="search">
    <div class="logo">
      <router-link target="_self" to="/"></router-link>
    </div>
    <div class="top_search">
      <div class="search_box">
        <div class="search_type" @mouseenter="search_show" @mouseleave="search_hide">
          <div class="search_type_chose">
            <span>{{type_chose=='goods'? "商品":"店铺"}}</span>
            <i></i>
          </div>
          <div v-show="search_chose" class="search_type_dropdown">
            <span @click="change_type('goods')">商品</span>
            <span @click="change_type('shop')">店铺</span>
          </div>
        </div>                               <!-- .13事件修饰符 keyup键盘按键抬起事件 合起来就是抬起回车时触发搜索事件 -->
        <input v-model="keyword" v-focus type="text" placeholder="请输入关键词，比如手机、Apple、小米..." @keyup.13="search">
        <button @click="search">搜索</button>
        <!-- 小话筒 -->
        <div class="search_voice"></div>
      </div>
      <div class="search_keyword">
        <router-link to="" v-for="(p,i) of keywords" :key="i">{{p}}</router-link>
      </div>
    </div>
    <div class="shopping_cart">
      <div class="shopping_carrier">
        <router-link to="" @click.native="into_shop">
          <em class="cart_icon">
            <span class="shop_num" :class="{change: shoppingCartList.length!=0}">
              <span>{{shoppingCartList.length}}</span>
              <i :class="{change_i: shoppingCartList.length!=0}"></i>
            </span>
          </em>
          <span>我的购物车</span>
          <b></b>
        </router-link>
      </div>
    </div>
    <!-- 遮罩层 -->
    <popup ref="popupMask"></popup>
  </div>
</template>

<style>
  .search{
    position: relative;
    width: 1200px; height: 120px;
    margin: 0 auto;
  }
  .search a{
    color: #a5a5a5;
  }
  .search a:hover{
    color: #b20fb3;
  }
  .search > .logo{
    float: left;
    margin-top: 32px;
  }
  .search > .logo a{
    display: block;
    width: 125px; height: 56px;
    background: url("../../public/img/static/logo.png") no-repeat;
  }
  .search > .top_search{
    position: absolute;
    top: 32px; left: 385px;
    width: 500px;
  }
  .search .top_search .search_box{
    height: 30px;
    background: #fff;
    border: 1px solid #b20fd3;
    font-size: 14px;
    /* 用于定位小话筒 */
    position: relative;
  }
  .search .search_box .search_type{
    float: left;
    position: relative;
    font-size: 14px;
    color: #a5a5a5;
    width: 62px; height: 30px;
    line-height: 30px;
    border-right: 1px solid #b20fb3;
    cursor: pointer;
  }
  .search .search_type .search_type_chose{
    width: 42px;
    padding: 0 10px;
  }
  .search .search_type i{
    position: absolute;
    width: 11px; height: 7px;
    right: 9px; top: 11px;
    background: url("../../public/img/static/ui.png") -145px -1469px no-repeat;
  }
  .search .search_type .search_type_dropdown{
    position: absolute;
    top: 30px; left: -1px;
    border: 1px solid #b20fb3;
    background: #fff;
  }
  .search .search_type_dropdown span{
    display: block;
    width: 42px;
    padding: 0 10px;
    height: 25px;
    line-height: 25px;
  }
  .search .search_type_dropdown span:hover{
    cursor: pointer;
    background: #f3f3f3;
  }
  .search .search_box input{
    /* 行内块元素不会被浮动压在下面，所以不用写float */
    border: 0; outline: 0;
    width: 310px; height: 20px;
    padding: 5px 10px;
    font-size: 14px;
    color: #5e5e5e;
  }
  .search .search_box button{
    float: right;
    width: 90px; height: 30px;
    border: 0; outline: 0;
    cursor: pointer;
    background: #b20fb3;
    font-size: 16px;
    line-height: 30px;
    color: #fff;
    /* 设置字间距 */
    letter-spacing:2px;
  }
  .search .search_box .search_voice{
    width: 15px; height: 20px;
    position: absolute;
    top: 50%; right: 95px;
    margin-top: -10px;
    background: url('../../public/img/static/search.png') no-repeat center;
    cursor: pointer;
    background-size: 100% 100%;
  }
  .search .search_keyword{
    margin-top: 10px;
    height: 14px;
    line-height: 14px;
  }
  .search .search_keyword a{
    margin-right: 10px;
  }
  .search .search_keyword a:first-child,
  .search .search_keyword a:last-child{
    color: #b20fb3;
  }
  .search .shopping_cart{
    position: absolute;
    top: 32px; right: 0;
    width: 142px;
  }
  .search .shopping_cart .shopping_carrier{
    position: relative;
  }
  .search .shopping_cart .shopping_carrier a{
    display: block;
    width: 75px; height: 34px;
    line-height: 34px;
    padding: 15px 20px 0 45px;
    text-align: center;
  }
  .search .shopping_cart .cart_icon{
    width: 27px; height: 20px;
    position: absolute;
    top: 21px; left: 10px;
    background: url("../../public/img/static/ui.png") no-repeat -100px -701px;
  }
  .search .shopping_cart .shop_num{
    position: absolute;
    top: -18px; left: 15px;
    width: 14px; height: 18px;
    line-height: 18px;
    padding: 0 3px;
    text-align: center;
    background: #a5a5a5;
    color: #fff;
    font-weight: bolder;
    font-style: normal;
  }
  .search .shopping_cart .change{
    background-color: #b20fd3;
  }
  .search .shopping_cart .change_i{
    border-left-color: #b20fd3;
  }
  .search .shopping_cart i{
    position: absolute;
    left: 5px; bottom: -4px;
    width: 0;
    border: 4px solid transparent;
    border-left-color: #a5a5a5;
  }
  .search .shopping_cart .shopping_carrier a > span{
    color: #5e5e5e;
  }
  /* 原有的a：hover样式被上面的样式覆盖了，再写一个 */
  .search .shopping_cart .shopping_carrier a:hover > span{
    color: #b20fb3;
  }
  .search .shopping_cart b{
    position: absolute;
    top: 29px; right: 10px;
    width: 0;
    border: 4px solid transparent;
    border-top-color: #5e5e5e;
  }
</style>

<script>
import { mapState } from 'vuex';
import popup from '../components/Popup.vue';
export default {
  components:{ popup },
  data(){
    return {
      type_chose:'goods',
      search_chose:false,
      keywords:['Apple产品',"冰箱自营","海尔洗衣机","美的空调","休闲零食","平板电脑","电烤箱","火锅食材开店"],
      keyword:''
    }
  },
  methods:{
    search_show(){ this.search_chose = true },
    search_hide(){ this.search_chose = false },
    change_type(type){ 
      this.type_chose = type;
      // 选完以后关闭列表
      this.search_chose = false; 
    },
    search(){
      // 先去除收尾空格
      this.keyword = this.keyword.trim();
      // 如果用户搜索栏为空的时候 点击搜索
      if(this.keyword == ''){
        // 则默认搜索手机
        this.keyword = '手机';
      }
      console.log(`搜索${this.keyword}相关的物品`);
      this.$router.push(`/list/${this.keyword}`);
    },
    into_shop(){
      // 调用子组件下的方法
      this.$refs.popupMask.judge();
    }
  },
  computed:{
    ...mapState(["shoppingCartList"])
  },
  watch:{
    // 一边输入一边搜索
    // keyword(){
    //   this.search();
    // }
  }
}
</script>