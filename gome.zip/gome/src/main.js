import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
import gomeTop from './components/GomeTop.vue'
import gomeBottom from './components/GomeBottom.vue'

Vue.config.productionTip = false
// 配置axios默认基础路径（'/'配合proxy）
axios.defaults.baseURL="/";
// 添加进原型对象，所有组件都可使用
Vue.prototype.axios = axios;
// 页头
Vue.component('gome-top',gomeTop);
// input自动获取焦点
Vue.directive("focus",{
  inserted(e){
    e.focus();
  }
})
// 页脚
Vue.component('gome-bottom',gomeBottom);

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
