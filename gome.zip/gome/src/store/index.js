import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
import router from '../router'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    // 购物车商品列表
    shoppingCartList:[],
    // 用户ID
    uid:'',
    // 用户名
    username:'',
    // 登录状态（-1：登录失败 | 0：未登录 | 1：已登录）
    loginState:0,
    /* 
      商品ID，用作复选框唯一value值，该ID属于临时添加，不进入数据库，原因：每个商品都需要一个唯一标识属性，
      但是在数据库中，不同颜色、容量等属性的商品的ID都是一样的，而且直接操作shoppingCartList的下标，又会产生更多的坑
      所以我们不得不为每一个商品添加一个唯一标识属性，这样即使不同颜色、容量等属性的同一商品，也会有自己不同的商品ID
    */ 
    pid:0
  },
  mutations: {
    isInclude(state,object){
      for(let obj of state.shoppingCartList){
        // 我们比较商品名、容量、颜色、延保、分期（从中转站添加的商品只会比较名字，因为其余全是undefined）
        if(obj.us_name == object.us_name && obj.us_capacity == object.us_capacity && obj.us_color == object.us_color && obj.us_guarantee == object.us_guarantee && obj.us_stages == object.us_stages){
          // 说明包含，直接叠加商品个数
          obj.us_count += object.us_count;
          return;
        }
      }
      // for循环结束后，还是没有return，我们直接添加该商品
      // 每次用户往购物车添加商品时，我们也要为新商品添加唯一标识属性
      object.us_pid = ++state.pid;
      state.shoppingCartList.push(object);
    },
    setShoppingCartList(state,obj){
      // 每次登陆把商品对象添加进购物车数组前，我们要为其添加唯一标识属性
      obj.us_pid = ++state.pid;
      state.shoppingCartList.push(obj);
    },
    setUid(state,str){
      state.uid = str;
    },
    setPid(state,num){
      state.pid = num;
    },
    setUserName(state,str){
      state.username = str;
    },
    setLoginState(state,value){
      state.loginState = value;
    },
    clearUserName(state){
      state.username = '';
      state.loginState = 0;
    },
    clearShoppingCartList(state){
      state.shoppingCartList = [];
    }
  },
  actions: {
    userLogin(context,obj){
      axios.get('/v1/users/log_user',{
        params:{
          userNameOrPhone:obj.userNameOrPhone,
          password:obj.password
        }
      }).then(res=>{
        if(res.data.length != 0){
          // 每次登陆成功都把pid清0
          context.commit("setPid",0);
          let data = res.data[0];
          // 存ID
          context.commit("setUid",data.uid);
          // 存用户名
          context.commit("setUserName",data.username);
          // 存商品（商品不止一个，所以要遍历数据）
          if(data.us_name != null){
            // 用户从未添加进购物车商品，所以登陆后查询出来的数据全都是null，当数据不是null的时候，我们才把商品加入购物车列表
            for(let obj of res.data){
              context.commit("setShoppingCartList",{
                us_img: obj.us_img,
                us_name: obj.us_name,
                us_price: obj.us_price,
                us_count: obj.us_count,
                us_color: obj.us_color,
                us_capacity: obj.us_capacity,
                us_guarantee: obj.us_guarantee,
                us_stages: obj.us_stages,
                us_db: obj.us_db,
                us_dbi: obj.us_dbi
              });
            }
          }
          // 改变登录状态
          context.commit("setLoginState",1);
          // 跳回首页
          router.push('/');
        }else{
          context.commit("setLoginState",-1);
        }
      })
    },
  },
  modules: {
  }
})
